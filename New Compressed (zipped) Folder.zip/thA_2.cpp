#include <iostream>
#include <string>

using namespace std;
class Student {
private:
    int studentId;
    string Sname;
    int at;
    char grade;

public:
    Student() {}
    Student(int id, string n) : studentId(id), Sname(n) {}
    Student(int id, string n, int attendance, char g) : studentId(id), Sname(n), at(attendance), grade(g) {}

    int getStudentId() {
        return studentId;
    }

    string getStudentName() {
        return Sname;
    }

    int getAttendance() {
        return at;
    }

    char getGrade() {
        return grade;
    }
};

class Teacher {
private:
    int teacherID;
    string Tname;
    string Texerpt;

public:
    Teacher() {}
    Teacher(string T, int tID, string Tex) : Tname(T), teacherID(tID), Texerpt(Tex) {}

    int getTeacherId() {
        return teacherID;
    }

    string getTeacherN() {
        return Tname;
    }

    string getTeacherEx() {
        return Texerpt;
    }
};

class Class{
private:
    int ClassId;
    string Cname;
    Student *s;
    Teacher t;

public:
	Class()
	{	}
    Class(int Cid, string Cn, Student as[], Teacher at, int limit)
        : ClassId(Cid), Cname(Cn), t(at) {
        s = new Student[limit];
        for (int i = 0; i < limit; ++i) {
            s[i] = as[i];
        }
    }

    int getClassId() {
        return ClassId;
    }

    string getClassName() {
        return Cname;
    }

    Student* getStudents() {
        return s;
    }

    Teacher getTeacher() {
        return t;
    }
    ~Class() {
        delete[] s;
    }
};

class overall {
public:
    overall() {}
    static int inc;
    static Class* Classes;
int limit;
    void make_class();
    void v_class_data();
    void specific_class();
     void supervision_class();
   void  report_attenedence();
  void  report_grade();
     
};
static string chatbox;
void sendmesage()
{
	cout<<"Send Mesage"<<endl;
	cin>>chatbox;
}
void readmesage()
{
cout<<"chatbox"<<endl;
if(chatbox=="")
{
	cout<<"chatbox is empty"<<endl;
}
else
{
cout<<">>"<<chatbox<<endl;
chatbox="";
cout<<"message readed"<<endl;
}
}
      void header()
      {

	  cout<<"-------------------------------------------------------------"<<endl;
        cout<<"                     School management System              "<<endl;
        cout<<"-------------------------------------------------------------"<<endl;
    }
void login()
{
	string n;
	int id;
	cout<<"name:"<<endl;
	cin>>n;
	cout<<"ID"<<id<<endl;
	cin>>id;
	cout<<"Login successful"<<endl;
}
int overall::inc = 0;
Class* overall::Classes = new Class[10]; 
void overall::make_class() {
	char choice='y';
	while(choice=='y'&&choice!='n')
	{
    int class_id;
    string class_n;
    cout << "Enter Class id:" << endl;
    cin >> class_id;
     cout << "Number of students in the class: ";
    cin >> limit;
    Student* list = new Student[limit];
    cin.ignore();
    cout << "Enter Class Name:" << endl;
    cin >> class_n;
    cout << "Enter student data for this class:" << endl;
    for (int i = 0; i < limit; i++) {
        string s_a;
        int stid;
        char grade;
        int att;
        cout << "Student Name: ";
        cin >> s_a;
        cout << "Student ID : ";
        cin >> stid;
        cout << "Student attence: ";
        cin >> att;
        cout << "Student attence grade: ";
        cin >> grade;
        list[i] = Student(stid, s_a, att, grade);
    }
    string tName;
    int tId;
    string Qual;
    cout << "Enter teacher data:" << endl;
    cout << "Teacher name: ";
    cin >> tName;
    cout << "Teacher ID: ";
    cin >> tId;
    cout << "Teacher Qualification: ";
    cin>>Qual;
    Teacher Classinch = Teacher(tName, tId, Qual);
    Classes[inc] = Class(class_id, class_n, list, Classinch, limit);
  
    delete[] list;
	cout<<"Do you want to make class"<<endl;
	cin>>choice; 
	inc++;
}
}
void overall::v_class_data() 
{
    for (int i = 0; i < inc; i++) {
        cout << "Class ID: " << Classes[i].getClassId() << endl;
        cout << "Class Name: " << Classes[i].getClassName() << endl;
        cout << "Teacher Name: " << Classes[i].getTeacher().getTeacherN() << endl;
        cout << "Teacher ID: " << Classes[i].getTeacher().getTeacherId() << endl;
        cout << "Teacher Qualification: " << Classes[i].getTeacher().getTeacherEx() << endl;
        for (int j = 0; j < limit; j++) {
            cout << "Student ID: " << Classes[i].getStudents()[j].getStudentId() << endl;
            cout << "Student Name: " << Classes[i].getStudents()[j].getStudentName() << endl;
            cout << "Student attendence: " << Classes[i].getStudents()[j].getAttendance()<< "%"<< endl;
            cout << "Student grade: " << Classes[i].getStudents()[j].getGrade() << endl;
        }
    }
}
void overall:: specific_class()
{
	int fetchClass;
	cout<<"which class data you want to retrive"<<endl;
	cout<<"Class ID"<<endl;
	cin>>fetchClass;
	  for (int i = 0; i < inc; i++) {
	  	if(Classes[i].getClassId()==fetchClass)
	  	{
        cout << "Class ID: " << Classes[i].getClassId() << endl;
        cout << "Class Name: " << Classes[i].getClassName() << endl;
        cout << "Teacher Name: " << Classes[i].getTeacher().getTeacherN() << endl;
        cout << "Teacher ID: " << Classes[i].getTeacher().getTeacherId() << endl;
        cout << "Teacher Qualification: " << Classes[i].getTeacher().getTeacherEx() << endl;
        for (int j = 0; j < limit; j++) {
            cout << "Student ID: " << Classes[i].getStudents()[j].getStudentId() << endl;
            cout << "Student Name: " << Classes[i].getStudents()[j].getStudentName() << endl;
            cout << "Student attendence: " << Classes[i].getStudents()[j].getAttendance()<< "%"<< endl;
            cout << "Student grade: " << Classes[i].getStudents()[j].getGrade() << endl;
        }
    }
    }
}
void overall::supervision_class()
{
	int fetch;
	cout<<"Dear Teacher\nEnter your Teacher ID"<<endl;
	cin>>fetch;
		  for (int i = 0; i < inc; i++) 
		  {
	  	if(Classes[i].getTeacher().getTeacherId()==fetch)
	  	{
        cout << "Teacher Name: " << Classes[i].getTeacher().getTeacherN() << endl;
        cout << "Teacher ID: " << Classes[i].getTeacher().getTeacherId() << endl;
        cout<<"-------------------------------------------------------------"<<endl;
        cout<<"               Class Students                      "<<endl;
        cout<<"-------------------------------------------------------------"<<endl;
        for (int j = 0; j < limit; j++) {
            cout << "Student ID: " << Classes[i].getStudents()[j].getStudentId() << endl;
            cout << "Student Name: " << Classes[i].getStudents()[j].getStudentName() << endl;
            cout << "Student attendence: " << Classes[i].getStudents()[j].getAttendance()<< "%"<< endl;
            cout << "Student grade: " << Classes[i].getStudents()[j].getGrade() << endl;
        }
    }
    }
}

void overall::report_attenedence()
{
	int fetch;
	cout<<"Dear Teacher\nEnter your Teacher ID"<<endl;
	cin>>fetch;
		  for (int i = 0; i < inc; i++) 
		  {
	  	if(Classes[i].getTeacher().getTeacherId()==fetch)
	  	{
        cout << "Teacher Name: " << Classes[i].getTeacher().getTeacherN() << endl;
        cout << "Teacher ID: " << Classes[i].getTeacher().getTeacherId() << endl;
        cout<<"-------------------------------------------------------------"<<endl;
        cout<<"                     Attendence Report                           "<<endl;
        cout<<"-------------------------------------------------------------"<<endl;
        for (int j = 0; j < limit; j++) {
        	cout << "Student ID: " << Classes[i].getStudents()[j].getStudentId() << endl;
            cout << "Student Name: " << Classes[i].getStudents()[j].getStudentName() << endl;
            cout << "Student attendence: " << Classes[i].getStudents()[j].getAttendance()<< "%"<< endl;
        }
    }
    }
}
void overall::report_grade()
{
	int fetch;
	cout<<"Dear Teacher\nEnter your Teacher ID"<<endl;
	cin>>fetch;
		  for (int i = 0; i < inc; i++) 
		  {
	  	if(Classes[i].getTeacher().getTeacherId()==fetch)
	  	{
        cout << "Teacher Name: " << Classes[i].getTeacher().getTeacherN() << endl;
        cout << "Teacher ID: " << Classes[i].getTeacher().getTeacherId() << endl;
        cout<<"-------------------------------------------------------------"<<endl;
        cout<<"                     Grade  Report                           "<<endl;
        cout<<"-------------------------------------------------------------"<<endl;
        for (int j = 0; j < limit; j++) {
        	cout << "Student ID: " << Classes[i].getStudents()[j].getStudentId() << endl;
            cout << "Student Name: " << Classes[i].getStudents()[j].getStudentName() << endl;
            cout << "Student grade: " << Classes[i].getStudents()[j].getGrade() << endl;
        }
    }
    }
}
int main() {
	 overall a;
	 header();
	int choice_user;
	cout<<"1:Administrator\n2:Teacher\n3:Student\n4:parents"<<endl;
	cin>>choice_user;
	switch(choice_user)
	{
case 1:
	{
	 login();
	 int in;
	 menu:
	 cout<<"1:Make Class\n2:View specific Class\n3:Classes and data\n4Menu\n5:Report attendence\n6:Report Grade\n7Exit"<<endl;
	 cin>>in;
	 if (in==1){
	 	a.make_class();
	 }
	 else if (in==2){
	  a.supervision_class();
	 }
	  else if(in==3){
	 	a.v_class_data();
	 }
	  else if (in==4){
	 goto menu;
	 }
	  else if (in==5){
	 	a.report_attenedence();
	 }
	 else if (in==6){
	  a.report_grade();
	 }
	  else if (in==7){
	 return 0;
	 }
	 else {
	 	cout<<"right option"<<endl;
	 }
	}
break;
case 2:
	{
	login();
	 int in;
	 tmenu:
	 cout<<"1:View specific Class data\n2:Menu\n3:Report attendence\n4:Report Grade\n5Exit"<<endl;	
	 cin>>in;
	if (in==1){
	  a.supervision_class();
	 }
	  else if(in==2){
	 goto tmenu;
	 }
	  else if (in==3){
	 	a.report_attenedence();
	 }
	 else if (in==4){
	  a.report_grade();
	 }
	  else if (in==5){
	 return 0;
	 }
	  else {
	 	cout<<"right option"<<endl;
	 }
	}
break;
case 3:
	{
	login();
	 int in;
	 smenu:
	 cout<<"1:view meassage and updates\n2Report attendence\n3:Report Grade\n4smenu\n5 meassage\n6Exit"<<endl;	
	 cin>>in;
	  if(in==2){
	  	  a.report_grade();
	 }
	  else if (in==3){
	 	a.report_attenedence();
	 }
	  else if (in==4){
	  	 goto smenu;
	 }
	  else if (in==6){
	 return 0;
	 }
	  else {
	 	cout<<"right option"<<endl;
	 }
	}	
break;
case 4:
	{
	login();
	 int in;
	 cout<<"1:view meassage \n2:send meassage\n3:exit"<<endl;
	 cin>>in;
	   if(in==1){
	  	// readmessage();
	 }
	   else if(in==2){
	  //	 sendmessage();
	 }
	   else if(in==3){
	  	  return 0;
	 }
	 	  else {
	 	cout<<"right option"<<endl;
	 }
	}
	break;
   default :
   	cout<<"Enter right option "<<endl;
	   }
}
