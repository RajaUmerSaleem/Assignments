#include<iostream>
#include"User.h"

using namespace std;
void header(){
     cout<<"-----------------------------"<<endl;
	 cout<<"  Library Management System  "<<endl;
 	 cout<<"-----------------------------"<<endl;
}
void login()
{
	cout<<"\t\tLogin successfully"<<endl;
}
static string chatbox;
void sendmesage()
{
	cout<<"Send Mesage"<<endl;
	cin>>chatbox;
}
void readmesage()
{
cout<<"chatbox"<<endl;
if(chatbox=="")
{
	cout<<"chatbox is empty"<<endl;
}
else
{
cout<<">>"<<chatbox<<endl;
chatbox="";
cout<<"message readed"<<endl;
}
}
class Book{
public:
string name;
string author;
string ISBN;
bool ava;

Book()
{	
}
Book(string b_nam,string b_a,string Ib,bool av)
{
name=b_nam;
author=b_a;
ISBN=Ib;	
ava=av;
}
void display_name()
{
	cout<<"Book "<<name<<endl;
	cout<<"Athor "<<author<<endl;
	cout<<"ISBN"<<ISBN<<endl;
	if (ava==false)
	{
		cout<<"Status : Borrowed"<<endl;
	}
	else
	if (ava==true)
	{
		cout<<"Status : Available"<<endl;
	}
} 
void available()
{

	if (ava==true)
	{
	cout<<"Book "<<name<<endl;
	cout<<"Athor "<<author<<endl;
	cout<<"ISBN"<<ISBN<<endl;
	}
}
void borrowed()
{

	if (ava==false)
	{
	cout<<"Book "<<name<<endl;
	cout<<"Athor "<<author<<endl;
	cout<<"ISBN"<<ISBN<<endl;
	}
}
void updateStatus()
{
ava=false;
        } 
};
class Library{
public:
static int counter;
int size;
	string choice = "y";
	Book *bookptr=NULL;
	Library()
	{
			bookptr=new Book[10];
	}
	void m_bookar()
	{
		cout<<"Enter books no you want to add"<<endl;
 	cin>>size;
		bookptr=new Book[size];
	}
	void addbooks()
	{
	string a_bn;
string a_a;
string a_I;
bool a_ava;
	while(choice!="n"&&choice=="y")
		{
			cin.ignore(); 
			cout<<"enter name of book "<<endl;
			getline(cin,a_bn);
			cout<<"enter Author of book "<<endl;
			getline(cin,a_a);
			cout<<"enter  ISBN of book "<<endl;
			getline(cin,a_I);
			cout<<"Enter Availability of book "<<endl;
			cin>> a_ava;
		bookptr[counter++]=Book(a_bn,a_a,a_I,a_ava);
		cout<<"Enter choice(y/n):"<<endl;
		cin>>choice;
		}	
	}
	void remove_books()
	{
		string Ch_name="";
			cout<<"Enter book name you that you want to delete"<<endl;
 	cin>>Ch_name;
 		cin.ignore();
	for(int i=0;i<counter;i++)
	{
		if(Ch_name==bookptr[i].name)
		{
bookptr[i].name=" ";
bookptr[i].author="";
bookptr[i].ISBN="";
cout<<"\t\tremoved succesfully..";
swap(bookptr[i],bookptr[counter]);
--counter;
        } 
	}
	}
	void update_book(){
		string a_bn;
string a_a;
string a_I;
bool a_ava;
				string Ch_name="";
			cout<<"Enter book name you that you want to update"<<endl;
 	    cin>>Ch_name;
 		   cin.ignore();
			cout<<"enter name of book "<<endl;
			getline(cin,a_bn);
			cout<<"enter Author of book "<<endl;
			getline(cin,a_a);
			cout<<"enter  ISBN of book "<<endl;
			getline(cin,a_I);
			cout<<"Enter Availability of book "<<endl;
			cin>> a_ava;
	for(int i=0;i<counter;i++)
	{
		if(Ch_name==bookptr[i].name)
		{
bookptr[i].name=a_bn;
bookptr[i].author=a_a;
bookptr[i].ISBN=a_I;
bookptr[i].ava=a_ava;	
	}
}
}
	void showbooks()
	{
	cout<<"----BOOKS---"<<endl;
	for(int i=0;i<counter;i++)
		{
		bookptr[i].display_name();
		}
	}
	//borrow overall
	void borrowBook()
	{
	showbooks();
	string Ch_name;
	cout<<"Enter book name you that you want to borrow"<<endl;
 	cin>>Ch_name;
 		for(int i=0;i<counter;i++)
		{
			if(Ch_name==bookptr[i].name)
		bookptr[i].display_name();
		bookptr[i].updateStatus();
		}
	}
 	void showborrow()	
	{
cout<<"---Borrowed Books---"<<endl;
	for(int i=0;i<counter;i++)
		{
		bookptr[i].borrowed();
		}
	}	
 	
    void showavailabe()	
	{
cout<<"---Available Books---"<<endl;
	for(int i=0;i<counter;i++)
		{
		bookptr[i].available();
		}
	}	
	~Library()
	{
		delete[] bookptr;
	}
};

int Library::counter=0;

User::User(string nam,string r)
{
	id=nam;
	role=r;
	login();
}
 void User::display_info()
{
	cout<<"name"<<id<<endl;
}
class student:public User{
public:
student()
{}
student(string nam,string r):User( nam,r){
}
void showbooks(Library &obj)
{
 obj.showbooks();
}
void borrow(Library &obj)
{
obj.borrowBook();	
}
};

class librarian : public User{
public:
librarian()
{
}
 librarian(string nam, string r) : User(nam, r) {}
void showbooks(Library &obj)
{
 obj.showbooks();
}
void ad_b(Library &obj)
{
obj.addbooks();
}
void remove(Library &obj)
{
obj.remove_books();
}
void update(Library &obj)
{
obj.update_book();	
}
};
int main()
{
header();
int size;
int pch;
Library a;
string n_s;//name
string p_s;//password
p:
cout<<"1: Student"<<endl;
cout<<"2: Librarian"<<endl;
cin>>pch;
switch(pch)
{
	case 1:
		{
		cout<<"Enter your profile name : "<<endl;
		cin>>n_s;
		cout<<"Enter your  password : "<<endl;
		cin>>p_s;
		student s(n_s,p_s);
		int furCh;
		cout<<"1: borrow Book"<<endl;
		cout<<"2: view Books"<<endl;
		cout<<"3: Chatbox"<<endl;
		cin.ignore();
				cin>>furCh;
		if(furCh==1)
		{
			s.display_info();
				s.showbooks(a);
				s.borrow(a);
		}
		else if(furCh==2)
		{
			s.showbooks(a);
		}
		else if(furCh==3)
		{
			int chatch;
		cout<<"1:send message\n2:check inbox "<<endl;
			cin>>chatch;
			switch(chatch)
			{
			case 1:
				sendmesage();
				break;
		  case 2:
		  	readmesage();
		  	break;
		default:
		cout<<"invalid input"<<endl;   		
		}
	}
		else
	{
		cout<<"click right one"<<endl;
	}
}
//break;
		case 2:
			{
		cout<<"Enter your profile name : "<<endl;
		cin>>n_s;
		cout<<"Enter your  password : "<<endl;
		cin>>p_s;
		librarian l(n_s,p_s);
		int furCh;
		cout<<"1: Add Books"<<endl;
		
		cout<<"2: view Books"<<endl;
		cout<<"3: Updtae Books"<<endl;
		cout<<"4: Remove Books"<<endl;
		cout<<"5: Chatbox"<<endl;
		cout<<"6: View allaviable Books"<<endl;
		cout<<"7: view Borrowed Books"<<endl;
		cin>>furCh;
		if(furCh==1)
		{
		a.m_bookar();
    	l.ad_b(a);
	  l.showbooks(a);  
	   goto p;
		}
		else if(furCh==2)
		{
			l.showbooks(a);
			goto p;
		}
		else if(furCh==3)
		{
		l.update(a)	;
		l.showbooks(a);
			goto p;
		}
		else if(furCh==4) 
		{
			l.remove(a);
			l.showbooks(a);
		}
			else if(furCh==5)
		{
			int chatch;
		cout<<"1:send message\n2:check inbox "<<endl;
			cin>>chatch;
			switch(chatch)
			{
			case 1:
				sendmesage();
				goto p;
				break;
		  case 2:
		  	readmesage();
		  	goto p;
		  	break;
		default:
		cout<<"invalid input"<<endl;   		
		}
	}
		else if(furCh==6){
		a.showavailabe();
	}
	else if(furCh==7){
		a.showborrow();
	}
	else {
		cout<<"invalid input"<<endl;
	}
}
default:
		cout<<"invalid input"<<endl;
}
}




