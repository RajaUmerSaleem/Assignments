//#include <iostream>
//#include <string>
//
//using namespace std;
//
//class scart {
//private:
//    static const int totalitems = 10;
//    string items[totalitems];
//    int itemcount;
//
//public:
// 
//    scart() : itemcount(0) {}
//
//
//    scart& additem(const string& item) {
//        if (itemcount < totalitems) {
//            items[itemcount++] = item;
//        }
//        else {
//            cout << "No more Space" << endl;
//        }
//        return *this;
//    }
//
//
//    scart& remove(const string& item) {
//        for (int i = 0; i < itemcount; ++i) {
//            if (items[i] == item) {
//
//                for (int j = i; j < itemcount - 1; ++j) {
//                    items[j] = items[j + 1];
//                }
//                itemcount--;
//                return *this;
//            }
//        }
//        cout << "Not Found" << endl;
//        return *this;
//    }
//    void display() {
//        cout << "Items in the  cart:" << endl;
//        for (int i = 0; i < itemcount; i++) {
//            cout << items[i] << endl;
//        }
//    }
//};
//
//int main() {
//    scart s1;
//    s1.additem("sugar").additem("vegetable").additem("milk").additem("bulb");
//
//    s1.display();
//
//    s1.remove("bulb");
//
//    s1.display();
//
//    return 0;
//}