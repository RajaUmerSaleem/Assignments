//#include<iostream>
//using namespace std;
//class stu
//{ private:
//	int regno;
//	string firstname;
//	string secondname;
//	string program;
//	float cgpa;
//public:	
//	stu(int a, string b, string c,string d,float e)
//	{
//		if (a <= 565 && a >= 501)
//		{
//			regno = a;
//		}
//		else
//		{
//			regno = 0;
//		}
//		firstname = b;
//		secondname = c;
//		program = d;
//		if (e <= 4 && e >= 0)
//		{
//			cgpa = e;
//		}
//		else
//		{
//			cgpa = -1;
//		}
//	}
//
//	stu(int a, string b, string c)
//	{
//		if (a <= 565 && a >= 501)
//		{
//			regno = a;
//		}
//		else
//		{		regno = 0;
//		}
//		firstname = b;
//		secondname = " ";
//		program = c;
//		cgpa = -1;
//	}
//	stu(int a, string b, string c, string d)
//	{
//		if (a <= 565 && a >= 501)
//		{
//			regno = a;
//		}
//		else
//		{
//			regno = 0;
//		}
//		firstname = b;
//		secondname = c;
//		program = d;
//		cgpa = -1;
//	}
//	void setreg(int a)
//	{
//		if (a <= 565 && a >= 501)
//		{
//			regno = a;
//		}
//		else
//		{
//			regno = 0;
//		}
//	}
//	void setfirst(string b)
//	{
//		firstname = b;
//	}
//	void setsecond(string c)
//	{
//		secondname = c;
//	}
//	void setprogram(string d)
//	{
//		program = d;
//	}
//	void setcgpa(float e)
//	{
//		if (e <= 4 && e >= 0)
//		{
//			cgpa = e;
//		}
//		else
//		{
//			cgpa = -1;
//		}
//	}
//	void read()
//	{
//		int a;
//		string b, c, d;
//		float e;
//		cout << "enter regno: ";
//		cin >> a;
//		setreg(a);
//		cout << "enter firstname";
//		cin >> b;
//		setfirst(b);
//		cout << "enter secondname";
//		cin >> c;
//		setsecond(c);
//		cout << "enter program";
//		cin >> d;
//		setprogram(d);
//		cout << "enter cgpa";
//		cin >> e;
//		setcgpa(e);
//	}
//	int getreg()
//	{
//		return regno;
//	}
//	string getfirst()
//	{
//		return firstname;
//	}
//	string  getsecond()
//	{
//		return secondname;
//	}
//	string getprogram()
//	{
//		return program;
//	}
//	float getcgpa()
//	{
//		return cgpa;
//	}
//	void write()
//	{
//		cout<<getreg();
//		cout << endl;
//		cout<<getfirst();
//		cout << endl;
//		cout<<getsecond();
//		cout << endl;
//		cout<<getprogram();
//		cout << endl;
//		cout<<getcgpa();
//		cout << endl;
//	}
//	bool isfirst()
//	{
//		if (cgpa = -1)
//		{		cout << "first semester " << endl;
//		return true;
//	    }
//		else
//			return false;
//	}
//	float percentage()
//	{
//		float p = 0;
//		if (cgpa <= 4 && cgpa >= 0.0)
//		{
//			p = (cgpa * 100) / 4;
//			cout << p;
//			return p;
//		}
//		else
//			cout << -1;
//			return -1;
//	}
//	bool ispromote()
//	{
//		if (cgpa >= 2)
//		{
//			cout << "promoted" << endl;
//			return true;
//		}
//		else {
//			cout << "fail"<<endl;
//			return false;
//		}
//	}
//	~stu()
//	{
//		cout << "destructor executed";
//	}
//
//};
//
//
//
//
//int main()
//{
//	stu s1(501, "ali", "ahmad", "cs", 3.4),
//		s2(540, "asif", "cs"), 
//		s3(513, "mohsin", "ali", "cs");
//	s1.write();
//	s2.write();
//	s2.read();
//	s2.write();
//	s1.ispromote();
//	cout << "percentage : ";
//	s1.percentage();
//	cout << endl;
//return 0;
//
//}