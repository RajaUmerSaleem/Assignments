#include <iostream>
using namespace std;
// 1/
/*
class Media
{
public:
    virtual void play()
    {
        cout << "playing media file" << endl;
    }
    virtual void pause()
    {
        cout << "pausing media file" << endl;
    }
    virtual void stop()
    {
        cout << "stoping media file" << endl;
    }
    virtual void getting_metadata()
    {
        cout << "getting metadata  of media file" << endl;
    }

    virtual void adjusting_volume() = 0;

    virtual void displaying_visual() = 0;

};
class Audio : public Media
{
public:
    void play() override
    {
        cout << "playing Audio file" << endl;
    }
    void pause() override
    {
        cout << "pausing audio file" << endl;
    }
    void stop() override
    {
        cout << "stoping audio file" << endl;
    }
    void adjusting_volume() override
    {
        cout << " adjusting volume of audio file" << endl;
    }
    void getting_metadata() override
    {
        cout << " geting audio metadata" << endl;
    }
    void displaying_visual() override
    {
        cout << "displaying visual of audio file" << endl;
    }
};
class Vedio : public Media
{
public:
    void play() override
    {
        cout << "playing vedio" << endl;
    }
    void pause() override
    {
        cout << " pausing vedio" << endl;
    }
    void stop() override
    {
        cout << "stoping vedio" << endl;
    }
    void adjusting_volume() override
    {
        cout << " adjusting volume of vedio" << endl;
    }
    void getting_metadata() override
    {
        cout << " getting metadata of vedio" << endl;
    }
    void displaying_visual() override
    {
        cout << " getting vsiuals of vedio" << endl;
    }
};
class Image : public Media
{
public:
    void play() override
    {
        cout << "playing Image" << endl;
    }
    void pause() override
    {
        cout << " pausing Image" << endl;
    }
    void stop() override
    {
        cout << "stoping Image" << endl;
    }
    void adjusting_volume() override
    {
        cout << " adjusting volume of Image" << endl;
    }
    void getting_metadata() override
    {
        cout << " getting metadata of Image" << endl;
    }
    void displaying_visual() override
    {
        cout << " getting vsiuals of Image" << endl;
    }
};

int main()
{
    Media *a;
    Audio b;
    a = &b;
    a->play();
    a->getting_metadata();
    a->displaying_visual();
    Vedio c;
    a = &c;
    a->play();
    a->getting_metadata();
    a->displaying_visual();
    Image img;
    a = &img;
    a->play();
    a->getting_metadata();
    a->displaying_visual();
}*/
/*
class Libraryitem
{
public:
    virtual void checkout()
    {
        cout << "checkout function LibraryItem" << endl;
    }
    virtual void returnitem()
    {
        cout << "return  LibraryItem" << endl;
    }
    virtual void display_details()
    {
        cout << "display_details function LibraryItem" << endl;
    }
    virtual void getauthor() = 0;
    virtual void getissuenumber() = 0;
};
class Book : public Libraryitem
{
public:
    void checkout() override
    {
        cout << "check book function Class Book" << endl;
    }
    void returnitem() override
    {
        cout << "return book function Class Book" << endl;
    }
    void display_details() override
    {
        cout << "display book function Class Book" << endl;
    }
    void getauthor() override
    {
        cout << "get author function Class Book" << endl;
    }
    void getissuenumber() override
    {
        cout << "get issuenumber function Class Book" << endl;
    }
};
//2
class Journal : public Libraryitem
{
public:
    void checkout() override
    {
        cout << "check Journal function Class Journal" << endl;
    }
    void returnitem() override
    {
        cout << "return Journal function Class Journal" << endl;
    }
    void display_details() override
    {
        cout << "display Journal function Class Journal" << endl;
    }
    void getauthor() override
    {
        cout << "get author function Class Journal" << endl;
    }
    void getissuenumber() override
    {
        cout << "get issuenumber function Class Journal" << endl;
    }
};

class DVD : public Libraryitem
{
public:
    void checkout() override
    {
        cout << "check DVD function Class DVD" << endl;
    }
    void returnitem() override
    {
        cout << "return DVD function Class DVD" << endl;
    }
    void display_details() override
    {
        cout << "display DVD function Class DVD" << endl;
    }
    void getauthor() override
    {
        cout << "get author function Class DVD" << endl;
    }
    void getissuenumber() override
    {
        cout << "get issuenumber function Class DVD" << endl;
    }
};
int main()
{
    Libraryitem *a;
    Book b;
    a = &b;
    a->checkout();
    a->returnitem();
    a->getauthor();
    a->getissuenumber();
    Journal c;
    a = &c;
    a->checkout();
    a->returnitem();
    a->getauthor();
    a->getissuenumber();
    DVD d;
    a = &d;
    a->checkout();
    a->returnitem();
    a->getauthor();
    a->getissuenumber();
    delete a;
}*/
// 3

class Employee
{
private:
    string name;
    int Empoyee_ID;
    string Empoyee_Department;

public:
   Employee()
   {}
    virtual void display_details() =0;
    virtual void  calculate_salary()=0;
    ~Employee() {}
};
class fulltimeEmployee : public Employee
{
    private:
    string name;
    int a;
    string dep;
    public:
    fulltimeEmployee(string n, int id, string dep) 
    {
        name = n;
        a = id;
        this->dep = dep;
    }
    void display_details() override
    {
        cout << "FulltimeEmployee name: " << name;
        cout << "Employee ID: " << a;
        cout << "Employee Department: " << dep;
        cout << "Facilites: ";
    } 
    void calculate_salary() override
    {
        string salary;
        cout << "Enter salary: ";
        cin >> salary;
        //1.5 extra for fulltime employee
        //  salary = salary+salary/1.5*100;
        cout << "FulltimeEmployee salary: " <<salary << endl ;
    }
    void fulltime_facilties(){
     cout<<"Better Salary: "<<endl;
     cout<<"Residence facilty: "<<endl;
    }
    ~fulltimeEmployee()
    {
    }
};
class PartailTime : public Employee
{
    private:
    string name;
    int a;
    string dep;
    public:
    PartailTime(string n, int id, string dep) {
        name = n;
        a = id;
        this->dep = dep;
    }
    void display_details() override
    {
        cout << "PartailTime name: " << name;
        cout << "Employee ID: " << a;
        cout << "Employee Department: " << dep;
    } 
        void Parttime_facilties(){
     cout<<" +0.5  bonus Salary: "<<endl;
     cout<<"travel facilty: "<<endl;
    }
    void calculate_salary() override
    {
        string salary;
        cout << "Enter salary: ";
        cin >> salary;
        //0.5 extra for partialtime employee
        //   salary = salary+salary/0.5*100;
        cout << "PartailTime salary: " <<salary << endl ;
    }
    ~PartailTime()
    {
    }
};
class Manager : public Employee
{
    private:
    string name;
    int a;
    string dep;
    public:
    Manager(string n, int id, string dep) {
        name = n;
        a = id;
        this->dep = dep;
    }
    void display_details() override
    {
        cout << "Manager name: " << name;
        cout << "Manager ID: " << a;
        cout << "Manager Department: " << dep;
    } 
    void calculate_salary() override
    {
        string salary;
        cout << "Enter salary: ";
        cin >> salary;
        //+2.5 Manager profits in salary
        //  salary = salary+salary/2.5*100;
        cout << "Manager salary: " <<salary << endl ;
    }
        void Manager_facilties(){
     cout<<" +2.5  bonus Salary: "<<endl;
     cout<<"Car facilty: "<<endl;
     cout<<"Residence: "<<endl;
    }
    ~Manager()
    {
    }
};
int main()
{
    Employee *a;
    Manager b("Raja",1,"industrial");
    a = &b;
    a->display_details();
    a->calculate_salary();
    b.Manager_facilties();

    fulltimeEmployee c("umer",2,"medical");
    a = &c;
    a->display_details();
    a->calculate_salary();
    c.fulltime_facilties();
    PartailTime d("partial employee",3,"freelancing");
    a = &d;
    a->display_details();
    a->calculate_salary();
    d.Parttime_facilties();
    delete a;
}

