#include <iostream>
#include <ctime> 
#include <windows.h>
#include<fstream> 
#include<string>
using namespace std;
void loading()                
{
cout<<"\t\t\t\tLoading..."<<endl;
char x = 219;
cout<<endl;
cout<<"\t\t\t";
for(int i=0;i<=35;i++)
{
	cout<<x;
	Sleep(75);
 } 
}
class Room {
private:
    int id_room;
    string type_room;
    string status;
    double price;
    int floor_number;
    int capacity;
    string features[3];

public:
    Room() {}
    Room(int id, string type, string st, double pr, int f_n, int ca, string fea[]) {
        id_room = id;
        type_room = type;
        status = st;
        price = pr;
        floor_number = f_n;
        capacity = ca;
        // Copy features array
        for (int i = 0; i < 3; ++i) {
            features[i] = fea[i];
        }
    }
    
    Room(Room &obj)
    {
        id_room = obj.id_room;
        type_room = obj.type_room;
        status = obj.status;
        price = obj.price;
        floor_number = obj.floor_number;
        capacity = obj.capacity;
        for (int i = 0; i < 3; ++i) {
            features[i] = obj.features[i];
        }
    }
    void access() {
        cout << "Room Id: " << id_room << endl;
        cout << "Room Type: " << type_room << endl;
        cout << "Room Status: " << status << endl;
        cout << "Room Price: " << price << endl;
        cout << "Room Floor Number: " << floor_number << endl;
        cout << "Room Capacity: " << capacity << endl;
        cout << "Room Features:" << endl;
        for (int i = 0; i < 3; ++i) {
            cout << features[i] << endl;
        }
    }
};

class Hotel {
private:
    int id_hotel;
    string name_hotel;
    string address_hotel;
    string city_hotel;
    Room rooms_hotel[5];

public:
    Hotel() {}
    Hotel(int id, string name, string ad, string c, Room room[]) {
        id_hotel = id;
        name_hotel = name;
        address_hotel = ad;
        city_hotel = c;
        for (int i = 0; i < 5; ++i) {
            rooms_hotel[i] = room[i];
        }
    }

    void access_room() {
        cout << "Hotel name: " << name_hotel << endl;
        cout << "Hotel address: " << address_hotel << endl;
        cout << "Hotel city: " << city_hotel << endl;
        for (int i = 0; i < 5; ++i) {
            rooms_hotel[i].access();
        }
    }
};

int main() {
    int id_hotel;
    string name_hotel;
    string address_hotel;
    string city_hotel;
    int id;
    string type;
    string status;
    double price;
    int floor_number;
    int capacity;
    string features[3];
    Room* rptr = new Room[5];
    loading();
    cout << "Enter hotel ID: ";
    cin >> id_hotel;
    cout << "Enter hotel name: ";
    cin >> name_hotel;
    cout << "Enter hotel address: ";
    cin >> address_hotel;
    cout << "Enter hotel city: ";
    cin >> city_hotel;
    for (int j = 0; j < 5; ++j) {
        cout << "Enter Room ID: ";
        cin >> id;
        cout << "Enter Room Type: ";
        cin >> type;
        cout << "Enter Room Status: ";
        cin >> status;
        cout << "Enter Room Price: ";
        cin >> price;
        cout << "Enter Room Floor Number: ";
        cin >> floor_number;
        cout << "Enter Room Capacity: ";
        cin >> capacity;
        cout << "Enter Room Features (3 features): ";
        for (int i = 0; i < 3; ++i) {
            cin >> features[i];
        }
        rptr[j] = Room(id, type, status, price, floor_number, capacity, features);
    }
    Hotel h(id_hotel, name_hotel, address_hotel, city_hotel, rptr);
    h.access_room();
    delete[] rptr;
    
    return 0;
}
