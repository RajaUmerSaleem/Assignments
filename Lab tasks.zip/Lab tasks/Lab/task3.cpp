//#include <iostream>
//#include <string>
//using namespace std;
//
//class Employee {
//private:
//    static int idcount;
//
//public:
//    int id;
//    string name;
//    double salary;
//    Employee() : id(idcount++), name(""), salary(0.0) {}
//    void setdata(int empid, const string& empname, double empsalary) {
//        id = empid;
//        name = empname;
//        salary = empsalary;
//    }
//    void display() {
//        cout << "ID: " << id<<endl << " Name: " << name <<endl<< " Salary: Rs." << salary << endl;
//    }
//};
//int Employee::idcount= 1;
//
//int main() {
//    Employee emp1, emp2, emp3, emp4;
//    emp1.setdata(emp1.id, "Shoaib", 50000.0);
//    emp2.setdata(emp2.id, "Ali", 60000.0);
//    emp3.setdata(emp3.id, "Zain", 55000.0);
//    emp4.setdata(emp4.id, "Arman", 65000.0);
//    cout << "Employee 1: ";
//    emp1.display();
//    cout << "Employee 2: ";
//    emp2.display();
//    cout << "Employee 3: ";
//    emp3.display();
//    cout << "Employee 4: ";
//    emp4.display();
//
//    return 0;
//}

