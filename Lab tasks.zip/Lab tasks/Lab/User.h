#ifndef USER_H
#define USER_H

#include <string>

class User {
	public:
    std::string id;
    std::string role;
    User() {}
    User(std::string nam, std::string r);
    void display_info();
};

#endif

