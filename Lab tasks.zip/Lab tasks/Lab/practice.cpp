#include <iostream>
using namespace std;
class library
{
private:
	string name;
	int bid;
	static int count;

public:
	library()
	{
		name = "";
		bid = 0;
	}
	library(string n, int id)
	{
		name = n;
		bid = id;
		count++;
	}
	void inccount()
	{
		count++;
	}

	void get_name()
	{
		cout << "Name" << name << endl;
	}
	library(library &obj)
	{
		name = obj.name;
		bid = obj.bid;
		count++;
	}
	void get_bid()
	{
		cout << "Book id" << bid << endl;
		cout << "count" << count << endl;
	}
	void set_name()
	{
		cout << "Name" << name << endl;
	}
	void set_data()
	{

		cout << "Enter the book  name" << endl;
		cin >> bid;
		cout << "Enter the book  name" << endl;
		cin >> name;
	}
};
int library::count = 0;
int main()
{
	cout << "Raja coding fun" << endl;
	cout << "Grow up " << endl;
	// cout<<"Count"<<endl;
	// cin>>library::count;
	library book1("Topper", 123);
	library book2(book1);
	book1.get_bid();
	book1.get_name();
	book2.get_bid();
	book2.inccount();
	book2.get_name();
	return 0;
}
-------
