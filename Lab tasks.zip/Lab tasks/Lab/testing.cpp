/*#include<iostream>
using namespace std;
int main()
{
cout<<"\a";

}
*/
/*
#include <iostream>
#include <windows.h>

using namespace std;

int main() {
    // Set frequency (in Hz) and duration (in milliseconds) for the sound
    int frequency = 2000; // Adjust frequency as needed
    int duration = 2000;  // Adjust duration as needed

    // Use the Beep function to generate the sound
    Beep(frequency, duration);

    // Output a message to indicate the alarm has finished
    cout << "Alarm sounded!\n";

    return 0;
}*/
/*

#include <iostream>
#include <windows.h>
#include <string>

using namespace std;



// Function to play the welcoming sound
void playWelcomeSound() {
    string soundPath = "C:/Users/umers/Downloads/kun-anta-slowed-reverb"; // Update the path to your welcome sound file
    LPCSTR soundFile = soundPath.c_str();
    PlaySound(soundFile, NULL, SND_FILENAME | SND_ASYNC);
}


int main() {
    cout << "Welcome to Our Hotel Management System!\n";
    cout << "Initializing...\n";

    // Play the welcoming sound
    playWelcomeSound();

    // Wait for the sound to finish playing (optional)
    // Adjust the delay time based on the duration of your sound file
    Sleep(5000); // Wait for 5 seconds

    // Proceed with the rest of your hotel management system initialization
    // Add your hotel management system functionalities here

    cout << "Initialization complete. Enjoy your stay!\n";

    return 0;
}
*/
/*
#include<iostream>
#include<ctime>
#include<fstream>
using namespace std;
class Employee
{
private:
    string E_name;
    int Employee_id;
    string position;
    double salary;
    int Manager_id;

public:
    time_t currentTime = time(NULL);
    string currentDate = ctime(&currentTime);
    Employee()
    {
    }
    Employee(string name, int id, string position, double salary, int manager_id)
    {
        E_name = name;
        Employee_id = id;
        this->position = position;
        this->salary = salary;
        this->Manager_id = manager_id;
    }
    void print_employee()
    {
        cout << "==================================" << endl;
        cout << "Employee Name: " << E_name << endl;
        cout << "Employee ID: " << Employee_id << endl;
        cout << "Position: " << position << endl;
        cout << "Salary: " << salary << endl;
        cout << "Manager ID: " << Manager_id << endl;
        cout << "=================================" << endl;
    }
    void checkinGuest(fstream &stream)
    {
        string checkin;
        string id;
        int RoomId;
        cin >> RoomId;
        cout << "Enter guestid: " << endl;
        cin >> id;
        checkin = id + " IN " + currentDate;
        stream.open("DatesGuest.txt", ios::app | ios::out);
        stream << RoomId << " " << checkin << endl;
        stream.close();
    }
    void checkoutGuest(fstream &stream)
    {
        string checkout;
        string id;
        int RoomId;
        cin >> RoomId;
        cout << "Enter guestid: " << endl;
        cin >> id;
        checkout = id + " OUT " + currentDate;
        stream.open("DatesGuest.txt", ios::app | ios::out);
        stream << RoomId << " " << checkout << endl;
        stream.close();
    }
};
int main()
{
fstream stream;
Employee a("Raja",123,"manager",2000,123);
a.print_employee();
a.checkinGuest(stream);
a.checkoutGuest(stream);
}
*/
/*
#include <iostream>
using namespace std;
class First
{
protected:
    int a;

public:
    First(int x = 1)
    {
        a = x;
    }
    void twist()
    {
        a *= 2;
    }
    int getVal()
    {
        twist();
        return a;
    }
};
class Second : public First
{
private:
    int b;

public:
    Second(int y = 5)
    {
        b = y;
    }
    void twist()
    {
        b *= 10;
    }
};
int main()
{
    First object1;
    Second object2;
    cout << object1.getVal() << endl;
    cout << object2.getVal() << endl;
    return 0;
}*/
/*
#include <iostream>
using namespace std;
class First
{
protected:
int a;
public:
First(int x = 1)
{ a = x; }
virtual void twist()
{ a *= 2; }
int getVal()
{ twist(); return a; }
};
class Second : public First
{
private:
int b;
public:
Second(int y = 5)
{ b = y; }
void twist() override
{ b *= 10; }
};
int main()
{
First object1;
Second object2;
cout << object1.getVal() << endl;
cout << object2.getVal() << endl;
return 0;
}*/

/*
#include<iostream>
#include<string>
using namespace std;
class player
{
private:
    string name;
    double point;

public:
    player()
    {
    }
    player(string name)
    {
        double p = 0;
        this->name = name;
        point = p;
    }
    double inc()
    {
        point = point + 10.0;
    }
    string name_show()
    {
        return name;
    }
    void show()
    {
        cout << name << endl;
        cout << point << endl;
    }
    double point_show()
    {
        return point;
    }
};
int main()
{
    player a("Raja");
    player b("Abduallah");
    int choice;
    cout << "Which Wana Come at first?" << endl;
    cout << "1:" << a.name_show() << endl;
    cout << "2:" << b.name_show() << endl;
    cin >> choice;
    if (choice == 1)
    {
        cout << "Answer the 3 Questions_ which is true" << endl;
        cout << "1: 2+2=4" << endl;
        cout << "2: 2+2=5" << endl;
        cout << "3: 2+2=6" << endl;
        cout << "4: 2+2=7" << endl;
        cin >> choice;
        if (choice == 1)
        {
            a.inc();
        }
        else
        {
            cout << "wrong Answer" << endl;
        }
        cout << "1: 2*2=4" << endl;
        cout << "2: 2*2=5" << endl;
        cout << "3: 2*2=6" << endl;
        cout << "4: 2*2=7" << endl;
        cin >> choice;
        if (choice == 1)
        {
            a.inc();
        }
        else
        {
            cout << "wrong Answer" << endl;
        }
        cout << "1:2/2=5" << endl;
        cout << "2:2/2=2" << endl;
        cout << "3:2/2=3" << endl;
        cout << "4:2/2=1" << endl;
        cin >> choice;
        if (choice == 4)
        {
            a.inc();
        }
        else
        {
            cout << "wrong Answer" << endl;
        }
        a.show();
        cout << b.name_show() << "now is your turn!" << endl;
        cout << "Answer the 3 Questions_ which is true" << endl;
        cout << "1: 2+2=4" << endl;
        cout << "2: 2+2=5" << endl;
        cout << "3: 2+2=6" << endl;
        cout << "4: 2+2=7" << endl;
        cin >> choice;
        if (choice == 1)
        {
            b.inc();
        }
        else
        {
            cout << "wrong Answer" << endl;
        }
        cout << "1: 2*2=4" << endl;
        cout << "2: 2*2=5" << endl;
        cout << "3: 2*2=6" << endl;
        cout << "4: 2*2=7" << endl;
        cin >> choice;
        if (choice == 1)
        {
            b.inc();
        }
        else
        {
            cout << "wrong Answer" << endl;
        }
        cout << "1:2/2=5" << endl;
        cout << "2:2/2=2" << endl;
        cout << "3:2/2=3" << endl;
        cout << "4:2/2=1" << endl;
        cin >> choice;
        if (choice == 4)
        {
            b.inc();
        }
        else
        {
            cout << "wrong Answer" << endl;
        }
        b.show();
    }
    if (choice == 2)
    {
        cout << "Answer the 3 Questions_ which is true" << endl;
        cout << "1: 2+2=4" << endl;
        cout << "2: 2+2=5" << endl;
        cout << "3: 2+2=6" << endl;
        cout << "4: 2+2=7" << endl;
        cin >> choice;
        if (choice == 1)
        {
            b.inc();
        }
        else
        {
            cout << "wrong Answer" << endl;
        }
        cout << "1: 2*2=4" << endl;
        cout << "2: 2*2=5" << endl;
        cout << "3: 2*2=6" << endl;
        cout << "4: 2*2=7" << endl;
        cin >> choice;
        if (choice == 1)
        {
            b.inc();
        }
        else
        {
            cout << "wrong Answer" << endl;
        }
        cout << "1:2/2=5" << endl;
        cout << "2:2/2=2" << endl;
        cout << "3:2/2=3" << endl;
        cout << "4:2/2=1" << endl;
        cin >> choice;
        if (choice == 4)
        {
            b.inc();
        }
        else
        {
            cout << "wrong Answer" << endl;
        }
        b.show();
        cout << a.name_show() << "now is your turn!" << endl;
        cout << "Answer the 3 Questions_ which is true" << endl;
        cout << "1: 2+2=4" << endl;
        cout << "2: 2+2=5" << endl;
        cout << "3: 2+2=6" << endl;
        cout << "4: 2+2=7" << endl;
        cin >> choice;
        if (choice == 1)
        {
            a.inc();
        }
        else
        {
            cout << "wrong Answer" << endl;
        }
        cout << "1: 2*2=4" << endl;
        cout << "2: 2*2=5" << endl;
        cout << "3: 2*2=6" << endl;
        cout << "4: 2*2=7" << endl;
        cin >> choice;
        if (choice == 1)
        {
            a.inc();
        }
        else
        {
            cout << "wrong Answer" << endl;
        }
        cout << "1:2/2=5" << endl;
        cout << "2:2/2=2" << endl;
        cout << "3:2/2=3" << endl;
        cout << "4:2/2=1" << endl;
        cin >> choice;
        if (choice == 4)
        {
            a.inc();
        }
        else
        {
            cout << "wrong Answer" << endl;
        }
        a.show();
    }
    if (a.point_show() > b.point_show())
    {
        cout << "==== Winner ====" << endl;
        a.show();
        cout << "================" << endl;
    }
    else if (a.point_show() < b.point_show())
    {
        cout << "==== Winner ====" << endl;
        b.show();
        cout << "================" << endl;
    }
    else if (a.point_show() == b.point_show())
    {
        cout << "==== Draw ====" << endl;
        a.show();
        b.show();
        cout << "================" << endl;
    }
    return 0;
}*/
/*
#include <iostream>

class A {
public:
    virtual void func() {}
};

class B:public A {
public:
    void func() override {}
};

int main() {
    std::cout << "Size of A: " << sizeof(A) << " bytes\n";
    std::cout << "Size of B: " << sizeof(B) << " bytes\n";
    return 0;
}
*/

#include <iostream>
using namespace std;
// template<class Y>
// Y larger(Y a=4, Y b=10) {
//     return (a > b)? a : b;
// }
// int main() {
//     int a = 1;
//     cout<<"Testing"<<endl;
//     cout<<larger(1,2)<<endl;
//     cout<<larger(1.1,2.2)<<endl;
//     cout<<larger<double>()<<endl;
//     cout<<larger<double>(1,2.2)<<endl;
//     return 0;
// }
//
//template<class T,class U>
//class class_name{
//    T a;
//U b;
//public:
//    class_name(T a, U b) {
//        this->a = a;
//        this->b = b;
//    }
//    class_name(T a){
//        this->b = 0;
//        this->a = a;
//    }
//T get_a() { return a;
//}
//    U get_b() { return b;
//}
//};
//
//int main() {
//    class_name<int,int> a(10,20);
//    cout<<a.get_a()<<endl;
//    class_name<double,char> b(10.5,'a');
//    cout<<b.get_a()<<endl;
//    class_name<char,string> c('a',"raja");
//    cout<<c.get_a()<<endl;
//    cout<<c.get_b()<<endl;
//    class_name<string,double> d("a");
//    cout<<d.get_a()<<endl;
//    cout<<d.get_b()<<endl;
//    return 0;
//}

//#include <iostream>
//using namespace std;
//
//int main() {
//    // Reset the text color to the default
//    cout << "\033[0m";
//
//    // Set the text color to red
//    cout << "\033[1;31mThis text is in red.\033[0m" << endl;
//
//    // Set the text color to green
//    cout << "\033[1;32mThis text is in green.\033[0m" << endl;
//
//    // Set the text color to blue
//    cout << "\033[1;34mThis text is in blue.\033[0m" << endl;
//
//    return 0;
//}


