/*#include<iostream>
using namespace std;
int main()
{
	int size;
	cout<<" Enter the size of array "<<endl;
	cin>>size;
	int *ptr = new int[size];
	for(int i=0;i<size;i++)
{
	cin>>ptr[i];
	}	
	for(int i=0;i<size;i++)
	{
		
	cout<<"Element #"<<i+1<<" "<<ptr[i]<<endl; 
}
remove[] ptr;
	return 0;
	
}*/
/*
#include<iostream>
using namespace std;
struct com{
	int real,imag;
};
void sum(	com n1,com n2,com fn)
{
fn.real=n1.real+n2.real;
	fn.imag=n1.imag+n2.imag;
	cout<<"Sum: "<<fn.real<<"+"<<fn.imag<<"i"<<endl;	
}
void sub(com n1,com n2,com fn)
{
	fn.real=n1.real-n2.real;
	fn.imag=n1.imag-n2.imag;
	cout<<"Sub: "<<fn.real<<"+"<<fn.imag<<"i"<<endl;	
}
void mux(	com n1,com n2,com fn)
{
fn.real=n1.real*n2.real;
	fn.imag=n1.imag*n2.imag;
	cout<<"mul: "<<fn.real<<"+"<<fn.imag<<"i"<<endl;	
}
void div(	com n1,com n2,com fn)
{
	fn.real=n1.real/n2.real;
	fn.imag=n1.imag/n2.imag;
	cout<<"div: "<<fn.real<<"+"<<fn.imag<<"i"<<endl;	
}
int main()
{
	int n;
	com n1,n2;
	com fn;
	cout<<"Note: Put +ve complex numbers"<<endl;
	cout<<" Enter the real part 1st and imaginary part 2nd of complex number1"<<endl;
	cin>>n1.real>>n1.imag;
	cout<<endl;
	cout<<" Enter the real part 1st and imaginary part 2nd of complex number2"<<endl;
    cin>>n2.real>>n2.imag;
	cout<<endl;
	cout<<"1st complex num is "<<n1.real<<"+"<<n1.imag<<"i"<<endl;
	cout<<"2nt complex num is "<<n2.real<<"+"<<n2.imag<<"i"<<endl;
	cout<<"operation you want to apply on these complex numbers"<<endl;
	cout<<"1: add\n2: sub\n3: div\n4: mul"<<endl;
	cin>>n;
	switch(n)
	{
	case 1:
sum(n1,n2,fn);
break;
	case 2:
sub(n1,n2,fn);
break;
	case 3:
mux(n1,n2,fn);
break;
	case 4:
div(n1,n2,fn);
break;		
		default:
			cout<<"Enter right operation "<<endl;
	}
}
*/
/*
#include<iostream>
using namespace std;
struct poly{
	int degree;
	int cofficent;
};
int main()
	{
	poly *exp=new plty[2];
	cout<<"Enter two polynomial "<<endl;
	cout<<"1st polynimial highest degree"<<endl;
	cin>>exp[0].degree;
	for(int=exp[0].degree;exp[0].degree>=0;exp[0].degree--)
{
	cin>>exp[i].cofficent;
}
	cout<<"2nd polynomial highest degree"<<endl;
	cin>>exp[1].degree;
	for(int=exp[1].degree;exp[1].degree>=0;exp[1].degree--)
{
	cin>>exp[2].cofficent;
}
	cout<<"1: add\n2: sub\n3: mul"<<endl;
	cin>>n;
	switch(n)
	{
	case 1:
		cout<<"adding polynimals";
		
//sum(n1,n2,fn);
//break;
	case 2:
sub(n1,n2,fn);
break;
	case 3:
mux(n1,n2,fn);
break;
	case 4:
div(n1,n2,fn);
break;		
		default:
			cout<<"Enter right operation "<<endl;
	}
}	
}
*/

#include<iostream>
using namespace std;
int main()
struct record{
string name, rollno;
int marks;
};
void insert
int main()
{
	record t[2];
	
}
	
	
	
	
	
