/*#include<iostream>
using namespace std;
class shop{
	private:
		string item[10];
		int itemN[10];
        int counter;
	public:
		void intilizeC()
		{
			counter=0;
		}
		void setData();
		void getData();
};
void shop::setData()
{
	cout<<"Enter item name: "<<endl;
	cin>>item[counter];
	cout<<"Enter item_code: "<<endl;
	cin>>itemN[counter];
	counter++;
}
void shop::getData()
{

for(int i=0; i<=counter;i++)
{
	cout<<"item code is"<<itemN[i]<<"item name is "<<item[i]<<endl;
}
}

int main()
{
	shop s;
	char c='y';
s.intilizeC();
while(c=='y'&&c!='n')
{
s.setData();
cout<<"You want to enter Item data:(y/n) "<<endl;
cin>>c;
}
s.getData();
}*/
/*
// static member function use for counter and increasing value for next memebers  and dont putting very first
// intializing value to the next object .
#include <iostream>
using namespace std;
class Employee
{
private:
	int id;
	static int count;

public:
	void setData()
	{
		cout << "Enter the ID of employee:" << endl;
		cin >> id;
		count++;
	}

	void getData()
	{
		cout << "Employee Id is " << id << " and it is Employee no# " << count << endl;
	}
};
int Employee::count;
int main()
{
Employee fn[5] ;
for(int i=0;i<5;i++)
{
	fn[i].setData();
	fn[i].getData();
}
}*/
/*
#include<iostream>
using namespace std;
class Demo {
public:
  int a;

  void FUN1() {
    cout << "\nFUN1 CALLED" << std::endl;
  }

  void FUN2() {
    cout << "\nFUN2 CALLED" << std::endl;
  }

  void FUN3() {
    cout << "\nFUN3 CALLED" << std::endl;
  }
};

int main() {
  Demo ob;
  ob.FUN1().FUN2().FUN3();
  return 0;
}
*/
/*
#include <iostream>

class Complex {
private:
    double real;
    double imag;

public:
    Complex(double r = 0, double i = 0) : real(r), imag(i) {}

    // Overloading addition operator
    Complex operator +(const Complex& other) const {
        return Complex(real + other.real, imag + other.imag);
    }

    // Overloading subtraction operator
    Complex operator -(const Complex& other) const {
        return Complex(real - other.real, imag - other.imag);
    }

    // Display the complex number
    void display() const {
        std::cout << real << " + " << imag << "i" << std::endl;
    }
};

int main() {
    Complex c1(2, 3);
    Complex c2(1, 4);

   c1 + c2.display();
     c1 - c2.display();

   

    return 0;
}

*/
/*
#include <iostream>
using namespace std;
class in_dec{
private:

int v;
int month;
public :
	in_dec()
	{
		v=1;
		month =1;
		
	}
	in_dec operator ++(int)
	{
	in_dec	a;
	a.v=v++;
	a.month= month++;
	return a;
	}
		in_dec operator --(int)
	{
	in_dec	a;
	a.v=v--;
	a.month= month--;
	return a;
	}
	void show()
	{
		cout<<"v"<<v<<endl;
		cout<<"month"<<month<<endl;
	}
};
int main()
{
in_dec a,c;
//c= ++a;
a.show();
c.show();
c=a++;
a.show();
c.show();
return 0;
}*/
	
#include<iostream>
using namespace std;

/*
class B{
private:
double w;
double h;
double l;
public:
B(we,he,le)
{w=we;h=he;l=le;}
B(B b)
{
w=b.we;
h=b.he;
l=b.le;
}
};
int main()
{
//code
} 
*/
/*
 // Assume header files are included
 class Box
 {
 private:
double width;
double length;
double height;
public:
Box()
{width=3.5; length 4.5; height 5.5; }
// Overloaded postfix ++ operator
void Box ++()
{
Box b;
b.width=width++;
b.length=length ++;
return b; }
 };*/
 //c) // Assume header files are included
 /*
 class BB
 {
 int one;
 int two;
 public:
bool equal() const;
print();
 BB(int, int);
}
 int main()
{
//code
} */
/*
Consider the following definition of the class myClass:
1)
class myClass
2) (
3) public:
4) void setX(int a);
5) void printX() const; //Function to output x.
6) static void printCount(); //Function to output
count.
7) static void incrementCount(); //Function to increment count. //Postcondition: count++;
8) myClass(int a = 0); //constructor with default parameters //Postcondition x = a; //If no value is specified for a, x = 0;
9) private:
10) int x;
11) static int count;
12) };
a) Write a C++ statement that initializes the member variable count to 0.
b) Write a C++ statement that increments the value of count by 1.
c) Write a C++ statement that outputs the value of count.
d) Write the definitions of the functions of the class myClass as described in its definition.
e) Write a C++ statement that declares myObjecti to be a myClass object and initializes its member variable x to 5.
f) Write a C++ statement that declares myObject2 to be a myClass object and initializes its member variable x to 7.
g) Which of the following statements are valid? (Assume that myObject! and myObject2 are as declared in Parts e and f.)
myObject1.printCount(); //Line 1
myObject1.printX(); //Line 2
myClass.printCount(); //Line 3
myClass.printX(); //Line 4
myClass::count++; //Line S
*/  


#include<iostream>
using namespace std;

class Caldays{
private:
float hours;
float days;
public:
Caldays()
{
hours=0;
	days=0;
}
Caldays(float h)
{
hours=h;
days=hours/8.0;
}
void pintDays()
{
cout<<"hours"<<hours<<endl;
cout<<"days"<<days<<endl;	
}

float operator *(Caldays& obj)
{
return hours*obj.hours;
}
float operator -(Caldays& obj)
{
return hours-obj.hours;

}
Caldays operator ++(int)
{ 
Caldays temp;
float t;
	temp.hours =hours++;
	t=temp.hours;
	temp.days=temp.hours/8.0;
	return temp;
}
Caldays operator =(Caldays &obj)
{
	days=obj.days;
	hours=obj.hours;
	return *this;
}
};
int main()
{
Caldays v(2),x(2);
v.pintDays();
Caldays y(x*v);
y.pintDays();
x.pintDays();
x++;
x.pintDays();
x++;
x.pintDays();
x-v;
x.pintDays();

}



