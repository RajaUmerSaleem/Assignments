/*#include<iostream>
using namespace std;
class car{
	private:
	int yr;
	string brand;
	int speed;
	public:
		car()
		{
			
		}
    car(int y, string b, int s)
{
 yr =y;
 brand= b;
speed =s;	
}
void getspeed()
{
	cout<<"Currect Speed :"<<speed<<endl;
}
void getbrand()
{
	cout<<"Car Brand:"<<brand <<" of year "<<yr <<endl;
} 
void accelerate()
{
	cout<<"speed is increasing "<<endl;
speed=speed+10;	
}
void brake()
{
		cout<<"speed is decreasing "<<endl;
speed=speed-10;	
}
car( car &obj)  
{
 yr =obj.yr;
 brand= obj.brand;
speed =obj.speed;	
}
};
int main()
{
car v1(2001,"Corolla",110);
v1.getspeed();
v1.getbrand();
for(int i=1;i<=5;i++)
{
v1.accelerate();	
}
v1.getspeed();
for(int i=1;i<=5;i++)
{
v1.brake();	
}
v1.getspeed();
car v2(v1);
v2.getspeed();
v2.getbrand();
return 0;
}*/
/*
#include<iostream>
using namespace std;
class bank{
	private:
 int ac_no;
double bal;
	public:
		bank()
		{
		}
bank(int ac,double b )	
	{
	ac_no=ac;
	bal=b;
	}
 void deposit(double add)
 {
 	bal+=add;
 }
 void withdraw(double sub)
 {
 	bal-=sub;
 }
const void getac_b()
{
	cout<<"Currect Balance:"<<bal<<endl;
} 
const  void getan()
{
	cout<<"Account No:"<<ac_no<<endl;
} 
};
int main()
{
	bank c1(1001,200.23);
	c1.getan();
	c1.getac_b();
	c1.deposit(200.33);
	c1.getac_b();
	c1.withdraw(33.33);
	c1.getac_b();
	return 0;
}*/
/*
#include<iostream>
#include<ctime>
#include<cstdlib>
using namespace std;
class enter{
	private:
 int size;
float *ptr;
	public:
		enter()
		{}
float* createfloat(int s)	
	{
	size=s;
ptr=new float[size];
for(int i=0; i<size; i++)
{
	ptr[i]=rand()%10;
}
	return ptr;
}
void print()
{
for(int i=0; i<size;i++)
{
	cout<<ptr[i]<<endl;
}
delete[] ptr;	
}
};
int main()
{
enter e1;
e1.createfloat(10);
e1.	print();
return 0;
}*/
/*
#include<iostream>
using namespace std;
class item{
	private:
	int id;
	string name;
	int quality;
	float cost;
	public:
		item()
		{
		}
	item(int i,string na,int q,float pri)
		{
	 id=i;
	 name=na;
    quality=q;
	 cost=pri;
		}
	item(int i,string na,int q)
		{
	 id=i;
	 name=na;
    quality=q;
	 cost=0.0;
		}
	item(int i,string na,float pri)
		{
	 id=i;
	 name=na;
    quality=0.0;
	 cost=pri;
		}
		void setid(int i)
		{
		id=i;	
		}
		void setname(string na)
		{
		 name=na;	
		}
		void setname(int q)
		{
	    quality=q;
		}
	  void setcost(float pri)
		{
        cost=pri;
		}
		void get()
		{
        cout<<"item : "<<id<<endl;
        cout<<"name : "<<name<<endl;
        cout<<"quantity : "<<quality<<endl;
        cout<<"cost : "<<cost<<endl;
		}
		item(item &obj)
		{
	 id=obj.id;
	 name=obj.name;
    quality=obj.quality;
	 cost=obj.cost;
		}
		~item()
		{
		}
	};
	int main()
	{
		item c3;
	item	c1(1001,"choclate",50,1550.02);
		c1.get();
	item 	c2(c1);
		return 0;
	}
*/
#include<iostream>
using namespace std;
class Student{
    private:
    string name;
    int* sc;
    int num_sc;
    public:
    Student()
    {
        name = "";
        sc = new int[3];
        num_sc = 0;
    }
    Student(string n, int nScore)
    {
        name = n;
        sc = new int[nScore];
        num_sc = nScore;
    }
    int getScore(int i)
    {
        return sc[i];
    }
    int getNumScore()
    {
        return num_sc;
    }
    ~Student()
    {
        delete[] sc;
    }
    void setsc(int*arr)
    {
        for (int i = 0; i < 3; i++)
        {
            sc[i] = arr[i];
        }
    }
    void printInfo()
    {
        cout<<"Name: "<<name<<endl;
        for (int i = 0; i < 3; i++)
        {
        cout<<"Score: "<<sc[i]<<endl;
        }
    }
};
class scfinder{
    private:
    Student* stu;
    public:
    scfinder(int noStu)
    {
        stu = new Student[noStu];
    }
    ~scfinder()
    {
        delete[] stu;
    }
    void setStudents(int index, Student* st = new Student)
    {
        stu[index] = *st;
    }
    void printsc(int noOfStu)
    {
        for (int i = 0; i < noOfStu; i++)
        {
            for (int j = 0; j < stu->getNumScore(); j++)
            {
                cout<<stu[i].getScore(j);
            }
        }
    }
};
int main()
{
    scfinder obj1(5);
    Student *stu = new Student[3];
    int std[3] = {20,30,24};
    stu[2].setsc(std);
    obj1.setStudents(1,stu);
}
	


