
//Q5
#include<iostream>
using namespace std;
class Product{
	private:
		static int Id;
		string name;
		int productid;
		string brand;
		int price;
		int Q_stock;
		int S_stock;
		double renevue;
		public:
			Product()
			{
			}
			Product (int I,string n,string b,int p,int Q,int S)
			{
				Id=I;
				productid=Id++;
				name=n;
				brand=b;
				price=p;
				Q_stock=Q;
				S_stock=S;
				Q_stock-S_stock;
				renevue=S_stock*price;
			}
		 void get_dta()
		 {
		 	cout<<"Id "<<productid<<endl;
		 	cout<<"Name "<<name<<endl;
		 	cout<<"brand "<<brand<<endl;
		 	cout<<"Price "<<price<<endl;
		 	cout<<"Currect Quantity in Stock "<<Q_stock<<endl;
		 	cout<<"sale "<<S_stock<<endl;	
			cout<<"Renevue "<<renevue<<endl;					
		 }
			void set_stocks(int stock)
			{
				Q_stock=stock;
					}	
					
					int fetch_sales()
					{
				return	S_stock	;
						}	
	};
	int Product:: Id=1;

int main()
{ 
int saletracker=0;
int size ;
int count=0;
string n;
string b;
int pr;
int Q;
int S;
double renevue;
cout<<"Enter the numbers of type of product in your stock"<<endl;
cin>>size;
	Product a[size];
	for(int i=0;i<size;i++)
{
		count++;
	cout<<"Enter Name of Product"<<endl;
	cin>>n;
	cout<<"Enter Brand of Product"<<endl;
	cin>>b;
	cout<<"Enter price of Product"<<endl;
	cin>>pr;
	cout<<"Enter Quantity of Product"<<endl;
	cin>>Q;
	cout<<"Enter Sale of Product"<<endl;
	cin>>S;
	a[i]=Product(count,n,b,pr,Q,S);
}
	for(int i=0;i<size;i++)
{
a[i].get_dta();
}
 int max_sale=a[0].fetch_sales();
	for(int i=0;i<size;i++)
{
	if(max_sale<a[i].fetch_sales())
	{
		max_sale=a[i].fetch_sales();
		saletracker=i;
	}
}
cout<<"The Maximun saled producvt is "<<endl;
a[saletracker].get_dta();
}
//Thankyou.. Ma,am Khola Naseen! for providing us this opportunity to learn about this..
