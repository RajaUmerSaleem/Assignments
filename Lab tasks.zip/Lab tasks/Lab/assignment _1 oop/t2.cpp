
//Q2

#include<iostream>
using namespace std;
class BA{
	int a_n;
	int a_b;
	string a_t;
	public:
		BA(int n,string t)
		{
			a_n=n;
			a_b=0;
			a_t=t;
		}
		BA(int n,int b, string t)
		{
			a_n=n;
			a_b=b;
			a_t=t;
		}
		BA(BA& obj)
		{
			a_n=obj.a_n;
		    a_b=obj.a_b;
			a_t=obj.a_t;
		}	
		friend ostream& operator<<(ostream& os, const BA& obj);
		friend void remove(int amount,BA& obj);
		friend void tranfer(int amount,BA& obj);
};
void remove(int amount,BA& obj)// for tranfer amount from Acount 1 to Acount 2
{
	obj.a_b-=amount;	
}
void tranfer(int amount,BA& obj)// for tranfer amount from Acount 1 to Acount 2
{
	obj.a_b+=amount;	
}
ostream& operator<<(ostream& os, const BA& obj)
{
	os<<"Account No "<<obj.a_n<<endl;	
	os<<"Account Balance "<<obj.a_b<<endl;
	os<<"Account type "<<obj.a_t<<endl;
	return os;
}	
int main()
{
	int ammount;
	BA a(1,1000,"currect"); 
    BA b(a);
    BA c(2,"saving");
	cout<<a<<endl;
	cout<<b<<endl;
	cout<<c<<endl;
	cout<<"Enter the ammount to tranfer"<<endl;
	cin>>ammount;
	remove(ammount,a);
	tranfer(ammount,c);
	cout<<a<<endl;
	cout<<b<<endl;
	cout<<c<<endl;
	}
