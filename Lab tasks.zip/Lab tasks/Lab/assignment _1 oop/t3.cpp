
//Q3
#include<iostream>
using namespace std;
class Date{
	private:
		int day,yr;// there day means current date of the day (1-31)
		string month;
		public :
				int m_no;
			Date()
			{
				day=1;
				month="January";
				yr=1900;
			}
			Date(int d,int m_n,int y)
			{
	string month_array[12] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
					day=d;	
			month=month_array[m_n-1];	
				yr=y;
			}
		string get_month()
			{
			return month;
	     	}	
			void set_month(int m_n)
			{
				string month_array[12] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
					month=month_array[m_n-1];	
					m_no=m_n;
			}
	   	int get_day()
			{
		    return day;
	     	}
		void set_day(int d)
			{
				day=d;	
			}
	    int get_year()
			{
				return yr;
			}
		void set_year(int y)
			{
			yr=y;
	      	}
    Date(Date& obj)	
    {
	obj.month=month;
	obj.day=day;
	obj.yr=yr;
	}
    void allData(){
	cout<<month<<"/"<<day<<"/"<<yr<<endl;
	cout<<month<<","<<day<<","<<yr<<endl;
    cout<<day<<","<<month<<","<<yr<<endl;
   }
friend ostream& operator<<(ostream& os, const Date& obj);
Date operator ++(int)
{
	Date obj;
	obj.day++;
	if(obj.day>31)
	{
		obj.day=1;
	}
		string month_array[12] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
		m_no++;
		obj.month=month_array[m_no-1];
	if (m_no>12)
		{
			m_no=1;
			obj.month=month_array[m_no-1];
			obj.yr++;
			}	
			return *this;
}
};
ostream& operator<<(ostream& os, const Date& obj)
{
	os<<obj.month<<"/"<<obj.day<<"/"<<obj.yr<<endl;
	os<<obj.month<<","<<obj.day<<","<<obj.yr<<endl;
    os<<obj.day<<","<<obj.month<<","<<obj.yr<<endl;	
    return os;
}

int main()
{
	int c_d,c_mon,c_ye;//day,month,year
    Date a;
    a.allData();
    Date b(2,3,2024);
   b.allData();
    cout<<"Enter all the data: "<<endl;
    t_day:
    cout<<"Day: "<<endl;
    cin>>c_d;
    if(c_d>=1&&c_d<=31)
    {
    	c_d=c_d;
	}
	else {
		cout<<"enter right day"<<endl;
		goto t_day;
	}
    t_mon:
    cout<<"Month: "<<endl;
    cin>>c_mon;
    if(c_d>=1&&c_d<=12)
    {
    	c_mon=c_mon;
	}
	else {
		cout<<"enter right month"<<endl;
		goto t_mon;
	}
    cout<<"Year: "<<endl;
    cin>>c_ye;
	Date c(c_d,c_mon,c_ye);
	c.allData();
	//setters 
	c.set_day(2);
	c.set_month(12);
	c.set_year(3330);
	c.allData();
	//getters 
	cout<<c.get_day();
	cout<<",";
	cout<<c.get_month();
	cout<<",";
	cout<<c.get_year();
	cout<<endl<<"by << operator"<<endl;
	cout<<a<<endl;
	cout<<b<<endl;
	a++;
	cout<<a<<endl;	
}
