
//Q4

#include<iostream>
using namespace std;

class month {
private:
    string name;
    int month_no;

public:
    string mn_arr[12] = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};

    month() {
        name = "January";
        month_no = 1;
    }

    month(string n) {
        name = n;
        for (int i = 0; i < 12; i++) {
            if (name == mn_arr[i]) {
                month_no = i + 1;
            }
        }
    }
    void get_month() {
        cout << "Month no#" << month_no << endl;
        cout << "Month name#" << name << endl;
    }

    void set_month() {
        cout << "Month no#" << endl;
        cin >> month_no;
        cout << "Month name#" << endl;
        cin >> name;
    }
    month& operator++() {
        if (month_no < 12)
            month_no++;
        else
            month_no = 1;
            name = mn_arr[month_no-1];
        return *this;
    }
      month& operator++(int) {
        if (month_no < 12)
            month_no++;
        else
            month_no = 1;
            name = mn_arr[month_no-1];
        return *this;
    }
      month operator--(int) {
        month temp(*this);
        if (month_no > 1)
            month_no--;
        else
            month_no = 12;
            name = mn_arr[month_no-1];
        return temp;
    }
       month operator--() {
        month temp(*this);
        if (month_no > 1)
            month_no--;
        else
            month_no = 12;
            name = mn_arr[month_no-1];
        return temp;
    }
    friend istream& operator>>(istream& is, month& obj);
    friend ostream& operator<<(ostream& os, const month& obj);
};

ostream& operator<<(ostream& os, const month& obj) {
    os << "Month no#" << obj.month_no << endl;
    os << "Month name#" << obj.name << endl;
    return os;
}

istream& operator>>(istream& is, month& obj) {
    cout << "Month no#" << endl;
    is >> obj.month_no;
    cout << "Month name#" << endl;
    is >> obj.name;
    return is;
}

int main() {
    month a;
    month b("February"); // Use double quotes for the month name
    a.get_month();
    cout << b << endl;
    cout << a << endl;
    month c;
    cin>>c;
    a++;
    cout << a << endl;
    ++a;
    cout << a << endl;
    a--;
    cout << a << endl;
    --a;
    cout << a << endl;
}
