//Raja Umer Saleem
//2023_CS_609
//Q1

#include<iostream>
using namespace std;
class fraction{
	private:
		int num;// numberator as num
		int denum;// denumberator as denum
		public:
				friend istream& operator>>(istream& is, fraction& obj);
			friend ostream& operator<<(ostream& os, const fraction& obj);
				
};
istream& operator >>(istream& is,  fraction& obj)
{
	cout<<"Enter numerator"<<endl;
	is>>obj.num;
	cout<<"Enter denumerator"<<endl;
	is>>obj.denum;
	
}
ostream& operator<<(ostream& os, const fraction& obj)
{
	os<<"Fraction"<<obj.num<<"/"<<obj.denum<<endl;	
	return os;
}
int main()
{
	fraction a;
	cin>>a;
	cout<<a;
}
//thankyou.. Ma,am Khola Naseen! for providing us this opportunity to learn about this..
