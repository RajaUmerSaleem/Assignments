#include <iostream>
using namespace std;

class Student {
public:
    int grades[3];

    Student(int g1, int g2, int g3) {
        grades[0] = g1;
        grades[1] = g2;
        grades[2] = g3;
    }

 
    Student() {
        grades[0] = 10;
        grades[1] = 20;
        grades[2] = 30;
    }

 
    double averagegrade() const {
        double sum = 0;
        sum=grades[0] + grades[1] + grades[2];
        return sum / 3.0;
    }
};
Student averagestudent(const Student stu[], int numstu) {
    if (numstu == 0) {
        return Student();
    }

    int totalgrade[3] = { 0 };

    for (int i = 0; i < numstu; i++) {
        totalgrade[0] = totalgrade[0] + stu[i].grades[0];
        totalgrade[1] = totalgrade[1] + stu[i].grades[1];
        totalgrade[2] = totalgrade[2] + stu[i].grades[2];
    }

    for (int i = 0; i < 3; i++) {
        totalgrade[i] = totalgrade[i] / numstu;
    }

    return Student(totalgrade[0], totalgrade[1], totalgrade[2]);
}

int main() {
  
    Student students[] = {
        {90, 80, 70},
        {85, 75, 65},
        {95, 85, 75} 
    };

    int numstudent = sizeof(students) / sizeof(students[0]);

    Student average = averagestudent(students, numstudent);
    cout << "Average grade: " << average.averagegrade() << endl;

    return 0;
}