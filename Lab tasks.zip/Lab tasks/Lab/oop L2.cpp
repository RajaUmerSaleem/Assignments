#include<iostream>
using namespace std;
 class book{
	private:
	string title;
	string author;
	int yr;
	public:
  book(string ti,string au,int ye)
	{
		title = ti;
		author = au;
		yr=ye;
		cout<<"---------------------"<<endl;
		cout<<"the title of book is "<<ti<<endl;
		cout<<"the Author of book is "<<au<<endl;	
		cout<<"the year of the book is "<<ye<<endl;
		cout<<"---------------------"<<endl;
	}
};
int main()
{
	book b1("Topper","Raja Umer Saleem",2023);
	book b2("DAnger","Raja Umer Saleem",2023);	
	book b3("Gorila","Raja Umer Saleem",2023);
	}

/*
#include<iostream>
using namespace std;
class personal{
	private:
	string name,address,phone,data;
	int age;
	public:
		personal(string na,string ad,string ph,int ag,string d)
		{
			name= na;
			address=ad;
			phone =ph;
			age=ag;
			data =d;
			cout<<d<<endl;
			cout<<"-----------------"<<endl;
			cout<<"Name:"<<na<<endl;
			cout<<"address:"<<ad<<endl;
			cout<<"Phone:"<<ph<<endl;
			cout<<"Age:"<<ag<<endl;
		}	
				
};
int main()
{
	string na,ad,ph;
	int ag;
	string d;
		string na1,ad1,ph1;
	int ag1;
	string d1;
		string na2,ad2,ph2;
	int ag2;
	string d2;
	cout<<" Data of"<<endl;
	cin>>d;
	cout<<" name"<<endl;
	cin>>na;
	cin.ignore();
	cout<<"address"<<endl;
	cin>>ad;
	cout<<"phone"<<endl;
	cin>>ph;
	cout<<"Age"<<endl;
	cin>>ag;
	cout<<" Data of"<<endl;
	cin>>d1;
	cout<<" name"<<endl;
	cin>>na1;
	cin.ignore();
	cout<<"address"<<endl;
	cin>>ad1;
	cout<<"phone"<<endl;
	cin>>ph1;
	cout<<"Age"<<endl;
	cin>>ag;
	cout<<" Data of"<<endl;
	cin>>d2;
	cout<<" name"<<endl;
	cin>>na2;
	cin.ignore();
	cout<<"address"<<endl;
	cin>>ad2;
	cout<<"phone"<<endl;
	cin>>ph2;
	cout<<"Age"<<endl;
	cin>>ag2;
	personal p1(na,ad,ph,ag,d);
	personal p2(na1,ad1,ph1,ag1,d1);
    personal p3(na2,ad2,ph2,ag2,d2);

}*/
/*
#include<iostream>
using namespace std;
class employee{
	private:
	string name;
	string id;
	int sa;
	public:
employee(string ti,string au,int ye)
	{
		name = ti;
		id = au;
		sa=ye;
	}
void show()
	{
	    cout<<"emloyee data "<<endl;
		cout<<"---------------------"<<endl;
		cout<<"name"<<name<<endl;
		cout<<"ID "<<id<<endl;	
		cout<<"Salary $"<<sa<<endl;
		cout<<"---------------------"<<endl;
	}
};
int main()
{
	employee e1("RAja umer","3231",20000);
	e1.show();
	}
	*/
	/*
	#include<iostream>
using namespace std;
class item{
	private:
	string name;
	int amount;
	int p;
	public:
item(string ti,int au,int ye)
	{
		name = ti;
		amount = au;
		p=ye;
	}
void show()
	{
	    cout<<"item "<<endl;
		cout<<"---------------------"<<endl;
		cout<<"name:"<<name<<endl;
		cout<<"amount "<<amount<<endl;	
		cout<<"price$ "<<p<<endl;
		cout<<"---------------------"<<endl;
	}
};
int main()
{
	item e1("product A",20,20000);
	e1.show();
	item e2("product B",50,100000);
	e2.show();
}	
	*/
	#include<iostream>
using namespace std;
class account{
	private:
	string name;
	int balance;
	public:
	 account(string n,int b )
	 	{
	 		name =n;
	 		balance=b;
		 }
		 void show()
		 {
		 	cout<<"Name:"<<name<<endl;
		 	cout<<"Balance: $"<<balance<<endl;
		 }
		 void deposit(int add)
		 {
		 	balance=balance+add;
		 	cout<<"Deposit Successful!!"<<endl;
		 	cout<<"current balance $"<<balance<<endl;
		 }
		 void sub(int sub)
		 {
		    balance=	balance-sub;
		 	cout<<"withdraw Successful!!"<<endl;
		 	cout<<"current balance $"<<balance<<endl;
		 }
	};
	int main()
	{
		string name;
		int balance;
		int n;
		int add;
		int sub;
		account c1("raja umer",1200);
		c1.show();
		cout<<"2:withdraw\n1:deposit"<<endl;
		cin>>n;
		if (n==1)
		{
			cout<<"Amount: "<<endl;
			cin>>add;
			c1.deposit(add);
		}
		else if (n==2)
		{
			cout<<"Amount: "<<endl;
			cin>>sub;
			c1.sub(sub);
		}
		else
		cout<<"write correct"<<endl;
	}
		 
	

	
	
