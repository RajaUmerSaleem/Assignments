// 1
/*#include<iostream>
using namespace std;
class car{
public:
string make ;
string model;
int year;
float price;

car()
{
	 make ="";
model="";
 year=0;
 price=0;
}
car(string ma,string m,int y,float p)
{
	 make =ma;
model=m;
 year=y;
 price=p;
}
void getdata()
{
	cout<<"maker:"<<make<<endl;
	cout<<"model:"<<model<<endl;
	cout<<"year:"<<year<<endl;
	cout<<"price:"<<price<<endl;
}
};
class Dealership{
car *Car;
public:
Dealership():Car(new car()){
}

void bookcar()
{
	string ma;
	string m;
	int y;
	float p;
		cout<<"maker:"<<endl;
		cin>>ma;
	cout<<"model:"<<endl;
		cin>>m;
	cout<<"year:"<<endl;
		cin>>y;
	cout<<"price:"<<endl;
		cin>>p;
		car Car(ma,m,y,p);
		Car.getdata();
		cout<<"enter car has booked"<<endl;
}
};

int main()
{
//Dealership a("toyota","2004",2024,100);
Dealership a;
a.bookcar();
}
*/
// 2
/*
#include <iostream>
#include <string>
using namespace std;
class Book{
private:
	string author;
	string title;
	string ISBN;
public:
	Book(){
	};
	Book(string t, string a, string isbn)
	{
		title=t;
		author=a;
		ISBN=isbn;
	}
	string fetch_til()
	{
		return title;
	}
	string getAuthor()
	{
		return author;
	}
	string getISBN()
	{
		return ISBN;
	}
};
class Reader
{
private:
	string name;
	int li_card;
	Book borrowed_books[10];
public:
	Reader(){};
	Reader(string naam, int card)
	{
		name=naam;
		li_card=card;
	}
	string getName() {
	return name;
	 }
	int getLibraryCardNumber()  {
	return li_card;
	}


	void borrowBook( Book& book) {
		for (int i = 0; i < 10; ++i) {
			if (borrowed_books[i].fetch_til() == "") {
				borrowed_books[i] = book;
				return;
			}
		}
		cout << "Cannot borrow more than 10 books." << endl;
	}
	void dbb()  {
		cout << "Borrowed Books:" << endl;
		for (int i = 0; i < 10; ++i) {
			if (borrowed_books[i].fetch_til() != "") {
				cout << "Title: " << borrowed_books[i].fetch_til() << "\n Author: " << borrowed_books[i].getAuthor() << "\n ISBN: " << borrowed_books[i].getISBN() << endl;
			}
		}
	}
};
class Library
{
private:
	string name;
	string location;
	int n_book;
	Book books[50];
public:
	Library(){};
	Library(string n, string l, int no_b)
	{
		name=n;
		location=l;
		n_book=no_b;
	}
	string getName()
	 {
	 return name;
	 }
	string getLocation()
	  {
	return location;

	 }

	int getNumbers() {
	 return n_book;
	  }
	void addBook( Book& book) {
		if (n_book < 50) {
			books[n_book] = book;
			n_book++;
		}
		else
		{
			cout << "Cannot add more than 50 books." << endl;
		}
	}
	void dld() {
		cout << "Library Name: " << name << endl;
		cout << "Location: " << location << endl;
		cout << "Number of Books: " << n_book << endl;
	}
};
int main() {
	Book b("calcus", "2", "5530");
	Reader r("raja umer", 123456);
	Library l("library", "Muridke library ", 0);
	 Book b2("multivariable", "CA", "475");
   l.addBook(b);
	r.borrowBook(b);
	l.dld();
	r.dbb();
}
*/

// 4
/*
#include<iostream>
using namespace std;
class floating{
private:
float *ptr=NULL;
public:
	int count;
floating( )
{

}
floating( int size)
{
	ptr=new float[size];
	count=size;
}
void save(float *p)
{
	for(int i=0;i<count;i++)
	{
	ptr[i]=p[i];
}

}
void dispay()
{
	for(int i=0;i<count;i++)
	{
	cout<<"numbers "<<ptr[i]<<endl;
}
}
void Max()
{
	float max=ptr[0];
		for(int i=0;i<count;i++)
	{
if(max<ptr[i])
{
	max=ptr[i];
}
   }
  cout<<"Maximum number "<<max<<endl;
  }
  void Min()
{
	float min=ptr[0];
		for(int i=0;i<count;i++)
	{
if(min>ptr[i])
{
	min=ptr[i];
}
   }
  cout<<"Maximum number "<<min<<endl;
  }
  void Avg()
{
	float avg =0.0;
		for(int i=0;i<count;i++)
	{

avg+=ptr[i];
   }
   avg/count;
  cout<<"avg "<<avg<<endl;
  }
};

int main()
{
	int size;
	cout<<"How many number you want to add "<<endl;
	cin>>size;
float *ptr=new float[size];
cout<<"Enter numbers "<<endl;
for(int i=0;i<size;i++)
{
	cin>>ptr[i];
}
floating a(size);
a.save(ptr);
a.dispay();
a.Max();
a.Min();
a.Avg();
}*/
// 5
/*
#include<iostream>
using namespace std;
//account
class Account{
public:
int ac_no;
double acc_balance;
Account()
{
}
Account(int n,double b)
{
ac_no=n;
acc_balance=b;
}
double deposit(double bal)
{
return acc_balance+=bal;
}
double withdraw(double bal)
{
return acc_balance-=bal;
}
double bal()
{
return acc_balance;
}
void display()
{
cout<<"Account Balance"<<acc_balance<<endl;

}
};
class saving
{
	private:
	Account *a;
	public:
	saving():a(new Account()){
}


void interest(){
cout<<"interest"<<a->bal()*1.1;
a->display();
}
};

int main()
{
	Account a(123,10000.0);
saving b;
b.interest();
a.deposit(20000);
a.display();
a.withdraw(100);
a.display();
}
*/
/*
#include<iostream>
using namespace std;
class Employee{
//private:

public:
	string name ;
double salary;
Employee()
{

	}
Employee(string nam, double sal)
{
	 name =nam;
salary=sal;
}
void display()
{
	cout<<"Name"<<name<<"Salary"<<salary<<endl;
}
};

class Manager: private Employee
{
	public:
	Manager()
	{

	}
	Manager(string nam, double sal)
{
	 name =nam;
	 salary=sal;
	// display();
}
void display1(){
	display();
}

};

int main()
{

Manager a ("Alice", 5000);
a.display1();
}
*/
/*
#include<iostream>
using namespace std;
class Person{
private:
string name;
int age ;
public:
person()
{
}
person(string n, int a)
{
	name= n;
	age=a;
}
void S_name()
{
cout<<"name";
cin>>name;
cout<<"age";
cin>>age;
}
void display()
{
cout<<"name"<<name<<","	<<"age"<<age<<endl;
}
void G_name()
{
cout<<"name"<<name<<","	<<"age"<<age<<endl;
}
};

class Student:public Person
{
public:
	Student()
	{

	}
void Setdata()
{
		S_name();
	display();

}
//void getdata()
//{
//
//}
};

int main()
{
Student a;
a.Setdata();
}
*/
/*
#include<iostream>
using namespace std;
class Animal{
public:
  virtual void sound()
 {
	cout<<"animal is speaking something"<<endl;
 }
};
class Dog : public Animal{
public:
 void sound() override
 {
	cout<<"BARking"<<endl;
 }
};
class Cat : public Animal{
public:
 void sound() override
 {
	cout<<"MEOw"<<endl;
 }
};
int main()
{
	Animal *c;
Dog a;
a.sound();
Cat b;
c=&a;
c->sound();
c=&b;
c->sound();
}
*/
/*
#include<iostream>
using namespace std;
class Vehicle{
public:
Vehicle()
{
	cout<<"Vehicle Constructor"<<endl;
}

~Vehicle()
{
	cout<<"Vehicle DesConstructor"<<endl;
}
};
class Car: public Vehicle{
public:
Car()
{
	cout<<"CAr Constructor"<<endl;
}
~Car()
{
	cout<<"Car DesConstructor"<<endl;
}
};
class bicycle: public Vehicle{
public:
bicycle()
{
	cout<<"bicyle Constructor"<<endl;
}
~bicycle()
{
	cout<<"bicyle DesConstructor"<<endl;
}
};
int main()
{
Vehicle a;
Car b;
bicycle c;
}*/

/*
#include<iostream>
using namespace std;
class Vehicle{
public:
 virtual void display()
 {
	cout<<" Driving the VEhicle "<<endl;
 }

};
class Car:public Vehicle
{
public:
void display()
 {
	cout<<" Driving the Toyota Car "<<endl;
 }
};

class Bus:public Vehicle
{
public:
void display()
 {
	cout<<" Driving the Volvo Bus "<<endl;
 }
};
class Truck:public Vehicle
{
public:
void display()
 {
	cout<<" Driving the Food truck "<<endl;
 }
};
int main()
{
Vehicle *v;
Car a;
Bus b;
Truck c;
v= &a;
v->display();
v= &b;
v->display();
v= &c;
v->display();
}
*/
/*
#include<iostream>
using namespace std;
class Employee{
//private:
public:
string name ;
double salary;
Employee()
{

}
Employee(string n,double sal)
{
name=n;
salary=sal;
}
void setdata(string n,double sal)
{
name=n;
salary=sal;
}

void getdata(string n,double sal)
{
cout<<"Name "<<name<<"Salary "<<salary<<endl;
}
};
class pe: public Employee{
public:

pe(string n,double sal)
{
name=n;
salary=sal;
}
double getdata()
{
	double bal;
	cin>>bal;
	return salary-bal;
}
};
class pc: public Employee{
public:
pc(string n,double sal)
{
name=n;
salary=sal;
}
double getdata()
{
		double bal;
	cin>>bal;
	return salary+bal;
}
};
int main()
{

pe a("raja",10000);
cout<<"salary"<<endl<<a.getdata();
pc b ("umer",25600);
cout<<"salary"<<endl<<b.getdata();
}
*/
/*
#include <iostream>

// Base class for all organisms
class Organism {
public:
	virtual void performAction() = 0;
	virtual ~Organism() {}
};

// Class representing a plant
class Plant : public Organism {
public:
	void performAction() override {
		std::cout << "Plant is photosynthesizing...\n";
	}
};

// Class representing an animal
class Animal : public Organism {
public:
	void performAction() override {
		std::cout << "Animal is hunting...\n";
	}
};

// Class representing the ecosystem
class Ecosystem {
private:
	Organism* organisms[100]; // Assuming a maximum of 100 organisms

public:
	// Constructor
	Ecosystem() {
		for (int i = 0; i < 100; ++i) {
			organisms[i] = NULL;
		}
	}

	// Destructor
	~Ecosystem() {
		for (int i = 0; i < 100; ++i) {
			delete organisms[i];
		}
	}

	// Method to add an organism to the ecosystem
	void addOrganism(Organism* organism) {
		for (int i = 0; i < 100; ++i) {
			if (organisms[i] == NULL) {
				organisms[i] = organism;
				return;
			}
		}
		std::cout << "Ecosystem is full. Cannot add more organisms.\n";
	}

	// Method to simulate the ecosystem
	void simulate() {
		for (int i = 0; i < 100; ++i) {
			if (organisms[i] !=NULL) {
				organisms[i]->performAction();
			}
		}
	}
};

int main() {
	// Create an instance of the ecosystem
	Ecosystem ecosystem;

	// Add some plants and animals to the ecosystem
	ecosystem.addOrganism(new Plant());
	ecosystem.addOrganism(new Plant());
	ecosystem.addOrganism(new Animal());
	ecosystem.addOrganism(new Animal());
	ecosystem.addOrganism(new Animal());

	// Simulate the ecosystem
	ecosystem.simulate();

	return 0;
}
*/

/*

#include<iostream>
#include<cstdlib>
#include "User.h"
using namespace std;
class book{
public:
string U_name;
static string Books[100];
int count ;
int ISBN[100];
void addBook()
{
	int size;
	int Rem;
	cout<<"Enter number book you Want to add"<<endl;
	cin>>size;
	Rem=count-size;
	if(Rem==0&&Rem>0)
	{
	string *B=new string[size];
		for(int i=0;i<size;i++)
		{
			cout<<"Enter book numbers"<<endl;
			cin>>B[i];
		Books[count+i]=B[i];
		ISBN[count+i]=(1+rand()%100)
		}
	}
	else
	{
		cout<<"Library has not enogh place "<<endl;
	}
}

void deleteBook()
{
	string name;
	cout<<"Enter name of book you want to delete"<<endl;
	cin>>name;
	for(int i=0;i<count;i++)
		{
		Books[count+i];
		}

}
};
//

class Book{
private:
string Title;
int ISBN;
bool availabilty;
public:
Book(String n, int i, bool av)
{
 Title =n;
 ISBN = i;
 availabilty= av;
}
void getdata()
{
	cout<<"Book name:"<<Title<<endl;
	cout<<"IBSN no#"<<ISBN <<endl;
	if (availabilty==1)
	{
		cout<<"Book is available"<<endl	;
		}
		else{
		cout<<"Book is unavailable"<<endl;

		}

		void setStatus(bool status)
		{
			availabilty=status;
		}
}
};
class library()
{
	private;
	Book mul[100];

	public:

}

int main()
{
cout<"_________________________________"<<endl;
cout<<"Library Management System"<<endl;
cout<"_________________________________"<<endl;
}

//#include<iostream>
//using namespace std;
//int main()
//{
//    cout<<"Bro!! You are winning "<<endl;
//}
*/
/////task 1

/*
#include<iostream>
using namespace std;
class Book{
private:
string Title;
string Author;
string  ISBN;
bool availabilty;
public:
Book(String n,string A ,string i, bool av){
 Title =n;
 Author=A;
  ISBN = i;
 availabilty= av;
}
void display()const
{
	cout<<"Book name:"<<Title<<endl;
	cout<<"IBSN no#"<<ISBN <<endl;
	if (availabilty==1)
	{
		cout<<"Book is available"<<endl	;
		}
		else{
		cout<<"Book is unavailable"<<endl;

		}

		void setStatus(bool status)
		{
			availabilty=status;
			return availabilty;
		}
}
};
class LiberyUser{
private:
string name;
int ID;
	public:
		LiberyUser()
		{

		}
			LiberyUser(string n,int i)
		{
			name=n;
			ID=i;
		}
	void display()const
	{
		cout<<"name :"<<name<<endl;
		cout<<"ID: "<<ID<<endl;
	}
};
class LibraryItem{
protected:
string title;
bool available;
public:
 LibraryItem(string t,bool a)
 {
	title=t;
	available=a;
 }
 void getter()
 {
	cout<<"Titile "<<title<<endl;
	if (available==1)
	{
		cout<<"Book is available"<<endl	;
		}
		else{
		cout<<"Book is unavailable"<<endl;

		}

		bool asetStatus(bool status)
		{
			available=status;
			return available;

		}
}
};
class BookItem:LibraryItem{
private:
string ISBN;
public:
void show()
{
	getter();
	cout<<"Isbn"<<ISBN<<endl;
}
};
class DVD:LibraryItem{
private:
string director;
public:
void show()
{
	getter();
	cout<<"director"<<director<<endl;
}
};

int main()
{

Book a("Topper","raja","656",true);
a.display();
LibraryItem *p;
p->getter();
//LiberyUser b;
////p=&b;
//b.display();
//DVD c;
//c.getter();
//p=&c;
//}
}*/
//
//
// #include <iostream>
// #include <string>
//
// using namespace std;
//
// class Employee {
// protected:
//    string name;
// public:
//    Employee(const string& name) : name(name) {}
//
//    virtual double calculateSalary() const = 0;
//
//    virtual void display() const {
//        cout << "Employee Type: ";
//    }
//};
//
// class HourlyEmployee : public Employee {
// private:
//    double hourlyRate;
//    double hoursWorked;
// public:
//    HourlyEmployee(const string& name, double hourlyRate, double hoursWorked)
//        : Employee(name), hourlyRate(hourlyRate), hoursWorked(hoursWorked) {}
//
//    double calculateSalary() const override {
//        return hourlyRate * hoursWorked;
//    }
//
//    void display() const override {
//        Employee::display();
//        cout << "Hourly Employee" << endl;
//    }
//};
//
// class SalariedEmployee : public Employee {
// private:
//    double monthlySalary;
// public:
//    SalariedEmployee(const string& name, double monthlySalary)
//        : Employee(name), monthlySalary(monthlySalary) {}
//
//    double calculateSalary() const override {
//        return monthlySalary;
//    }
//
//    void display() const override {
//        Employee::display();
//        cout << "Salaried Employee" << endl;
//    }
//};
//
// int main() {
//    HourlyEmployee hourlyEmp("John Doe", 20.0, 40.0);
//    SalariedEmployee salariedEmp("Jane Smith", 4000.0);
//
//    cout << "Employee Information:" << endl;
//    hourlyEmp.display();
//    cout << "Name: "<<hourlyEmp.display() << ", Salary: $" << hourlyEmp.calculateSalary() << endl;
//
//    salariedEmp.display();
//    cout << "Name: " << salariedEmp.display() << ", Salary: $" << salariedEmp.calculateSalary() << endl;
//
//    return 0;
//}
/*
#include<iostream>
#include<string>
using namespace std;
class employee
{
protected:
	string name;
public:
	employee(const string& n):name(n){}
	virtual double calculatesalary()
		const = 0;
	string getname()
	{
		return name;
	}
	virtual void display() const {
		cout << "Employee : " <<name<< endl;
	}

};
class hourlyemployee :public employee
{
private:
	double hourlyrate;
	double hoursworked;
public:
	hourlyemployee(const string &n,double hr,double hw):employee(n),hourlyrate(hr),hoursworked(hw){}
	double calculatesalary() const override
	{
		return hourlyrate * hoursworked;
	}
	void display() const override
	{
		employee::display();
		cout << "hourly employee. "<<endl;
	}
};
class salariedemployee :public employee
{
private:
	double monthlysalary;
public:
	salariedemployee(const string &n,double ms):employee(n),monthlysalary(ms){}
	double calculatesalary() const override
	{
		return monthlysalary;
	}
	void display() const override
	{
		employee::display();
		cout << "salaried employee. "<<endl ;
		}
};
int main()
{
	hourlyemployee he("ali",10.0,15.6);
	he.display();
	salariedemployee se("zain", 10.9);
	se.display();
	employee* a;
	a = &he;
	a->display();
	cout << "Salary is : " << a->calculatesalary() << endl;
	a = &se;
	a->display();
	cout << "Salary is : " << a->calculatesalary() << endl;
	return 0;
}*/
/*
#include<iostream>
using namespace std;
class Book{
//private:
public:
string name;
string author
string ISBN;
bool ava;
Book(string b_nam,string b_a,string Ib)
{
name=b_nam;
author=b_a;
ISBN=Ib;
}

void display_name()
{
	cout<<"Book "<<name<<endl;
	cout<<"Athor "<<author<<endl;
	cout<<"ISBN"<<ISBN<<endl;

}
};
class User{
//private:
string u_name;
public:
	User(string n)
	{
		u_name=n;
	}
void display_book(Book &obj){
	obj.display_name();
}
};
class libraian:User{
public:
string a_bn;
string a_a;
string a_I;
bool a_ava;
static count;
	void add_book()
	{
		int ad_no;
		cout<<"how many books you want to add "<<endl;
		cin>>ad_no;
		Book *Bookptr=new Book[ad_no];
		for(int i=0;i<ad_no;i++)
		{
			ignore.cin;
			cout<<"enter name of book "<<endl;
			getline(cin,a_bn);
			cout<<"enter Author of book "<<endl;
			getline(cin,a_a);
			cout<<"enter  ISBN of book "<<endl;
			getline(cin,a_I);
			cout<<"Enter Availability of book "<<endl;
			cin>> a_ava;
		Bookptr[0].Book(a_bn,a_a,a_I,a_ava);

	}
}
};
int libraian::count=0;
class Student: public User {
	public:
string S_name;
	Student(string n)
	{
		S_name=n;
	}
void borrow() {
string a_bn;
string book_AU;
string b_is;

	cout<<"Enter book name: "<<endl;
	cin>> a_bn;
cout<<"Book author "<<endl;
cin>> book_AU;
cout<<"Book ISBN "<<endl;
cin>> b_is;
}
*
*/
/*
#include<iostream>
using namespace std;
class Book{
private:
string name;
string author;
string ISBN;
bool ava;
public:
Book()
{
}
Book(string b_nam,string b_a,string Ib,bool av)
{
name=b_nam;
author=b_a;
ISBN=Ib;
ava=av;
}
void display_name()
{
	cout<<"Book "<<name<<endl;
	cout<<"Athor "<<author<<endl;
	cout<<"ISBN"<<ISBN<<endl;
	if (ava==false)
	{
		cout<<"Status : Borrowed"<<endl;
	}
	else
	if (ava==true)
	{
		cout<<"Status : Available"<<endl;
	}
}
void changeStatus(Book *ptr,int arrc)
{
	string Ch_name;
	cout<<"enter name of book "<<endl;
	cin>>Ch_name;
	cin.ignore();
	for(int i=0;i<arrc;i++)
	{
		if(Ch_name==ptr[i].name)
		{
	cout<<"Enter Book status"<<endl;
	cin>>ptr[i].ava;
		}
	}
}
};
void header(){
	 cout<<"-----------------------------"<<endl;
	cout<<"  Library Management System  "<<endl;
	cout<<"-----------------------------"<<endl;
}
int main()
{
	int size;
	int counter=0;
	string choice = "y";
header();
string a_bn;
string a_a;
string a_I;
bool a_ava;
// 	Book *bookptr=NULL;
	cout<<"Enter book , no you want to add"<<endl;
	cin>>size;
	Book *bookptr=new Book[size];
		while(choice!="n"&&choice=="y")
		{
			cin.ignore();
			cout<<"enter name of book "<<endl;
			getline(cin,a_bn);
			cout<<"enter Author of book "<<endl;
			getline(cin,a_a);
			cout<<"enter  ISBN of book "<<endl;
			getline(cin,a_I);
			cout<<"Enter Availability of book "<<endl;
			cin>> a_ava;
		bookptr[counter++]=Book(a_bn,a_a,a_I,a_ava);
		cout<<"Enter choice:"<<endl;
		cin>>choice;
		}
		for(int i=0;i<counter;i++)
		{
		bookptr[i].display_name();
		}
		choice= "";
		cout<<"Is you to want update book status "<<endl;
		cin>>choice;
		if (choice=="y"){
		bookptr->changeStatus(bookptr,counter);
		}
			for(int i=0;i<counter;i++)
		{
		bookptr[i].display_name();
		}
		delete[]  bookptr;
}*/

#include <iostream>
#include <string>
class student
{
private:
	int studentId;
	string Sname;

public:
	student()
	{
	}
	student(int id, string n)
	{
		studentId = id;
		Sname = n;
	}
	int getStudentId()
	{
		return studentId;
	}
	string getStudentName()
	{
		return Sname;
	}
};

class Teacher
{
private:
	int teacherID;
	string Tname;
	string Texerpt;

public:
	Teacher()
	{
	}
	Teacher(string T, int tID, string Tex)
	{
		Tname = T;
		teacherID = tID;
		Texpert = Tex;
	}

	string getTeacherN()
	{
		return Tname;
	}
	string getTeacherEx()
	{
		return Texpert;
	}
	int getTeacherId()
	{
		return teacherID;
	}
};
class Class
{
private:
	int ClassId;
	string Cname;
	student s[];
	Teacher t;

public:
	Class(int Cid, string Cn, student as[], Teacher at, int limit)
	{
		ClassId = Cid;
		Cname = Cn;
		for (int i = 0; i < limit; ++i)
		{
			s[i] = as[i];
		}
		t = at;
	}
	int getClassId() const
	{
		return ClassId;
	}
	string getClassName() const
	{
		return Cname;
	}
	Student getStudents()
	{
		return s;
	}
	Teacher getTeacher() const
	{
		return t;
	}
};

using namespace std;
int main()
{
	int limit;
	cout << "Number of student class" << endl;
	cin >> limit;
	student list[limit];
	cout << "enter student data of this class" << endl for (int i = 0; i < limit; i++)
	{
		string s_a;
		int stid;
		cout << "Student Name: " << endl;
		cin >> s_a;
		cout << "Student ID : " << endl;
		cin >> stid;

		list[i] = student(s_a, stid);
	}
	s_a = "";
	stid = 0;
	Teacher Classinch;
	cout << "Enter teacher data " << endl;
	cout << "Teacher name " << endl;
	cin >> s_a;
	cout << "Teacher id " << endl;
	cin >> stid;
	Classinch = Teacher(s_a, stid);
	Class a(1, "PG", list[], Classinch, limit);
	cout << a.getClassId();
	cout << a.getClassName();
	for (int i = 0; i < limit; i++)
	{
		cout << "Student ID: " << a[i].getStudents().getStudentId();
		cout << "Student Name: " << a[i].getStudents().getStudentName();
	}
	cout << "Teacher name" << a.getTeacher().getTeacherN();
	cout << "Teacher ID" << a.getTeacher().getTeacherId();
	cout << "Teacher Qualification :" << a.getTeacher().getTeacherEx();
	delete[] list;
}
