#include<iostream>
using namespace std;
int main()
{
	int v,len,w,h;
	cout << "Enter length,width and heigth to evaluate the volume of the box."<<endl;
	cout <<"Enter the length:";
	cin>>len;
	cout <<"Enter the width:";
	cin>>w;
	cout <<"Enter the heigth:";
	cin>>h;
	v=len*w*h;
	cout<<"volume of the box is "<<v;
	return 0;
}
