 /*#include<iostream>
using namespace std;
int main() {
	int game=1;
	int points;
	int total=0;

	while(points!=-1)
{
	cout<<"game"<<game<<" points are";
	total+=points;
	cin>>points;
	game++;
	}	
	cout<<" total points are :" << total;		
}*/
/*
#include<iostream>
using namespace std;
int main()
{
	int a;
	int r;
	cout<<"Enter the number";
	cin>>a;
	int n=1;
	while(n<=5)
	{
		 r=1;
		for(int j=1;j<=n;j++)
		{
			r=r*a;
			cout<<r<<"\t";
		}
		cout<<endl;
		n++;
	}
	return 0;
}*/
/*
#include<iostream>
using namespace std;
void month(int n)
{
	switch(n)
	{
		case 1:
			cout<<"feb ";
			break;
			case 2:
			cout<<"jan ";
			break;
				case 3:
			cout<<"march ";
			break;	
				case 4:
			cout<<"april ";
			break;
				case 5:
			cout<<"may ";
			break;
			default:
				cout<<"it is greater than 5";
	}
}
int main()
{
	int c;
	cout<<"enter the month no to check its days no. and name";
	cin>>c;
	month(c);
	if(c==4||c==6||c==9||c==11)
	cout<<"is 30 days month";
	else if(c==1||c==3||c==5||c==7||c==8||c==10||c==12)
	cout<<"is 31 days month ";
	else 
	cout<<"is 28 or 29 days month ";
	
return 0;
}*/
/*
#include<iostream>
using namespace std;

int main()
{
	char n;
	while(n!=-1)
	{
	cout<<"enter a chracter "<<endl;
	cin>>n;
	if(n<='Z'&&n>='A')
{
		cout<<n<<" is capital letter "<<endl;
	cout<<n<<" ASCII is"<<int (n)<<endl;
}
	else if(n<='z'&&n>='a')
{
		cout<<n<<" is small letter "<<endl;
	cout<<n<<" ASCII is"<<int (n)<<endl;
}
	else if(n<='9'&&n>='0')
	{
	cout<<n<<" is ";
	if(n%2==0)
cout<<"even number letter "<<endl;
else 
cout<<"odd number letter "<<endl;
		cout<<n<<"ASCII is"<<int (n)<<endl;
	}
	else 
	cout<<"chill maar jani in\n mai se koi b ni hn";
	}
}*/
/*
#include<iostream>
using namespace std;
int pnum(int n)
{
	for(int j=1;j<=n;j++)
	{
		int r;
	
		for(int c=1;c<=j;c++)
		{
			if(j%c==0)
			r++;
		}
			if(r==2)
			cout<<j<<" is prime no "<<endl;
			r=0;
	}
	return 0;
}
int main()
{
int v=pnum(100)	;
cout<<v;
	return 0;
}*/
/*
#include<iostream>
using namespace std;
int main()
{
	int c ;
	cout<<"entre the choice no\n1 for check\n2 for   "
	*/
	#include<> 
