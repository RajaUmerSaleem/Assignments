#include<iostream>
using namespace std;
int main() {
	cout<<"A carpentor campany makes cerates write lenth , \nwidth, heigth of that cerate to find his profit\nvolume and his cost:\n\n";
	double len, wth,heigth,volume,cost,charge,pro;
	cout<<"Enter the length :\n";
	cin>>len;
    cout<<"Enter the width :\n";
	cin>>wth;
	cout<<"Enter the heigth :\n";
	cin>>heigth;
	volume = len*wth*heigth;
	cost=volume*0.23;
	charge=volume*0.5;
	pro=charge-cost;
	cout<<"\nThe volume is:"<<volume<<endl;
	cout<<"The charge is $"<<charge<<endl;
	cout<<"The cost is$"<<cost<<endl;
	cout<<"The profit is$"<<pro<<endl;	
}
