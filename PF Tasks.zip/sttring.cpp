#include<iostream>
#include<cstring>
using namespace std;
 int main() 
 {
char first[30],second[30];
cin.getline(first,30);
cin.getline(second,30);
cout<<(first==second);
}

