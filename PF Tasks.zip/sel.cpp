#include<iostream>
using namespace std;
int main()
{
	int n , w;
	float p,kg,g,o;
	char in;
	cout<<"Enter weigth of choclates";
	cin>>w;
	cout<<"Enter number of choclates";
	cin>>n;
	cout<<"press O for ounce weigth"<<endl;
	cout<<"press P for  pounds weigth"<<endl;
	cout<<"press G for  grams weigth"<<endl;
	cout<<"press K for Kilograms weigth"<<endl;	
	cin>>in;
	if(in=='O')
	{
		o=w*n*28.3495;
		cout<<o<<"ounces";	
	}
	else	if(in=='P')
			{
		p=w*n*16*28.3495;
		cout<<p<<"pounds";
		
	}
	else		if(in=='G')
					{
		p=w*n*0.03527;
		cout<<p<<"grams";
		
	}
		else		if(in=='K')
	
					{
		p=w*n*35.2858;
		cout<<p<<"Kilograms";
		
	}
	return 0;
}
