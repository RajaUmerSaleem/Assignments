/*#include<iostream>
using namespace std;
void freq(int arr[10],int fre[10],int maxfre=0)
{
	int maxnum;
	for(int i=0;i<9;i++)
{ 
//if(arr[i]==arr[i+1])
fre[arr[i]]++;
if(fre[arr[i]]>maxfre)
{
maxfre=fre[arr[i]];
maxnum=arr[i];
	
}
}
cout<<"frequency is"<<maxfre<<endl;
cout<<"frequent number"<<maxnum<<endl;
}
int main()
{
	int maxnum;
	int maxfre=0;
	int fre[10]={0};
	int arr[10];
for(int i=0;i<10;i++)
{
	cin>>arr[i];
}
for(int i=0;i<10;i++)
{
	cout<<arr[i]<<"\t";	
}
//for(int i=0;i<9;i++)
//{ 
//if(arr[i]=arr[i+1])
//fre[arr[i]]++;
//if(fre[arr[i]]>maxfre)
//{
//maxfre=fre[arr[i]];
//maxnum=arr[i];
//	
//}
//}
//cout<<"frequency is"<<maxfre<<endl;
//cout<<"frequent number"<<maxnum<<endl;
freq(arr,fre,maxfre);
}*/
/*
#include<iostream>
using namespace std;
int main()
{
	int sum=0;
	int m1[3][3];
	int m2[3][3];
	int res[3][3];
	
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<3;j++)
		{
		
	cin>>m1[i][j];
		}

	}
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<3;j++)
		{
		
	cin>>m2[i][j];
		}
	}
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<3;j++)
		{
			sum=0;
			for(int k=0;k<3;k++ )
			{
				sum=sum+m1[i][k]*m2[k][j];
			}
			res[i][j]=sum;
		}
	}
	cout<<"matrix 1"<<endl;
		for(int i=0;i<3;i++)
	{
		for(int j=0;j<3;j++)
		{
		
		cout<<m1[i][j]<<" ";
		}
		cout<<endl;
	}
	cout<<"matrix 2"<<endl;
		for(int i=0;i<3;i++)
	{
		for(int j=0;j<3;j++)
		{
		
		cout<<m2[i][j]<<" ";
		}
		cout<<endl;
	}
	cout<<"matrix resultant"<<endl;
	for(int i=0;i<3;i++)
	{
		for(int j=0;j<3;j++)
		{
		
		cout<<res[i][j]<<" ";
		}
		cout<<endl;
	}
}*/
/*
#include<iostream>
using namespace std;
int main()
{
	int c=0;
	int length=10;
	char arr[10];
	for(int i=0;i<10;i++)
	for(int i=0;i<10;i++)
	{
		cin>>arr[i];	
	}
		for(int i=0;i<10;i++)
	{
		if(arr[i]==' '||arr[i]==','||arr[i]=='.')
		{
			length--;
			c++;
		}
	}
	cout<<"the length of sting"<<length<<endl;
	cout<<"the words in string"<<c<<endl;
}*/
/*
#include<iostream>
#include<string>
using namespace std;
struct cacount{
    string name;
    int no;
    double balance,interest;
};
int main()
{
    cacount c1={"Joason Miller",17328910,24476.34,2.5};
        cout<<"Acount holder: "<<c1.name<<endl;
        cout<<"account no: "<<c1.no<<endl;
         cout<<"balance: "<<c1.balance<<endl;
          cout<<"interest:  %"<<c1.interest<<endl;
         cout<<endl;
    }*/	
    /*
#include<iostream>
#include<string>
using namespace std;
struct reading{
    int wind;
	double humid;
};
struct tempscale{
	reading a;
    double f,c;
};
int main()
{
	tempscale v={{37,32},32,0}
	cout<<"Wind Speed"<<v.a.wind<<endl;
	 cout<<"Humidity"<<v.a.humid<<endl;
	 cout<<"Fahrenheit temperature"<<v.f<<endl;
	 cout<<"Centigrade temperature"<<v.c<<endl;
}*/
#include<iostream>
#include<string>
#include <cstdlib>
#include<fstream> 
#include<cstddef> 
using namespace std;
struct item{
	string itn;
	double q;
	double wcost;
	double rcost;
	string date;
};
void add(item it[],int n,fstream &file)
{
	for(int i=0;i<n;i++)
	{
		cout<<"Enter item name:";
		cin>>it[i].itn;
		cout<<endl;
		cout<<"Enter item on hand quantity:";
		cin>>it[i].q;
		cout<<endl;
		cout<<"Enter item wholesale cost:";
		cin>>it[i].wcost;
		cout<<endl;
		cout<<"Enter item retail cost:";
		cin>>it[i].rcost;
		cout<<endl;
		cout<<"Enter date:";
		cin>>it[i].date;
		cout<<endl;
	}
	for(int i=0;i<n;i++)
	{
		file<<it[i].itn<<" "<<it[i].q<<" "<<it[i].wcost<<" "<<it[i].rcost<<" "<<it[i].date<<endl;
	}
}
void copy(fstream &file)
{
	    fstream file1;
	    string iname;
        double quantity,wholesale,retail;
        string date;
file.open("file.txt",ios::in);
file1.open("file1.txt",ios::out);
while(file>>iname>>quantity>>wholesale>>retail>>date)
{
{
		file1<<iname<<","<<quantity<<","<<wholesale<<","<<retail<<","<<date<<endl;
	}
	if(file.eof())
break;
}
file.close();
file1.close();
}
int main()
{
	char ch;
//	int n;
//	 string iname;
//     double quantity,wholesale,retail;
//     string date;
	string temp="";
//	cout<<"how many records you want to add";
//	cin>>n;
//	item *it = new item[n];
	fstream file,file1,file2;
//file.open("file.txt",ios::out);
//add(it,n,file);
//file.close();
//copy(file);
file1.open("file1.txt",ios::in);
file2.open("file2.txt",ios::out);
for(int i=0;i<2;i++)
{
	if(ch!=',')
{
	file1>>ch;
	temp+ch;
	}
else
{
file2<<temp<<" ";
temp="";
}
	if(file.eof())
break;
}
file1.close();
file2.close();	
return 0;
}











