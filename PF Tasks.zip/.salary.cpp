#include<iostream>

using namespace std;
int main()
{
double b ,tot,anu;
cout<<"Enter the Ali,s basic salary:\t";
cin>>b;
tot=b+(b*55/100);
anu=tot*12;
cout<<"Gross month Salary:\t"<<tot<<endl;
	cout<<"Gross annual Salary\t"<<anu<<endl;
	return 0;
}
