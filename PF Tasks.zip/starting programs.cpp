#include<iostream>
using namespace std;
int main()
{
int x,y,c,a,mu,s,d,mo;
cout<<"Enter  1st Number: ";
cin>>x;
cout<<"Enter  1st Number: ";
cin>>y;
cout<<"Press 1 for Addition"<<endl; cout<<"Press 2 for multiply"<<endl;
cout<<"Press 3 for subtraction"<<endl;
cout<<"Press 4 for division"<<endl;
cout<<"Press 5 for modulus"<<endl;
cin>>c;

if(c==1)
{
	a=x+y;
cout<<a;
}

else if(c==2)
{
	mu=x*y;
cout<<mu;
}
else if (c==3)
{
	s=x-y;
cout<<s;
}
else if (c==4)
{
	d=x/y;
cout<<d;
}
else if(c==5)
{
	mo=x%y;
cout<<mo;
}
else
cout<<"enter a valid number";
return 0;
}
