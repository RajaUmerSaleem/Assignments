/*#include<iostream>
using namespace std;
void palindrome(int a)
{
	int b,c,d;
	b=a/100;
	c=(a/10)%10;
	d=(a%100)%10;
	if (b==d)
	cout<<" it is a palindrome"<<endl;
	else 
	cout<<"it is not a palindrome";
	
	}
	int main()
	{
	 	int a;
		cin>>a;
		palindrome(a);
	}
	*/
/*
#include<iostream>
using namespace std;
int main()
{
 int sum=0;
int c=0;
	int a;
	cin>>a;
	int num=0;
   while(a!=0)
   {
   	num=a%10;
   	sum=sum+num;
    c++;
   	a=a/10;
   }
   cout<<sum;
   sum=sum-1;
   for(int i=1; i<=sum;i++)
   {
   if(sum%i==0)
  c++;
}
if (c==2)
cout<<endl<<"it is prime no";
cout<<"it is a funny no";
   
}
*/
 
/*
#include<iostream>
using namespace std;
int main()
{
 int sum=0;
int c=0;
	int a,x,y;
	cin>>a;
	int num=0;
   while(a!=0)
   {
   	num=a%10; 
   	sum=sum+num;
   	c++;
   	x=sum;
   	if (c==2)
   	sum=0;
   	a=a/10;
   }
   y=x-sum;
   cout<<sum;
}*/


	
	


