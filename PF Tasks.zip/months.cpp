#include<iostream>
using namespace std;
int main()
{
int td,y,m,w,d;
	
cout<<"Enter number of days";
cin>>td;
y=td/365;
td=td%365;
m=td/30;  //30days in one month
td=td%30;
w=td/7;  //7days in one week
td=td%7;
d=td;
cout<<"No. of years :"<<y<<endl;
cout<<"No. of months :"<<m<<endl;
cout<<"No. of week :"<<w<<endl;
cout<<"No. of days :"<<d<<endl;
return 0;	
}	


