//cases problem to find sum , muptily, division,modulus
/*#include<iostream>
using namespace std;
int main()
{
int x,y,c,a,mu,s,d,mo;
cout<<"Enter  1st Number: ";
cin>>x;
cout<<"Enter  1st Number: ";
cin>>y;
cout<<"Press 1 for Addition"<<endl; 
cout<<"Press 2 for multiply"<<endl;
cout<<"Press 3 for subtraction"<<endl;
cout<<"Press 4 for division"<<endl;
cout<<"Press 5 for modulus"<<endl;
cin>>c;

if(c==1)
{
	a=x+y;
cout<<a;
}

else if(c==2)
{
	mu=x*y;
cout<<mu;
}
else if (c==3)
{
	s=x-y;
cout<<s;
}
else if (c==4)
{
	d=x/y;
cout<<d;
}
else if(c==5)
{
	mo=x%y;
cout<<mo;
}
else
cout<<"enter a valid number";
return 0;
}*/


//salary 
//gross monthly and per anum 
/*#include<iostream>

using namespace std;
int main()
{
double b ,tot,anu;
cout<<"Enter the Ali,s basic salary:\t";
cin>>b;
tot=b+(b*55/100);
anu=tot*12;
cout<<"Gross month Salary:\t"<<tot<<endl;
	cout<<"Gross annual Salary\t"<<anu<<endl;
	return 0;
}*/
/*
//triangle ,finding right ,acute and scalene .
#include<iostream>
using namespace std;
int main()
{
int a,b,c;
cin>>a;
cin>>b;
cin>>c;
if(a+b+c==180)
{
	cout<<"valid triangle";
	
	
	if(a<90&&b<90&&c<90)
{
	cout<<" acute";
}
if(a!=b&&b!=c&&c!=a)
{	
	cout<<" scalene";
}
if(a==90||b==90||c==90)
{
	cout<<" right trangle";
	}
if(a==60&&b==60&&c==60)
{
	cout<<" equilateraltrangle";  
}

}
else 
	cout<<"invalid triangle ";

return 0;
}   */
/*
//input name, department , year 
#include<iostream>
using namespace std;
int main()
{
string myname;
	int fy,sy;
	
	cout<<"enter your name";
	//TO CIN NAME 
getline(cin,myname);
	cout<<"enter your first year marks";
	cin>>fy;
	cout<<"enter your second year marks";
	cin>>sy;
	cout<<myname<<"your first year marks"<<fy<<endl;
	cout<<"  your second year marks"<<sy<<endl;
	return 0;
}*/

//palindrome 
/*
#include<iostream>
using namespace std;
int main()
{
	int a,b,c,d;
	cout<<"Enter a Number to check it is Palindrome or not ? : ";
	cin>>a;
	b=(a/100);
	c=(a/100)%10;
	d=(a%100)%10;	
	if(b==d)
	  	cout<<" Palindrome " ;
	  	else
	  		cout<<" not Palindrome " ;
	  		return 0;
	  	}*/

//axis quadrent or orign and in quad 
/*
#include<iostream>
#include<string>
using namespace std;
int main()
{
	int x,y;
	cout<<"Enter x value ";
cin>>x;
cout<<"Enter y value  ";
cin>>y;
if (x==0)
  if (y==0)
cout<<"lies on origin";
else
{
	if(y>0)
     	cout<<"on +ve y-axis";
	else
      	cout<<"on -ve y-axis";
    
  }  
  else
  {
  	if(y==0)
  	 if(x>0)
  	 cout<<"on +ve x-axis";
	else
      	cout<<"on -ve x-axis";
      	else
      	{
      		if(y>0)
      		 if (x>0)
      		 cout<<"quad 1";
      		 else
      		  cout<<"quad 2";
      		  else
      		  {
      		  	if (x>0)
      		  	cout<<"quad 4";
      		 else
      		  cout<<"quad 3";
				}
		  }
     	 
  }
  return 0;
}
