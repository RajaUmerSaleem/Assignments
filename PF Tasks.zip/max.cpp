#include<iostream>
using namespace std;
/*int large(int a,int b) 
{
	int max;
	if (a>b)
	{
		max=a;
	}
	else
	max=b;
	return max;
}

int main() 
{
	int x,y;
cout<<"enter two no";
cin>>x>>y;
int max = large(x,y);
cout<<max;
}*/
//int a;
/*
bool prime(int a)
{
	int c;
	for (int i=1 ;i<=a;i++)
	{
if(a%i==0)
	c++;
	}
	if (c==2)
	return true;
	else
	return false;
}
int main() 
{
	int x;
	cout<<"enter a no:";
	cin>>x;
	bool res;
	res = prime(x) ;
	cout << res;
	return 0;
}*/
/*
int p(int a,int b)
{
	int per=1;
	for (int i=1 ;i<=b;i++)
	{
	   per =per*a;
	}
	int power = per;
	return power;
}
int main()
{
	int x,y;
cout<<"enter  no and poer";
cin>>x>>y;
int power =p(x,y);
cout<<power;
}*/

/*void str (int  x)
{
	for(int i =1 ;i<=x;i++)
	{

	for(int j =1 ;j<i;j++)
		cout<<" ";
	for(int k =9;k>= 2*i-1;k--)
			cout<<"*";
		cout<<endl;
	}
}*/
/*void str (int  x)
{
	for(int i =x ;i>=1;i--)
	{

	for(int j =1 ;j<x-i;j++)
		cout<<" ";
	for(int k =1;k>= 2*i-1;k++)
			cout<<"*";
		cout<<endl;
	}
}
int main()
{
	int a;
	cin>>a;
str( a);
}*/
void rec (int r)
{ 
for ( int i=1 ; i<=r; i++ )
{
	for(int j=1; j<=r*2 ;j++ )
	{
		
	if(i==1||i==r||j==1||j==r*2)
	cout<<"*";
	else 
	cout<<" ";
	}
	cout<<endl;
}
}

/*int main ()
{
	int row ;
	cin>>row;
rec(row);
	}*/
	
void menu()
{
cout<<"enter 1";
}
int main()
{
	int c,r;
	menu();
	cin>>c;

	switch(c)
	{
		case 1:
			cin>>r;
		rec (r);
	}
}
	

