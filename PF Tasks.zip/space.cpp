#include<iostream>
#include<iomanip>
using namespace std;
int main() {

int y=10;
cout<<setw(10)<<y;
}

