#include<iostream>
using namespace std;
int main() {
int begInv, store1, store2, store3,sold;	
cout<<"one week ago , 3 stores opened.those had\nsame numbers of widgets in inoventory \nafter  sold wigdets, the final widgets\nin inoventory?\n\n";
cout<<"----------(INOVENTRIES)------------\n\n";
cout<<"Entre the number of begnin inoventries?\n\t ";
cin>>begInv;
store1=store2=store3=begInv;
cout<<"\n----------(sold widgets)----------\n";
cout<<"\nEnter the sold widgets in store1:\n\t ";
cin>>sold;
store1-=sold;
cout<<"Enter the sold widgets in store2:\n\t ";
cin>>sold;
store2-=sold;
cout<<"Enter the sold widgets in store3:\n\t ";
cin>>sold;
store3-=sold;
cout<<"----------(FINAL INOVENTRIES)---------\n\n";
cout<<"\nFinal inoventories in store1:\n\t "<<store1<<endl;
cout<<"Final inoventories in store2:\n\t "<<store2<<endl;
cout<<"Final inoventories in store3:\n\t "<<store3<<endl;
}

