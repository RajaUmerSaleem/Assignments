#include<iostream>
using namespace std;

/*
// " RECURSIVE FUNCTION TO FIND FACTORIAL OF A NUMBER "
int factorial(int n)
{
	// " Factorial of 0 & 1 is 1 "
	if (n == 0 || n == 1)
	{
		return 1;
	}
	else
	{
		return n * factorial(n - 1);
	}
}
int main()
{
	int num;
	cout << " Enter a number to find its factorial !" << endl;
	cin >> num;
	cout << " Factorial  of number " << num << " is " << factorial(num) << endl;
	return 0;
}
*/

/*
// " RECURSIVE FUNCTION TO FIND FACTORIAL OF A NUMBER "
int fibonacci(int n)
{
	// " Fibonacci of 0 is 0 while of 1 is 1 "
	if (n == 0)
	{
		return 0;
	}
	else if (n == 1)
	{
		return 1;
	}
	else
	{
		return fibonacci(n - 1) + fibonacci(n - 2);
	}
}
int main()
{
	int num;
	cout << " Enter a number to find fibonacci  series digit at that number !" << endl;
	cin >> num;
	cout << " Fibonacci series digit at " << num << " is " << fibonacci(num) << endl;
}
*/

/*
// " RECURSIVE FUNCTION TO FIND NTH POWER OF A NTH NUMBER "
int power(int base, int exponent)
{
	// " 0 exponent of nth number is 1 while 1 exponent is that number "
	if (exponent == 0)
	{
		return 1;
	}
	else if (exponent == 1)
	{
		return base;
	}
	else
	{
		return base * power(base, exponent - 1);
	}
}
int main()
{
	int base, exponent;
	cout << "Enter a number and its power to find the result !" << endl;
	cin >> base >> exponent;
	cout << exponent << " power of " << base << " is :" << power(base, exponent) << endl;
}
*/

/*
// " RECURSIVE FUNCTION TO FIND A GCD OF NUMBERS "
int gcd(int num1, int num2)
{
	if (num1 == 0)
	{
		return num2;
	}
	else if (num2 == 0)
	{
		return num1;
	}
	else
	{
		return gcd(num2, num1 % num2);
	}
}
int main()
{
	int num1, num2;
	cout << " Enter two numbers to find their gcd !" << endl;
	cin >> num1 >> num2;
	cout << " GCD of " << num1 << " and " << num2 << " is : " << gcd(num1, num2) << endl;
	return 0;
}
*/
