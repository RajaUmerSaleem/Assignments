/*#include<iostream>
using namespace std;
int main() 
{
	int a[10];
	cout<<"enter n numbers ";
	for(int i =0;i<10;i++)
	{
		cin>>a[i];
	}
		for(int i =0;i<10;i++)
	{
		cout<<a[i]<<"\t";
	}
	return 0;
}*/

/*
#include<iostream>
using namespace std;
int main() 
{
	int a[10];
	int sum =0;
	cout<<"enter n numbers ";
	for(int i =0;i<10;i++)
	{
		cin>>a[i];
		sum+=a[i];
	}
	cout<<"the sum of the array "<<sum;
	return 0;
}*/

/*
#include<iostream>
using namespace std;
int main() 
{
	int n;
	int c=0;
	int a[5];
	cout<<"enter n numbers ";
	for(int i =0;i<5;i++)
	{
		cin>>a[i];
	}
	while(true)
	{
	cout<<"enter the number which is occur first: "<<endl;
	cin>>n;		
		for(int i =0;i<5;i++)
	{
		if(a[i]==n)
			c=i;
	}
	cout<<"the index of "<<n<<" is "<<c;
	}
	return 0;
	}*/
	/*
#include<iostream>
using namespace std;
int main() 
{
	int n;
	int c=0;
	int a[5];
	cout<<"enter n numbers ";
	for(int i =0;i<5;i++)
	{
		cin>>a[i];
	}
	cout<<"enter the number which is occur last: "<<endl;
	cin>>n;	
	for(int i =4;i>0;i--)
	{
		if(a[i]%n==0)
	c++;
	if(c==1)
	{
		cout<<"the index no is"<<i;
		break;
	}	
	}
	return 0;
	}*/
/*
#include<iostream>
#include<cstdlib>
using namespace std;
int main() 
{
    int n;
	int v;
	int c=0;
	int a[5];
	cout<<"enter n numbers ";
	for(int i =0;i<5;i++)
	{
	    v= rand()%100;	
		a[i]=v;
		cout<<a[i]<<endl;
	}
	cout<<"enter the number you want to delete "<<endl;
	cin>>n;	
for(int i =0;i<5;i++)
	{
		if(a[i]==n)
	for(int j =i;j<5-1;j++)
	{
		a[j]=a[j+1];
	}
    }
	for(int i =0;i<5-1;i++)
	{
		cout<<a[i]<<endl;
	}
	return 0;
}*/
/*
#include<iostream>
#include<cstdlib>
using namespace std;
int main() 
{
	int a[5];
	int min =a[0];
	int max=0;
	int v;
	
	cout<<"enter n numbers ";
	for(int i =0;i<5;i++)
	{
		v=rand()%100;
	   a[i] = v;
	  cout<<a[i]<<endl;
	if(	max<a[i])
	{
	max=a[i];
     }
		if(	min>a[i])
		{	
	min=a[i];
        }
	}
	cout<<"the maximum value is: "<<max<<endl;
		cout<<"the minimum  value is: "<<min;
	return 0;
}*/

/*
#include<iostream>
using namespace std;
int main() 
{int a[5];
	cout<<"enter n numbers ";
	for(int i =0;i<5;i++)
	    { 
	     cin>>a[i];
		}
//		for(int j =0;j<4;j++)
//		{
//		 for(int k =j+1;k<5;k++)
//		 {
//		 	if(a[j]>a[k])
//		 	{
//		 		int temp=a[j];
//		 		a[j]=a[k];
//		 		a[k]=temp;
//			 }
//		}
//	}
for(int i =0;i<4;i++)
	{
	 for(int k =i+1;k<5;k++)
    {  
	if(a[i]>a[k])
swap(a[i],a[k]);
	}
	} 
	for(int i =0;i<5;i++)
	{
	cout<<a[i]<<"  ";
	} 
return 0;
 }*/
 /*
#include <iostream>
#include <algorithm>

using namespace std;
int main() {
    int n;
    cout << "Enter the number of elements: ";
    cin >> n;

    if (n <= 0) {
        cout << "Invalid input. Please enter a positive number of elements." << endl;
        return 1;
    }

    int arr[100]; 
	// Assuming a maximum of 100 elements
    int frequency[100] = {0}; // Array to store frequency of each number
    cout << "Enter " << n << " numbers: ";
    for (int i = 0; i < n; i++) {
        cin >> arr[i];
        f[arr[i]]++;
    }
    int mostFrequentNumber = arr[0];
    int maxFrequency = frequency[arr[0]];
    
    for (int i = 0; i < n; i++) 
	{
        if (frequency[arr[i]] > maxFrequency) 
		{
            mostFrequentNumber = arr[i];
            maxFrequency = frequency[arr[i]];
        }
    }

   cout << "The most frequent number is: " << mostFrequentNumber << " (appears " << maxFrequency << " times)" << endl;

    return 0;
}*/
/*
#include<iostream>
using namespace std;
int main() 
{
	int n[10]={0};
	int a[10];
	cout<<"enter n numbers ";
	for(int i =0;i<10;i++)
	{
		cin>>a[i];
	}
	// swap  
		for(int i =0;i<9;i++)
	{
		for(int j=i+1;j<10;j++)
		{
			if(a[i]>a[j])
		{
			swap(a[i],a[j]);
		}
		}
	}
	cout<<endl;
		cout<<"sorted array" ;
	for(int i=0; i<9;i++)
	{
		cout<<a[i]<<" ";
	}
	cout<<endl;
		cout<<"removing duplicates array" ;
	for(int i=0;i<9;i++)
	{
		if(a[i]==a[i+1])
		{
			 n[i]=a[i];
		}
		else
		cout<<a[i]<<"  ";
	}
cout<<endl;
	cout<<"duplicates array" ;
	for(int i=0; i<9;i++)
	{
		cout<<n[i]<<" ";
	}

	return 0;
}*/
