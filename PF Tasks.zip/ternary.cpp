#include<iostream>
#include<string>
using namespace std;
int main() {
int y;
cin >>y;
string result;
result=(y>0)?"good":"no";
cout<<result;
}

