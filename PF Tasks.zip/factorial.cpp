#include<iostream>
using namespace std;
int main() {
	int n,g,f;
f=n=1;
	cout<<"enter the no. of factorial:";
	cin>>g;
while(n<=g)
{
f = f*n;
n++; 
}
	cout<<"factorial of "<<g<<" is\n\t"<<f;
}

