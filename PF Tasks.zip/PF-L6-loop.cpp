                    //PF LAB 6 TASK ASSIGNMENT 
                     /*RAJA UMER SALEEM 
                     CS-2023-609*/
                     //LOOP PROBLEMS
//P7 loop
/*#include<iostream>
using namespace std;
int main()
{
char x;
while(true)
{
cout << "enter a character";
cin>>x;

if(x=='Y'||x=='y')
break;
cout <<"I am happy"<<endl;
}

	return 0;
}*/

//P8 loop
/*#include<iostream>
using namespace std;
int main()
{
int sum;
	for(int i=1; i<=100;i++)
	{
	cout<<i<<endl;
	sum=sum+i;
}
cout<<"the sum is"<<sum;
return 0;
}*/

//P9 loop
/*#include<iostream>
using namespace std;
int main()
{
	int num;
	cout<<"enter the Nth number";
	cin>>num;
	for(int i=1 ;i<=num;i++)
		cout<<i<<endl;
		return 0;
	}*/
  /*THANKYOU very much... Respected SIR! MUHAMMAD AIZAZ AKMAL and  Respected MA'AM! ZOHA SOHAIL
					   for this opportunity to make this assignment.*/	

	
