#include<iostream>
using namespace std;
int main()
{   /*
	int a, n = 1, original_number,reversed_number=0,remainder=1;
	cout << "Enter a number:";
	cin >> a;
	original_number = a;
	while(a!=0)
		{
			remainder = a % 10;
		reversed_number = reversed_number * 10 + remainder;
			a = a / 10;
		}
	if (original_number == reversed_number)

		cout << "Its a Palindrome";
	else
		cout << "Its not a Palindrome.";
	return 0;
	*/
	/*
	int a,b=0,original,half=1,number=0,count=0,sum=0,u,t,h,th,sum2=0,sum1=0,number1;
	cout << "Enter a number:";
	cin >> a;
	original = a;
	while (a != 0)
	{
		a = a / 10;
		b++;
	}
		
			u = original / 1000;
			t = (original % 1000) / 100;
			h = ((original % 1000) % 100) / 10;
			th = (((original % 1000) % 100) % 10) / 1;
			sum1 = u + t;
			sum2 = h + th;
			number1 = abs(sum1 - sum2);
		for (int i = 1; i < number1; i++)
		{
			if (number1 % i == 0)
				sum = sum + i;
		}
		if (sum == number)
			cout << "The number is Funny.";
		else
			cout << "The number is Serious.";
		
		u = original / 1000;
		t = (original % 1000) / 100;
		h = ((original % 1000) % 100) / 10;
		th = (((original % 1000) % 100) % 10) / 1;
		number = (u + t + h + th)-1;
		for (int i = 1; i <= number; i++)
		{
			if (number % i == 0)
				count++;
		}
		if (count == 2)
			cout << "The number is Funny.";
		else
			cout << "The number is Serious.";*/
	return 0;
}