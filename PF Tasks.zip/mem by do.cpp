#include<iostream>
using namespace std;
int main() {
	const double adult =40.0;
const double child =30.0;
const double senior =35.0;
int choice,months;
double charges;
do{

cout<<"\t\tLibrary Membership Menu\n";
cout<<"choose according to your desire membership\n";
cout<<"1:adult"<<endl;
cout<<"2:child"<<endl;
cout<<"3:senior"<<endl;
cout<<"4:quit program"<<endl;
cin>>choice;
{
while(choice<1||choice>4)
{
cout<<"please entre 1,2,3 or 4"<<endl;
break;
}
}

switch(choice)
{
case 1:
	cout<< "ok! you want adult memebership\nFor how many months?\n";
cin>>months;
charges = months*adult;
	cout <<"your bill is $"<<charges<<endl<<"After paying your bill you can join us";
	break;
case 2:
	cout<< "ok! you want child memebership\nFor how many months?\n";
cin>>months;
charges = months*child;
	cout <<"your bill is $"<<charges<<endl<<"After paying your bill you can join us";
	break;
	case 3:
	cout<< "ok! you want senior memebership\nFor how many months?\n";
	cin>>months;
charges = months*senior;
	cout <<"your bill is $"<<charges<<endl<<"After paying your bill you can join us";
	break;
	case 4:
	cout<< "program end";
break;
default:
	cout<<"invalid input";	
}
}
while(choice!=4);
}
