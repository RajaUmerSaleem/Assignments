#include<iostream>
using namespace std;
int main() {
char ch[30];	
cout<<"your name is ?";
cin.getline(ch,30);
cout << "your name is: "<<ch;
}

