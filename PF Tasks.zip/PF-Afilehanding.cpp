        /*Raja Umer Saleem 
        2023-CS-609*/
       //File handling assignment
         
//p1
/*
#include<iostream>
#include<string>
#include<fstream>
using namespace std;
int main()
{ 
int c;
string word;
char ch;
ifstream fout;
fout.open("student.txt");
 if(fout.is_open())
 {
 cout<<"linewise data"<<endl;
 while(true)
 {
 	getline(fout,word);
 c++;
 	if(fout.eof())
  	break;
 }
 fout.close();
}
cout<<"Lines are:"<<c-1;
c=0;
fout.open("student.txt");
 if(fout.is_open())
 {
 cout<<endl<<"word wise data"<<endl;
 while(true)
 {
 fout>>word;
 c++;
 	if(fout.eof())
  	break;
 }
 fout.close();
}
cout<<"words are:"<<c-1;
c=0;
 fout.open("student.txt");
 if(fout.is_open())
 {
 cout<<endl<<"chracter wise data"<<endl;
 while(true)
 {
 fout>>ch;
 c++;
 	if(fout.eof())
  	break;
 }
 fout.close();
}
cout<<"characters are:"<<c-1;
return 0;
}*/
//p2
/*
#include<iostream>
#include<string>
#include <cstdlib>
#include<fstream>
using namespace std;
int main()
{ 
ifstream fin;
ofstream fout;
int a[100];
int v[100];
//a //inserting 100 random numbers in file 
for(int i=0;i<100;i++)
{
	a[i]=rand()%1000+1;
}
for(int i=0;i<100;i++)
{
	cout<<a[i]<<" ";
}
fout.open("randon.txt");
for(int i=0;i<100;i++)
{
fout<<a[i]<<endl;
}
fout.close();
fin.open("randon.txt");
int i=0;
while(i<100)
{
fin>>v[i];	
i++;
}
fin.close();
cout<<"other array"<<endl;
for(int i=0;i<100;i++)
{
cout<<v[i]<<endl;	
}
//b //deleted occurrance  of 100 random number..
fout.open("randon.txt");
fout <<-1;	
fout.close();
return 0;
}*/

//P3
/*
#include<iostream>
#include<string>
#include <cstdlib>
#include<fstream> 
#include<cstddef> 
using namespace std;
struct item{
	string itn;
	double q;
	double wcost;
	double rcost;
	string date;
};
void add(item it[],int n,fstream &file)
{
	for(int i=0;i<n;i++)
	{
		cout<<"Enter item name:";
		cin>>it[i].itn;
		cout<<endl;
		cout<<"Enter item on hand quantity:";
		cin>>it[i].q;
		cout<<endl;
		cout<<"Enter item wholesale cost:";
		cin>>it[i].wcost;
		cout<<endl;
		cout<<"Enter item retail cost:";
		cin>>it[i].rcost;
		cout<<endl;
		cout<<"Enter date:";
		cin>>it[i].date;
		cout<<endl;
	}
	for(int i=0;i<n;i++)
	{
		file<<it[i].itn<<" "<<it[i].q<<" "<<it[i].wcost<<" "<<it[i].rcost<<" "<<it[i].date<<endl;
	}
}
void fetch(fstream &file)
{
	    string name,iname;
        double quantity,wholesale,retail;
        string date;
		cout<<"Enter the name of item, fetch its record"<<endl;
		cin.ignore();
		getline(cin,name);
file.open("item.txt",ios::in);
while(file>>iname>>quantity>>wholesale>>retail>>date)
{
	if(name==iname)
	{
	cout<<"item:"<<iname<<endl;
	cout<<"quantity:"<<quantity<<endl;
	cout<<"wholesale cost: $"<<wholesale<<endl;
	cout<<"retail cost: $"<<retail<<endl;
	cout<<"date:"<<date<<endl;
	}
	if(file.eof())
  	break;
}
file.close();
}
void update(fstream &file)
{
	fstream file1;
	    string name,iname;
        double quantity,wholesale,retail;
        string date;
		cout<<"Enter the name of item,modify its record"<<endl;
		cin.ignore();
		getline(cin,name);
file.open("item.txt",ios::in);
file1.open("item1.txt",ios::out);
while(file>>iname>>quantity>>wholesale>>retail>>date)
{
	if(name==iname)
	{
	cout<<"item:";
getline(cin,iname);
	cout<<"quantity:";
	cin>>quantity;
	cout<<"wholesale cost: $";
	cin>>wholesale;
	cout<<"retail cost: $";
	cin>>retail;
	cout<<"date:";
	cin>>date;
	file1<<iname<<" "<<quantity<<" "<<wholesale<<" "<<retail<<" "<<date<<endl;
	}
	else{
		file1<<iname<<" "<<quantity<<" "<<wholesale<<" "<<retail<<" "<<date<<endl;
	}
	if(file.eof())
break;
}
file.close();
file1.close();
  remove("item.txt"); 
  rename("item1.txt","item.txt");
  cout<<"Updated records"<<endl;
  file.open("item.txt",ios::in);
while(file>>iname>>quantity>>wholesale>>retail>>date)
{
	cout<<"item:"<<iname<<endl;
	cout<<"quantity:"<<quantity<<endl;
	cout<<"wholesale cost: $"<<wholesale<<endl;
	cout<<"retail cost: $"<<retail<<endl;
	cout<<"date:"<<date<<endl;
	if(file.eof())
  	break;
}
file.close();
}
int main()
{ 
int choice;

fstream file;
item *arr = NULL;
int n;
cout<<"1:Add record\n2:Display any record\n3:Change any record\n";
cin>>choice;
switch(choice){
	case 1:
	cout<<"Enter the no. of records you want to add"<<endl;
	cin>>n;
	arr= new item[n];
file.open("item.txt",ios::out);
add(arr,n,file); 
file.close();
break;
	case 2:
	fetch(file)	;
break;
case 3:
update(file);
}
delete[] arr;
}
*/
/*
//P4
//total items quantity in inventery
//total wholesale 
//total retail 
#include<iostream>
#include<string>
#include <cstdlib>
#include<fstream> 
#include<cstddef> 
using namespace std;
struct item{
	string itn;
	double q;
	double wcost;
	double rcost;
	string date;
};
int items,whole,re;
void fetch(fstream &file)
{
	    string iname;
        double quantity,wholesale,retail;
        string date;
file.open("item.txt",ios::in);
while(file>>iname>>quantity>>wholesale>>retail>>date)
{
	items+=quantity;
	whole+=wholesale;
	re+=retail;
	if(file.eof())
		break;
	}

	cout<<"total items:"<<items<<endl;
	cout<<"total wholesale cost of items :"<<whole<<endl;
	cout<<"otal retail cost of items "<<re<<endl;
	file.close(); 	
}
int main()
{ 
fstream file;
fetch(file)	;
}
*/
//P5
/*
#include <iostream>
#include<string>
#include <cstdlib>
#include<fstream> 
#include<cstddef> 
using namespace std;
struct student {
string name,id;
double cgpa,marks;
char grade;
};
void add(student it[],int n,fstream &file)
{
	for(int i=0;i<n;i++)
	{
		cin.ignore();
		cout<<" student name:";
		getline(cin,it[i].name);
		cout<<endl;
		cout<<" student ID:";
		getline(cin,it[i].id);
		cout<<endl;
		cout<<" student cgpa:";
		cin>>it[i].cgpa;
		cout<<endl;
		cout<<" student marks:";
		cin>>it[i].marks;
		cout<<endl;
		if (it[i].marks<=70&&it[i].marks<100)
		{
		it[i].grade='F';	
		}
		else if (it[i].marks>70&&it[i].marks<=80&&it[i].marks<100)
		{
		it[i].grade='C';		
		}
		else if (it[i].marks>80&&it[i].marks<=90&&it[i].marks<100)
		{
		it[i].grade='B';		
	    }
	}
	for(int i=0;i<n;i++)
	{
		file<<it[i].name<<" "<<it[i].id<<" "<<it[i].cgpa<<" "<<it[i].marks<<" "<<it[i].grade<<endl;
	}
}
void show(fstream &file)
{
string n,id;
double c,m;
char g;
file.open("stu.txt",ios::in);
while(file>>n>>id>>c>>m>>g)
{
	cout<<"Stuednt name: "<<n<<endl;
	cout<<"Stuednt id: "<<id<<endl;
	cout<<"CGPA: "<<c<<endl;
	cout<<"Marks: "<<m<<endl;
	cout<<"Grade: "<<g<<endl;
	if(file.eof())
  	break;
}
	file.close();
}
void highest(fstream &file)
{
string n,id;
double c,m;
char g;
double max=0;
file.open("stu.txt",ios::in);
while(file>>n>>id>>c>>m>>g)
{
	if(max<m)
{

	max=m;
}
	if(file.eof())
  	break;
}
while(file>>n>>id>>c>>m>>g)
{ 
if (max==m)
{ 
    cout<<"highest marks Student"<<endl;
	cout<<"Stuednt name: "<<n<<endl;
	cout<<"Stuednt id: "<<id<<endl;
	cout<<"CGPA: "<<c<<endl;
	cout<<"Marks: "<<m<<endl;
	cout<<"Grade: "<<g<<endl;	
}
}
	file.close();
}
int main()
{ 
int choice;
fstream file;
student *arr = NULL;
int n;
cout<<"1:Add record\n2:Display record\n";
cin>>choice;
switch(choice){
	case 1:
	cout<<" the no. of records of students, You want to add"<<endl;
	cin>>n;
	arr= new student[n];
file.open("stu.txt",ios::out);
add(arr,n,file); 
file.close();
break;
	case 2:
	show(file);
break;
case 3:
	highest(file);
break;
case 4:
	sortdata(file);
	break;
case 5: 
best(file);
break;
default:
	cout<<"invalid choice"<<endl;
}
delete[] arr;
}
*/ 


  /*THANKYOU very much... Respected SIR! MUHAMMAD AIZAZ AKMAL and  Respected MA'AM! ZOHA SOHAIL
					   for this opportunity to make this assignment.*/ 
/*
#include<iostream>
#include<string>
#include <cstdlib>
#include<fstream> 
#include<cstddef> 
using namespace std;
int main(){
	fstream file;
		int account;
	string passid,pword;
	cout<<"Dear customer!\n1:you have an account\n2:You want to create to create a account\n";
	cin>>account;
	switch(account)
	{
		case 1:
		//read;	
		  break;
		  case 2:
		  	cin.ignore();
		  	cout<<"Enter id"<<endl;
		  	cin>>passid;
		  	cout<<"Enter password"<<endl;
		    cin>>pword;
		  	file.open("password.txt",ios::app|ios::out);
		 if (!file.is_open()) {
                cout << "Error opening file." << endl;
            }
		  	file<<passid<<" "<<pword<<endl;
		  	file.close();
		  	break;
        }
}*//*
void updaterecord(car *ptc,fstream &file)
{
	fstream file1;
	    string name,iname;
        double quantity,wholesale,retail;
        string date;
		getline(cin,name);
file.open("carrecord.txt",ios::in);
file1.open("item1.txt",ios::out);
for(int i=0;i<filelength;i++)
{
	{
		file1<<ptc[i].name<<" "<<ptc[i].modle<<" "<<ptc[i].color<<" "<<ptc[i].reg<<" "<<ptc[i].price<<" "<<ptc[i].speed<<" "<<ptc[i].rent<<endl;
	}
if(file.eof())
break;
	}
file.close();
file1.close();
  remove("carrecord.txt"); 
  rename("item1.txt","carrecord.txt");
  cout<<"Updated records"<<endl;
}*/
/*
void omenu()
{
	loading();
	system("CLS");
    cheader(); 
    cout<<endl;
    cout<<endl;
    cout<<"\t\t\t 1:change password"<<endl;
    cout<<"\t\t\t 2:View available cars"<<endl;
    cout<<"\t\t\t 3:Add  new car"<<endl;
    cout<<"\t\t\t 4:remove a car"<<endl;
    cout<<"\t\t\t 5:Update a car"<<endl;
    cout<<"\t\t\t 6:view customer data"<<endl;
    cout<<"\t\t\t 7:Add customer"<<endl;
    cout<<"\t\t\t 8:remove customer"<<endl;
    cout<<"\t\t\t 9:Update customer data"<<endl;
    cout<<"\t\t\t 10:Check report"<<endl;
    cout<<"\t\t\t 11:Logout"<<endl;  
    cout<<"\t\t\t";
}*/

#include <iostream>
#include <ctime>

using namespace std;

int main() {
    // Get the current time
    time_t currentTime = time(NULL);

    // Convert the current time to a string representation
    string currentDate = ctime(&currentTime);

    // Print the current date
    cout << "Current Date and Time: " << currentDate << endl;

    return 0;
}


void modifycus(&file)
string n1,n2,cic,day,month,date,time,yr;
int pri;
file>>pcc[i].car>>n1>>n2>>cic>>pri>>day>>month>>date>>time>>yr;


login
system("PAUSE");
    system("CLS");
    loading();
	system("CLS");
    cheader(); 
    cout<<endl;
    cout<<endl;

