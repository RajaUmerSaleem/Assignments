#include<iostream>
#include<iomanip>
using namespace std;
int main() {
double quotient ,a=10.555,b =2.22;
quotient=a/b;	
cout<<quotient<<endl;
cout<<setprecision(5)<<quotient<<endl;
cout<<setprecision(4)<<quotient<<endl;
cout<<setprecision(3)<<quotient<<endl;
cout<<setprecision(2)<<quotient<<endl;
cout<<setprecision(1)<<quotient<<endl;
}

