#include<iostream>
using namespace std;
int main() {
char str[30];
cout<<"Enter your name :";
cin.get(str,30);
cout<<"your name is :"<<str;	
}

