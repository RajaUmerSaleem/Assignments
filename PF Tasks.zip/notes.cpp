#include<iostream>
using namespace std;
int main()
{
	int th,f,h,fif,x,y,z,c,sum;
	sum=0;
	th=1000;
	f=500;
	h=100;
	fif=50;
	 cout <<"enter the number of thousand notes";
	 cin>>x;
	 th=th*x;
	 cout <<"enter the number of five hundred notes";
	 cin>>y;
	 f=f*y;
	 cout <<"enter the number of hundred notes";
	 cin>>z;
	 h=h*z;
	cout <<"enter the number of fifty notes";
	cin>>c;
	 fif=fif*c;
	 sum=th+f+h+fif;
	 cout<<"the sum of deposit"<<sum;
	 return 0;
}
