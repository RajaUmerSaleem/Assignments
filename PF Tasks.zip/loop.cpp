//1
/*#include<iostream>
using namespace std;
int main()
{

	int N;
	cin>>N;
for (int i=1;i<=N;i++)	
cout<<i<<endl;


return 0;	
}		
*/
//2
/*
#include<iostream>
using namespace std;
int main()
{
	

	int N;
	cin>>N;
for (int i=1;N>=i;N--)	
cout<<N<<endl;


return 0;	
}*/
//3	
/*
#include<iostream>
using namespace std;
int main()
{
	

	int N;
	cin>>N;
for (int i=1;i<=N;i++)	
if(i%2==1)
cout<<i<<endl;

return 0;	
}*/
//4
/*
#include<iostream>
using namespace std;
int main()
{

int n,l;
cout<<"enter the no ";
cin>>n;
cout<<"enter the limit ";
cin>>l;
for(int i=1 ; i<=l; i++)
cout<<n << "*"<<i<<"="<<n*i<<endl;
return 0;
}*/
/*
#include<iostream>
using namespace std;
int main()
{

	int N,sum;
	cin>>N;
for (int i=1;i<=N;i++)	
{

cout<<i<<endl;
sum=sum+i;
}
cout<<"sum is"<<sum;
return 0;	
}	
*/
#include<iostream>
using namespace std;
int main()
{

	int num, N ,p,n,s;
	float v;
	cin>>N;
	
for (int i=1;i<=N;i++) 
{
	
cin>>num;
if(num>0)
{
	
	s=s+i;
	p++;
	}
	
	else
{
	n++;
		
	}
}
	v=s/p;
		cout<<"average of positive"<<v;
cout<<"total positive are"<<p;
cout<<"total negitive are"<<n;
return 0;	
}


