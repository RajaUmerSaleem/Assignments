                     //PF LAB 3 ASSIGNMENT 
                     /*RAJA UMER SALEEM 
                     CS-2023-609*/
                    
 //lab1 problem#0
/*#include<iostream>
#include<string>
using namespace std;
int main()
{
string name, department;
int a,s;
cout<<"Enter your name: ";
getline(cin,name);
cout<<"Enter your age: ";
cin>>a;
cout<<"Enter your department: ";
cin.ignore();
getline(cin,department);
cout<<"Enter your salary: ";
cin>>s;
cout<<" Employee name is "<<name<<". He is  "<<a<<"years old, and belongs to  "<<department<<"\ndepartment having monthly salary" <<s<< "rupees.";
return 0;
}*/

//lab1 problem#1
/*
#include<iostream>
#include<string>
using namespace std;
int main()
{
string name ,r,cnic ;
int a;
cout<<"Enter your name: ";
getline(cin,name);
cout<<"Enter your age: ";
cin>>a;
cout<<"Enter your  roll no: ";
cin.ignore();
getline(cin,r);
cout<<"Enter your CNIC: ";
getline(cin,cnic);
cout<<" My name is "<<name<<".I am "<<a<<" years old, and my student ID is "<<r<<" and my CNIC is\n"  <<cnic;
return 0;
}*/

//lab1 problem#2
/*
#include<iostream>
using namespace std;
int main()
{
	int v,len,w,h;
	cout << "Enter length,width and heigth to evaluate the volume of the box."<<endl;
	cout <<"Enter the length:";
	cin>>len;
	cout <<"Enter the width:";
	cin>>w;
	cout <<"Enter the heigth:";
	cin>>h;
	v=len*w*h;
	cout<<"volume of box is "<<v;
	return 0;
}
*/

//lab1 problem#3
/*
#include<iostream>
using namespace std;
int main()
{
float e,c,pf,avg,per;
cout<<"Enter the marks in English:";
cin>>e;
cout<<"Enter the marks in Calculus:";
cin>>c;
cout<<"Enter the marks in PF:";
cin>>pf;
avg=(e+c+pf)/3;
per=((e+c+pf)/300)*100;
cout<<"Average of Marks"<<avg<<endl;
cout<<"Percentage of Marks"<<per<<"%";
return 0;
}
*/

//lab1 problem#4
/*
#include<iostream>
using namespace std;
int main()
{
float r,h,v;
float pi =3.14;
cout<<"Enter the radius:\t";
cin>>r;
cout<<"Enter the height:\t";
cin>>h;
v=pi*r*h;
cout<<"Volume of cylinder is:\t"<<v;
return 0;
}
*/

//lab1 problem#5
/*
#include<iostream>

using namespace std;
int main()
{
float b ,tot,anu;
cout<<"Enter the Ali,s basic salary:\t";
cin>>b;
tot=b+(b*55/100);
anu=tot*12;
cout<<"Gross month Salary:\t"<<tot<<endl;
	cout<<"Gross annual Salary\t"<<anu<<endl;
	return 0;
}
*/

//lab1 problem#6
/*
#include<iostream>
using namespace std;
int main()
{
	int th,f,h,fif,x,y,z,c,sum;
	th=1000;
	f=500;
	h=100;
	fif=50;
	 cout <<"enter the note of 1000: ";
	 cin>>x;
	 th=th*x;
	 cout <<"enter the note of 500: ";
	 cin>>y;
	 f=f*y;
	 cout <<"enter the note of 100: ";
	 cin>>z;
	 h=h*z;
	cout <<"enter the note of 50: ";
	cin>>c;
	 fif=fif*c;
	 sum=th+f+h+fif;
	 cout<<"total Amount he deposits:\t"<<sum;
	 return 0;
}
*/

//lab2 problem#1
/*
#include<iostream>
using namespace std;
int main()
{
int a,b,c;
cout<<"enter the first side of triangle:";
cin>>a;
cout<<"enter the second side of triangle:";
cin>>b;
cout<<"enter the third side of triangle:";
cin>>c;
if(a+b+c==180)
	cout<<"valid triangle";
else
  cout<<"invalid triangle";
  return 0;
}
*/

//lab2 problem#2
/*
#include<iostream>
using namespace std;
int main()
{
int a,b,c;
cin>>a;
cin>>b;
cin>>c;
if(a+b+c==180)
{
	cout<<"valid triangle";
	
	
	if(a<90&&b<90&&c<90)
{
	cout<<" acute";
}
if(a!=b&&b!=c&&c!=a)
{	
	cout<<" scalene";
}
if(a==90||b==90||c==90)
{
	cout<<" right trangle";
	}
if(a==60&&b==60&&c==60)
{
	cout<<" equilateraltrangle";  
}

}
else 
	cout<<"invalid triangle ";

return 0;
}  
*/

//lab2 problem#3
/*
#include<iostream>
#include<string>
using namespace std;
int main()
{
	int x,y;
	cout<<"Enter x value ";
cin>>x;
cout<<"Enter y value  ";
cin>>y;
if (x==0)
  if (y==0)
cout<<"lies on origin";
else
{
	if(y>0)
     	cout<<"on +ve y-axis";
	else
      	cout<<"on -ve y-axis";
    
  }  
  else
  {
  	if(y==0)
  	 if(x>0)
  	 cout<<"on +ve x-axis";
	else
      	cout<<"on -ve x-axis";
      	else
      	{
      		if(y>0)
      		 if (x>0)
      		 cout<<"quad 1";
      		 else
      		  cout<<"quad 2";
      		  else
      		  {
      		  	if (x>0)
      		  	cout<<"quad 4";
      		 else
      		  cout<<"quad 3";
				}
		  }
     	 
  }
  return 0;
}*/

//lab2 problem#4
/*#include<iostream>
using namespace std;
int main()
{
	int a,b,c,d;
	cout<<"Enter a Number to check it is Palindrome or not ? : ";
	cin>>a;
	b=(a/100);
	c=(a/100)%10;
	d=(a%100)%10;	
	if(b==d)
	  	cout<<" Palindrome " ;
	  	else
	  		cout<<" not Palindrome " ;
	  		return 0;
	  	}*/
	  	

//lab2 problem#5
/*
#include<iostream>
using namespace std;
int main()
{
int x,y,c,a,mu,s,d,mo;
cout<<"Enter  1st Number: ";
cin>>x;
cout<<"Enter  1st Number: ";
cin>>y;
cout<<"Press 1 for Addition"<<endl; cout<<"Press 2 for multiply"<<endl;
cout<<"Press 3 for subtraction"<<endl;
cout<<"Press 4 for division"<<endl;
cout<<"Press 5 for modulus"<<endl;
cin>>c;

if(c==1)
{
	a=x+y;
cout<<a;
}

else if(c==2)
{
	mu=x*y;
cout<<mu;
}
else if (c==3)
{
	s=x-y;
cout<<s;
}
else if (c==4)
{
	d=x/y;
cout<<d;
}
else if(c==5)
{
	mo=x%y;
cout<<mo;
}
else
cout<<"enter a valid number";
return 0;
}*/

//lab2 problem#6
/*
#include<iostream>
using namespace std;
int main()
{
int x ;
cout<<"Enter your marks ";
cin>>x;
if(x>=75)
cout<<"Passed:Grade A";
else if(x>=60)
cout<<"Passed:Grade B";
else if(x>=45)
cout<<"Passed:Grade C";
else
cout<<"Failed";
return 0;
}
*/
                       /*THANKYOU very much... Respected SIR! MUHAMMAD AIZAZ AKMAL 
					   for this opportunity to make this assignment.*/
