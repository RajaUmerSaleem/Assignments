                    //PF LAB 6 TASK ASSIGNMENT 
                     /*RAJA UMER SALEEM 
                     CS-2023-609*/
					 
   //P1
  //by switch
/*#include<iostream>
using namespace std;
int main()
{
char c;
cout<<"Enter the alphabets to check weather it is vowels and consonants	";
cin>>c;
switch(c)
{
case 'a':
cout<<"vowel";
break;
case 'i':
cout<<"vowel";
break;
case 'o':
cout<<"vowel";
break;
case 'u':
cout<<"vowel";
break;
case 'e':
cout<<"vowel";
break;
default:
cout<<"you enter a consonant";
return 0;
}
}*/
//by if else
/*#include<iostream>
using namespace std;
int main()
{
char c;
cout<<"Enter the alphabets to check weather it is vowels and consonants";
cin>>c;
if (c=='a')
cout<<"vowel";
else if (c=='i')
cout<<"vowel";
else if (c=='o')
cout<<"vowel";
else if (c=='u')
cout<<"vowel";
else if (c=='e')
cout<<"vowel";
else 
 cout<<"you enter a consonant";
return 0;
}*/

//P2 
/*#include<iostream>
using namespace std;
int main()
{
	int fn,sn;
	cout<<"enter the first number";
	cin>>fn; 
	cout<<"enter the second number";
	cin>>sn;
	int larger=(fn>sn)? fn: sn;
		 	int smaller=(fn<sn)?fn:sn;
	 	cout<<"the larger no. is: " << larger<<endl;
	 	cout<<"the smaller no. is: " << smaller<<endl;	 	
return 0;
}*/

//P3
//by SWITCH
/*
#include<iostream>
using namespace std;
int main()
{
int c;
cout<<"Enter the no of month";
cin>>c;
switch(c)
{
case 1:
cout<<"January";
break;
case 2:
cout<<"February";
break;
case 3:
cout<<"March";
break;
case 4:
cout<<"April";
break;
case 5:
cout<<"May";
break;
case 6:
cout<<"june";
break;
case 7:
cout<<"July";
break;
case 8:
cout<<"August";
break;
case 9:
cout<<"September";
break;
case 10:
cout<<"October";
break;
case 11:
cout<<"November";
break;
case 12:
cout<<"December";
break;
default:
cout<<"you enter a invalid year,s no..";
return 0;
}
}*/
//by IF-ELSE
/*
#include<iostream>
using namespace std;
int main()
{
int c;
cout<<"Enter the no of month";
cin>>c;
if (c==1)
cout<<"January";
else if (c==2)
cout<<"February";
else if (c==3)
cout<<"March";
else if (c==4)
cout<<"April";
else if (c==5)
cout<<"May";
else if (c==6)
cout<<"June";
else if (c==7)
cout<<"July";
else if (c==8)
cout<<"August";
else if (c==9)
cout<<"September";
else if (c==10)
cout<<"October";
else if (c==11)
cout<<"November";
else if (c==11)
cout<<"December";
else 
     cout<<"you entered a invalid no. of year";
return 0;
}
*/

//P4
/*
#include<iostream>
using namespace std;
int main()
{
float w,h;
float bmi;
cout<<" To find BMI (body mass index)" <<endl<<" Enter the weigth in pounds";
cin>>w;
cout<<"Enter the heigth in inches";
cin>>h;
bmi = w*703 / (h*h);
if(bmi<18.5)
cout<<"underweigth";
else if(bmi<=24.9)
cout<<"normalweigth";
else if(bmi<29.9)
cout<<"normalweigth";
else
cout<<"obese";
return 0;
}
*/
//P5
//by switch
/*
#include<iostream>
using namespace std;
int main()
{
		int c,fn,sn,a,sub,d,m;
		float avg;
		
		//the sum, subtraction, division, multiplication or average.
		
	cout<<"enter the first number";
	cin>>fn; 
	cout<<"enter the second number";
	cin>>sn;
		cout<<"enter 1 to find sum"<<endl;
	 cout<<"enter 2 to find subtration"<<endl;
	 cout<<"enter 3 to find division"<<endl;	 
	 	 cout<<"enter 4 to find multiplication"<<endl;
	 	  cout<<"enter 5 to find average"<<endl;
	 	  cin>>c;
	 	  switch(c)
	 	  {
	 	  	case 1: 
	 	  	a=fn+sn;
	 	  	cout<<"the sum is"<<a;
	 	  	break;
	 	  	case 2:
	 	  	sub=fn-sn;
	 	  	cout<<"the subtraction is"<<sub;
	 	  	break;
	 	  	case 3:
	 	  	d=fn/sn;
	 	  	cout<<"the division is"<<d;
	 	  	break;
	 	  	case 4:
	 	  	m=fn*sn;
	 	  	cout<<"the multiplication is"<<m;
	 	  	break;
	 	  	case 5:
	 	  	avg=(fn+sn)/2;
	 	  	cout<<"the average is"<<avg;
	 	  	break;
	 	  	default:
	 	  	cout<<"you enter a invalid number";	
	 	  	
		   }
		   return 0;
    }*/
    //by if else
 /*   
#include<iostream>
using namespace std;
int main()
{
		int c,fn,sn,a,sub,d,m;
		float avg;
		
		//the sum, subtraction, division, multiplication or average.
		
	cout<<"enter the first number";
	cin>>fn; 
	cout<<"enter the second number";
	cin>>sn;
		cout<<"enter 1 to find sum"<<endl;
	 cout<<"enter 2 to find subtration"<<endl;
	 cout<<"enter 3 to find division"<<endl;	 
	 	 cout<<"enter 4 to find multiplication"<<endl;
	 	  cout<<"enter 5 to find average"<<endl;
	 	  cin>>c;
	 	  if(c==1)
	 	  {
	 	  		a=fn+sn;
	 	  	cout<<"the sum is"<<a;
		   }
		   else if(c==2)
		   {
		   		sub=fn-sn;
	 	  	cout<<"the subtraction is"<<sub;
		   }
		   else if(c==3)
		   {
		   	d=fn/sn;
	 	  	cout<<"the division is"<<d;
		   }
		   else if(c==4)
		   {
		   	m=fn*sn;
	 	  	cout<<"the multiplication is"<<m;
		   }
		    else if(c==5)
		    {
		    	avg=(fn+sn)/2;
	 	  	cout<<"the average is"<<avg;	
			}
			else 
			cout<<"you enter a invalid number";	
			return 0;
		}*/
		//P6
	/*	#include<iostream>
using namespace std;
int main()
{
int x;
cout<<"Enter the no.";
cin>>x;
if(x>0)
cout<<"it is positive no. ";
else if (x<0)
cout<<"it is negative no. ";
else 
cout<<" zero ";
return 0;
}*/

//P7
//by SWITCH
/*
#include<iostream> //pr P=2(l+w) //cA = 3.14*r� //C = 2*3.14*r //cylinderV = pr�h//A = 2pr� + 2prh
using namespace std;
int main()
{
 int c ;
 float l,w,r,h, ra,rp,ca,cc,cya,cyv;
 l=w=c=r=h=0;
 cout<<"enter shape type :"<<endl;
cout<<"enter 1 for rectangle :"<<endl; 
 cout<<"enter 2 for circle :"<<endl;
 cout<<"enter 3 for cylinder :"<<endl;
 cin>>c;
 switch(c)
 {
 	case 1:
 	cout<<"enter lenth and width of rectangle ";	
 	cin>>l;
 	cin>>w;
 	ra = l*w;// rectangle area
 	rp= 2*(l+w);
 	cout<<"area of reactange is"<<ra<<"\nperimeter of rectangle is"<<rp;
 	break;
 	case 2:
 	cout<<"enter radius of circle ";
	 cin>>r;
	 ca=3.14*r*r;	//area 
	 cc=2*3.14*r;
	 	cout<<"area  of circle is"<<ca<<"\ncircumference of circle is"<<cc;
 	break;
	case 3:
	cout<<"enter radius and heigth of cylinder ";
	cin>>r;
	cin>>h;	
	cya= 2*3.14*r*(r+h);
	cyv= 3.14*r*r*h;
		cout<<" area of cylinder is" << cya<< "\nvolume of cylinder"<<cyv;
	break;	
	default:
	cout<<" enter valid shape no.";
 }
 return 0;
}*/

//by IF ELSE
/*
#include<iostream>
using namespace std;
int main()
{
 int c ;
 float l,w,r,h, ra,rp,ca,cc,cya,cyv;
 l=w=c=r=h=0;
 cout<<"enter shape type :"<<endl;
cout<<"enter 1 for rectangle :"<<endl; 
 cout<<"enter 2 for circle :"<<endl;
 cout<<"enter 3 for cylinder :"<<endl;
 cin>>c;
 if(c==1)
 {
 	
 	cout<<"enter lenth and width of rectangle ";	
 	cin>>l;
 	cin>>w;
 	ra = l*w;// rectangle area
 	rp= 2*(l+w);
 	cout<<"area of reactange is"<<ra<<"\nperimeter of rectangle is"<<rp;
 }
 else if(c==2)
 {
 
 	cout<<"enter radius of circle ";
	 cin>>r;
	 ca=3.14*r*r;	//area 
	 cc=2*3.14*r;
	 	cout<<"area  of circle is"<<ca<<"\ncircumference of circle is"<<cc;	
 }
else if(c==3)
{
	
	cout<<"enter radius and heigth of cylinder ";
	cin>>r;
	cin>>h;	
	cya= 2*3.14*r*(r+h);
	cyv= 3.14*r*r*h;
	cout<<" area of cylinder is" << cya<< "\nvolume of cylinder"<<cyv;
}
else
	cout<<" enter valid shape no.";
	return 0;
}*/

//P8
/*
#include<iostream>
using namespace std;
int main()
{
	int c;
		cout<<"enter the numbers of books you purchase this month:"<<endl;
		cin>>c;
		switch(c)
		{
		case 0:
			cout<<"you earns 0 points.";
			break;
		case 1:
			cout<<"you earns 5 points.";
			break;
		case 2:
			cout<<"you earns 15 points.";
			break;
		case 3:
			cout<<"you earns 30 points.";
			break;
	    case 4: 
			cout<<"you earns 60 points.";
			break;	
			default:
					cout<<"you earns 60 points";
				
		}
		return 0;
	}*/
	
	//P9
/*	#include<iostream>
using namespace std;
int main()
{
		int i=0;
	int n=127;

	for(int j=1 ; j<=n ; j++)
	{
		cout<<j<<"ASCII IS "<<char(j);
	i++;
	if(i%16==0)
	cout<<"\n";
	}
	return 0;
}*/

//P10
/*
#include<iostream>
using namespace std;
int main()
{
	cout<<"a"<<endl;
	for(int i=1;i<=10;i++)
	{
	{
		
	for(int j=1;j<=i;j++)
	cout<<"*";
	}
	cout<<endl;
}
	cout<<"b"<<endl;
for(int i=1;i<=10;i++)
	{
	{
		
	for(int j=10;j>=i;j--)
	cout<<"*";
	}
	cout<<endl;
}
	cout<<"c"<<endl;
for(int i=10;i>=1;i--)
	{
	
	for(int k =10-i;k>0;k--)
		cout<<" ";	
	for(int j=i;j>=1;j--)
	cout<<"*";
	
	cout<<endl;
}
  
cout<<"d"<<endl;
	for(int i=1;i<=10;i++)
	{
	for(int k =10-i;k>0;k--)
		cout<<" ";	
	for(int j=1;j<=i;j++)
	{
	cout<<"*";
	}
	cout<<endl;
}

 //combine this
    for (int i = 1; i <= 10; i++) 
	{
      
        for (int j = 1; j <= i; j++) 
		{
            cout << "*";
        }
        
       
        cout << " ";
        
     
      	for(int j=10;j>=i;j--)
		  {
            cout << "*";
        }
        
   
        cout <<" ";
        
  
        for (int j = 1; j <= 10 - i; j++) {
            cout << " ";
        }
        for (int k = 1; k <= i; k++) {
            cout << "*";
        }
         
       
        cout << " ";
        
        for (int j = 10; j >= 10 - i + 1; j--) {
            cout << "*";
        }
        
        cout << endl;
    }
	return 0;	
}*/


//P11
//a
/*#include<iostream>
using namespace std;
int main()
{
	for(int i=1; i<=100;i++)
	cout<<i<<endl;
return 0;
}*/

//b
/*
#include<iostream>
using namespace std;
int main()
{ 
	for(int i=1; i<=100;i++)
	if(i%2==1)
	cout<<i<<endl;
return 0;
}*/

//c
/*
#include<iostream>
using namespace std;
int main()
{
	int num;
	cout<<"enter the Nth number";
	cin>>num;
	for(int i=1 ;i<=num;i++)
		cout<<i<<endl;
		return 0;
	}*/
	
	//d
	/*
	#include<iostream>
using namespace std;
int main()
{
for(int i=90;i>=65;i--)
cout<<"the z to a aphabets are "<<char(i)<<endl;
return 0;
}*/

//e
/*
#include<iostream>
using namespace std;
int main()
{
for(int i=90;i>=65;i--)
if(i!='A'&&i!='E'&&i!='U'&&i!='O'&&i!='I')
cout<<"the z to a aphabets are "<<char(i)<<endl;
return 0;
}*/

//f
/*#include<iostream>
using namespace std;
int main()
{ int i,c;
i=c=0;
cout<<"entre the starting no:";
cin>>i;
cout<<"entre the ending no:";
cin>>c;
	for(int s=i ; s<=c; s++)
	cout<<s<<endl;
return 0;
}*/

  /*THANKYOU very much... Respected SIR! MUHAMMAD AIZAZ AKMAL and  Respected MA'AM! ZOHA SOHAIL
					   for this opportunity to make this assignment.*/
