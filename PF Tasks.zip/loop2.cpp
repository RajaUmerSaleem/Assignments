//6
/*#include<iostream>
using namespace std;
int main()
{

	int num, N ,p,n,s;
	p=n=s=0;
	float v;
	cin>>N;
	
for (int i=1;i<=N;i++) 
{
	
cin>>num;
if(num>0)
{
	
	s=s+i;
	p++;
	}
	
	else
{
	n++;
		
	}
}
	v=s/p;
		cout<<"average of positive"<<v<<endl;
cout<<"total positive are"<<p<<endl;
cout<<"total negitive are"<<n<<endl;
return 0;	
}*/
//7
/*
#include<iostream>
using namespace std;
int main()
{
	int n;
	cin>>n;
for(int i =1 ;i<=n; i++){

if(n%i==0)
cout<<"the factors of n"<<n<<"is"<<i<<endl;
}
return 0;
}*/

//8
/*
#include<iostream>
using namespace std;
int main()
{
	int n,c;
	c=0;
	cin>>n;
	for(int i =1 ;i<=n; i++) 
	{
if(n%i==0)
c++;
}
if(c==2)
cout<<"it is prime no";
else
cout<<"it is not prime no";
return 0;
}*/

//9
/*
#include<iostream>
using namespace std;
int main()
{

	int n,p,s;
	s=1;
	cout<<"enter the number";
	cin>>n;
	cout<<"enter the power";
	cin>>p;
	for(int i=1;i<=p;i++)
	{
s=s*n;
}
	cout<<"The "<< p <<" power of " << n<< " is "<< s;
	return 0;
} 
*/ 

//10
/*
#include<iostream>
using namespace std;
int main()
{
	int f,s;
	s=1;
cin>>	f;
	for ( int i =1; i<=f ;i++)
	s=s*i;
	cout<<"The factorial of "<< f<<" is "<< s;
	return 0;
} 
*/ 
//p11
/*
 #include<iostream>
using namespace std;
int main()
{
	int num=90;
		for ( int i =65; i<=num ;i++)
		cout<< "ASCI	" << i<<"\t"<< "Character	" << (char)i<<endl;
 	return 0;
} */
//p12
/*
 #include<iostream>
using namespace std;
int main()
{
	int num=256;
		for ( int i =0; i<=num ;i++)
		cout<< "ASCI	" << i<<"\t"<< "Character	" << (char)i<<endl;
 	return 0;
} */
