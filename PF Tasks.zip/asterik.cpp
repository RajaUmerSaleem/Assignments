//1
/*#include<iostream>
using namespace std;
int main()
{
	for(int i =1 ;i<=10;i++)
	{
		for(int j =1 ;j<=i;j++)
		{
		cout<<char(64+i);
	}
		cout<<endl;
	}
	return 0;
}*/
//2
/*
#include<iostream>
using namespace std;
int main()
{
	for(int i =1 ;i<=5;i++)
	{
		for(int j =1 ;j<=i;j++)
		{
		cout<<"*";
	}
		cout<<endl;
	}
	return 0;
}*/
//3
/*
#include<iostream>
using namespace std;
int main()
{
	for(int i =1 ;i<=5;i++)
	{
		for(int j =5 ;j>=i;j--)
		{
		cout<<"*";
	}
		cout<<endl;
	}
	return 0;
}*/
//4
/*
#include<iostream>
using namespace std;
int main()
{
	for(int i =1 ;i<=5;i++)
	{

	for(int j =5 ;j>=i;j--)
		cout<<" ";
	for(int k =1 ;k<= 2*i-1;k++)
			cout<<"*";
		cout<<endl;
	}
	return 0;
}*/
//5
/*
#include<iostream>
using namespace std;
2
	return 0;
}*/
//6
/*
#include<iostream>
using namespace std;
int main()
{
int r;
cin>>r;
int c=2*r;
for ( int i=1 ; i<=r; i++ )
{
	for(int j=1; j<=c ;j++ )
	{
		
	if(i==1||i==r||j==1||j==c)
	cout<<"*";
	else 
	cout<<" ";
	}
	cout<<endl;
} 
return 0;
}*/


	
	
