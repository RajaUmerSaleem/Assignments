/*#include<iostream>
using namespace std;
int main()
{
	int temp;
	int a[10];
	for(int i=0 ;i<9;i++)
	{
	 	cin>>a[i];
	 }
	 for(int i=0 ;i<9;i++)
	{
		for(int j=i+1;j<10;j++)
			if(a[i]>a[j])
		{
			temp=a[i];
			a[i]=a[j];
			a[j]=temp;
		}
	 }
	cout<<" non_decreasing order"<<endl;
	for(int i=1 ;i<10;i++)
	{
	 	cout<<a[i]<<"	";
	 }
	 	 cout<<endl;
	 cout<<"Removing Dublicates"<<endl;
	for(int i=1 ;i<9;i++)
	{
	 	if(a[i]!=a[i+1])
	 	cout<<a[i]<<"	";
	 	
	 }
	 
	}*//*
/*
#include<iostream>
using namespace std;
int main()	
{
	int sum1=0;
	int sum2=0;
	int num;
	int a[5][5]={{1,2,3,4,5},{6,7,8,9,10},{10,11,12,13,14},{16,18,19,20,21},{22,23,24,25,26}};
	cout<<"SORTED METRIX OF 5*5"<<endl;
for(int i=0;i<5;i++)
	 {
	 	for(int j=0;j<5;j++)
	 {
	 	cout<<a[i][j]<<"\t\t";
	 }
	 cout<<endl;
	 }
	 
	sum1=a[0][0]+a[1][1]+a[2][2]+a[3][3]+a[4][4];
	sum2=a[0][4]+a[1][3]+a[2][2]+a[3][1]+a[4][0];
		cout<<"the sum of diagonal#1 is "<<sum1<<endl;
		cout<<"the sum of diagonal#2 is "<<sum2<<endl;
		cout<<"enter the no which you wnat to find"<<endl;
		cin>>num;
		int c=0;
	 for(int i=0;i<5;i++)
	 {
	 	for(int j=0;j<5;j++)
	 {
	 	if(a[i][j]==num)
	 {
	 		cout<<num<<"is found";
	 }
	 }
	
	 }
	
}*/

#include<iostream>
using namespace std;
int main()	
{
	int r;
	int c;
	cin>>r>>c;
int a[r][c];

for(int i=0;i<r;i++)
	 {
	 	for(int j=0;j<c;j++)
	 {
	 	cin>>a[i][j];
}
	 }
	 	cout<<endl;	 
	cout<<"input by user"<<endl;
for(int i=0;i<r;i++)
	{
		 {
	 	for(int j=0;j<c;j++)
	 {
	 	cout<<a[i][j]<<"  ";
      }
	 }
	 cout<<endl;
	}
	
	cout<<endl;	 
	cout<<"required"<<endl;
for(int j=0;j<c;j++)
	{
	{
	 	for(int i=r-1;i>=0;i--)
	 {
	 	cout<<a[i][j]<<"  ";
      }
	 }
	 cout<<endl;
	}
}
	
	
	 
	

