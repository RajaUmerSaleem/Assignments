                    //PF LAB 7 TASK ASSIGNMENT 
                     /*RAJA UMER SALEEM 
                     CS-2023-609*/
					 

//p1
//shape1
/*#include<iostream>
using namespace std;
int main()
 { 
 int n;
 cin>>n;
for (int i= n ; i>=1; i--){

for(int k=1 ;k<=n-i;k++)
cout <<" ";
	for (int j=1; j<=i*2-1;j++)	
	{
		cout<<"*";
		
}
cout<<endl;
}
for (int i= 1 ; i<=n; i++){

for(int k=n-i ;k>=1;k--)
cout <<" ";
	for (int j=i*2-1; j>=1;j--)	
	{
		cout<<"*";
	}
cout<<endl;
}
	return 0;
}*/
//shape2
/*
#include<iostream>
using namespace std;
int main()
 { 
 int n;
 cin>>n;
 for (int i= 1 ; i<=n; i++){

for(int k=n-i ;k>=1;k--)
cout <<" ";
	for (int j=i*2-1; j>=1;j--)	
	{
		if (i==1||j==1||j==2*i-1)
		cout<<"*";
		else 
		cout<<" ";
	}
cout<<endl;
}
for (int i= n-1 ; i>=1; i--){

for(int k=1 ;k<=n-i;k++)
cout <<" ";
	for (int j=1; j<=i*2-1;j++)	
	{
		if (i==1||j==1||j==2*i-1)	
		cout<<"*";
		else 
		cout<<" ";	
}
cout<<endl;
}

	return 0;
}*/

//P2
/*
 #include<iostream>
using namespace std;
bool pnum(int a)
{
	int v;
	v=a;
	int d;
	int x;
	int sum=0;
	
	while(a!=0)
	{
		d=a%10;
		x=d*d*d;
		sum=sum+x; 
		a=a/10;
	}
return v==sum;

return 0;	
}
int main()
 { 
 int a;
 cin>>a;
 int n= pnum(a);
 if(n==1)
 	cout<<"it is a strong no";
	else 
	cout<<"it is  not strong no";
	return 0;
}*/

//P3
/*
#include<iostream>
using namespace std;
int allpnum(int a)
{
int v;
	v=a;
	int d;
	int x;
	int sum=0;
	while(a!=0)
	{
		d=a%10;
		x=d*d*d;
		sum=sum+x; 
		a=a/10;
	}	
	if(v==sum)
	{
	cout <<sum<<" strong no "<<endl;
}
return 0;
}
int main()
 { 
 int s,e;
 cin>>s;
 cout<<"enter ending vlaue";
 cin>>e;
 for(int i=s;i<=e;i++)
 {
 int v=0;
 v= allpnum( i);
 if(v!=0)
 cout<<v<<;
 }

}*/

//P4
/*
#include<iostream>
using namespace std;
void allprime(int j)
{
	int c;
for(int k=1;k<=j;k++)
{
int c=0;
	int num = k;
	for(int i=1;i<=k;i++)
	{ 
		if(num%i==0)
		c++;
	}
if(c==2)
cout<<num<<" is prime no"<<endl;
}

}
int main()
{
	int j;
	cout<<"enter n number to find prime numbers in that";
	cin>>j;
		allprime(j);
	
return 0;
}*/

//P5
/*
#include<iostream>
using namespace std;
void fibonnaci(int fn,int sn,int N)
{
  int nextNum;
if(N<3)
cout<<"it should be greater than 3";
else
 {
	
	cout <<"fibonacci series" <<fn<<", "<<sn<<", ";
	for (int i=2;i<=N;i++)
	{
          

            if (i % 2 == 0)
                nextNum = fn + sn;
			 else
                nextNum = fn * sn;
	cout<<nextNum<<", ";
	fn=sn;
sn=nextNum;
    }
 }
}

int main()
{
	int fn,sn,N;
	cout << "enter first , sencod number and the number of series";
cin>>fn>>sn>>N;
fibonnaci( fn, sn, N);
return 0;
}
*/

//P6
/*
#include<iostream>
using namespace std;
int sum(int n)
{
int sum=0;	
	while(n>0)
	{
		sum =sum+n%10;
		n=n/10;
	}
return sum;
}

int singledigit(int n )
{
	while (n >= 10) 
	{
		n = sum(n);
	}
return n;
}

int main() 
{
	int inNum;

	cout << "Enter a number: ";
	cin >> inNum;
	int sdigit =singledigit(inNum);
	cout << "The sum of separate  digits from input value  " << sdigit <<endl;
	return 0;
}*/

//P7
/*#include<iostream>
using namespace std;
int sum(int x,int y )
{	
cout<<x+y;
return 0;
}
int sub(int x,int y )
{	
cout<<x-y;
return 0;
}
int mul(int x,int y )
{	
cout<<x*y;
return 0;
}
int div(int x,int y )
{	
cout<<x/y;
return 0;
}
int main()
{
	int x,y;
	int c;
	cout<<"enter two numbers ";
	cin>>x>>y;
	cout<<"enter 1 to add "<<endl;
		cout<<"enter 2 to multipty "<<endl;
			cout<<"enter 3 to subtraction "<<endl;
				cout<<"enter 4 to divide"<<endl;
				cout<<"enter 5 for exit"<<endl;	
				cin>>c;		
 switch(c)
{
case 1:
	sum(x,y);
	break;
	case 2:
	mul(x,y);
	break;
	case 3:
	sub(x,y);
	break;
	case 4:
	div(x,y);
	break;
	case 5:
cout<<"program end"<<endl;	
	break;
	default:
		cout<<"enter valid choice ";
}
return 0;
}*/

//lab quiz 2
//Task 1
/*#include<iostream>
using namespace std;
bool Palin(int a) 
{
    if (a < 0)
        return false;
    int oX = a;
    int rX = 0;
    while (a > 0) 
	{
        int y = a % 10;
        rX = rX * 10 + y;
        a =a /10;
    }
    return oX == rX;
}

int main() 
{
    int num;
    cout << "Enter no ";
    cin >> num;

    if (Palin(num))
	 {
        cout << num << " is a palindrome." << endl;
    }
    else {
        cout << num << " is not a palindrome." << endl;
    }

    return 0;
}*/

//task 2
/*
#include<iostream>
using namespace std;
bool Prime(int n)
 {
	if (n <= 1)
	return false;
	for (int i = 2; i * i <= n; i++) 
	{
		if (n % i == 0)
		 {
			return false;
		}
	}
	return true;
}
bool Perfect(int n) 
{
	int sum = 1; 
	for (int i = 2; i * i <= n; i++) 
	{
		if (n % i == 0)
		 {
			sum =sum + i;
			if (i != n / i) 
			{
				sum =sum+ n / i;
			}
		}
	}
	return sum == n;
}
bool fun(int number)
 {
	int sum = 0;
	int temp = number;
	while (temp > 0) 
	{
		sum =sum+ temp % 10;
		temp=temp/ 10;
	}
	if (Prime(sum - 1))
	 {
		return true;
	}
	int numDigits = 0;
	int fs = 0;
	int ss = 0;
	temp = number;
	while (temp > 0) 
	{
		int digit = temp % 10;
		if (numDigits % 2 == 0)
		 {
			fs =fs+ digit;
		}
		else 
		{
			ss= digit;
		}
		temp =temp/ 10;
		numDigits++;
	}
		int difference = (fs - ss);
	if (Perfect(difference)) {
		return true;
	}

	return false;
}
	int main()
	 {
	int number;
	cout << "Enter a number: ";
	cin >> number;

	if (fun(number))
	 {
		cout << "The number is funny." << endl;
	}
	else 
	{
	cout << "The number is serious." << endl;
	}

	return 0;
}*/

  /*THANKYOU very much... Respected SIR! MUHAMMAD AIZAZ AKMAL and  Respected MA'AM! ZOHA SOHAIL
					   for this opportunity to make this assignment.*/
