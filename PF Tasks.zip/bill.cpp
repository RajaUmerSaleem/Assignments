#include<iostream>
using namespace std;
int main()
{
int u;
cout<<"Enter number of units";
cin>>u;	
if (u<=50)
	u=u*20;
else if (u<=150)

	u=(20*50)+((u-50)*25);

else if (u<=250)

	u=(20*50)+(100*25)+((u-150)*30);

else if (u<=500)

	u=(20*50)+(100*25)+(100*30)+((u-250)*35);

u=u+u*.2;
cout<<u<<"rupees";
return 0;
}

