#include<iostream>
#include<string>
using namespace std;
                        //lab1 problem 0
/*int main(){
   string N,D;
   int A,S;
   cout<<"Enter the name: ";
   cin.ignore();
   getline(cin,N);
   cout<<"Enter the Age: ";
cin>>A;
cout<<"Enter the Department: ";
cin.ignore();
getline(cin,D);
cout<<"Enter the Salary: ";
cin>>S;
cout<<"Employee Name is "<<N<<"."<<"He is "<<A<<" years old and belongs to the "<<D<<" department having monthly salary "<<S<<" Reupees.";
   
    return 0;
}*/

                         //lab1 problem 1
 /*int main(){
string N,R;
int A,C;
cout<<"Enter the Name: ";
cin.ignore();
getline(cin,N);
cout<<"Enter the  Age: ";
cin>>A;
cout<<"Enter the Roll Num: ";
cin.ignore();
getline(cin,R);
cout<<"Enter the CNIC: ";
cin>>C;
cout<<"My Name is "<<N<<". I am "<<A<<" years old, and my student ID is "<<R<<" and my CNIC is "<<C;

    return 0;
}*/

                //lab1 problem 2
/*int main() {

	int l, w, h, v;
	cout << "Enter the length of the box: ";
	cin >> l;
	cout << "Enter the width of the box: ";
	cin >> w;
	cout << "Enter the height of the box: ";
	cin >> h;
	v = l * w * h;
	cout << "The volume of the box is: " << v;


return 0;
}*/
                //lab1 problem 3
           /* int main(){
float E,C,P,Am;
int Pa;
cout<<"Enter the Marks in English: ";
cin>>E;
cout<<"Enter the Marks in Calculus: ";
cin>>C;
cout<<"Enter the  Marks in PF: ";
cin>>P;
Am=(E+C+P)/3;
Pa=((E+C+P)/300)*100;
cout<<"The average of Marks is: "<<Am<<endl<<"The percentage of Marks is: "<<Pa<<"%";


                    return 0;
                }  */

                 //lab1 problem4

                /* int main(){
float R,H,V;
cout<<"Enter the Radius: ";
cin>>R;
cout<<"Enter the height: ";
cin>>H;
V=3.14*R*R*H;
cout<<V;

                    return 0;
                 } */


                 //lab1 problem5

                /*  int main() {
	int Bs, Ms, Ha, Ts,Aa;
	cout << "Enter the basic sallary of Ali: ";
	cin >> Bs;
	Ms = (30*Bs)/100;
	Ha = (25 * Bs) / 100;


   Ts = Bs + Ms + Ha;
	cout<<"Ali's Gross Monthly sallary is:  " << Ts<<"Rs";
    Aa=Ts*12;
    cout<<endl<<"Ali's Gross Annual Sallary is: "<<Aa<<"Rs";

return 0;
} */


          //lab1 problem6

 /* int main(){

int a,b,c,d;
cout<<"Enter the Note of 1000: ";
cin>>a;
cout<<"Enter the Note of 500: ";
cin>>b;
cout<<"Enter the Note of 100: ";
cin>>c;
cout<<"Enter the Note of 50: ";
cin>>d;
d=a*1000+b*500+c*100+d*50;
cout<<"Total amount he doposits: "<<d;
                return 0;
} */



//lab2 question 1

  /* int main(){
int x,y,z;
cout<<"Enter First Side of Triangle: ";
cin>>x;
cout<<"Enter Second Side of Triangle: ";
cin>>y;
cout<<"Enter Third Side of Triangle: ";
cin>>z;
if(x+y+z==180){
cout<<"This is a valid Triangle";
}
else{
cout<<"Thsi is not a valid Triangle";
}
return 0;
} */


//lab2 question 2

 /*  int main(){
    int x,y,z;
    cout<<"Enter First Side of Triangle: ";
cin>>x;
cout<<"Enter Second Side of Triangle: ";
cin>>y;
cout<<"Enter Third Side of Triangle: ";
cin>>z;
if(x+y+z==180){
cout<<"This is a valid Triangle";
        if(x==y&&y==z){
            cout<<endl<<"This is an equilatral  triangle";
        }
        if(x==90||y==90||z==90){
            cout<<endl<<"This is a right angle triangle";
        }
        if(x!=y&&y!=z){
            cout<<endl<<"This is a scalene triangle";
        }
}
else{
cout<<endl<<"This  is not a valid Triangle";
}
if(x<90&&y<90&&z<90){
    cout<<endl<<"This is an acute triangle";
}

return 0;
} */
     
       
                //lab2 Question3

               /* int main(){
                    int X,Y;
                    cout<<"Enter the value of X: ";
                    cin>>X;
                    cout<<"Enter the value of Y: ";
                    cin>>Y;
         
                    if(X==0&&Y==0){
                        cout<<"The point lies on origin";
                    }
                    if(X>0&&Y>0){
                        cout<<"Point lies in I Quadrant";
                    }
                    if(X>0&&Y<0){
                        cout<<"Point lies in IV Quadrant";
                    }
                   if(X<0&&Y>0){
                        cout<<"Point lies in II Quadrant";
                    }
                    if(X<0&&Y<0){
                        cout<<"Point lies in III Quadrant";
                    }
                    if(X==0&&Y>0){
                        cout<<"Point lies on +ve y-axis";
                    }
                          if(X>0&&Y==0){
                        cout<<"Point lies on +ve x-axis";
                    }
                          if(X<0&&Y==0){
                        cout<<"Point lies on -ve x-axis";
                    }
                if(X==0&&Y<0){
                    cout<<"Point lies on -ve y-axis";
                }
                    
 return 0;
                } */

                //lab2 question4

                 /* int main(){
                    int a,b,c,d;
                    cout<<"Enter a three-digit number: ";
                    cin>>a;
                    b=a/100;
                    c=(a%100)/10;
                    d=(a%100)%10;
                    if(b==d){
                        cout<<"The number is palindrome";
                    }
                    else{
                        cout<<"The number is not palindrome";
                    }
                    
                    
                    return 0;
                } */


                //lab2 question5

              /*  int main(){
                    int a,b,c,d,e,f,g,h;
                    cout<<"Enter first number: ";
                    cin>>a;
                    cout<<"Enter second number: ";
                    cin>>b;
                    cout<<"Enter 1 for Addition";
                    cout<<endl<<"Enter 2 for Multiply";
                    cout<<endl<<"Enter 3 for Subtraction";
                    cout<<endl<<"Enter 4 for Divide";
                    cout<<endl<<"Enter 5 for Modulus"<<endl;
                    cin>>c;
                    if(c==1){
                        d=a+b;
                cout<<endl<<"The addition of two numbers is: " <<d;
                    }
                    if(c==2){
                        e=a*b;
                     cout<<endl<<"The multiplication of two numbers is: " <<e;
                    }
                    if(c==3){
                        f=a-b;
                             cout<<endl<<"The subtraction of two numbers is: " <<f;                }
                        if(c==4){
                            g=a/b;
                             cout<<endl<<"The division of two numbers is: " <<g;
                        }
                    if(c==5){
                        h=a%b;
                         cout<<endl<<"The modulus of two numbers is: " <<h;
                    }
     return 0;
                }  */

                //lab2 question 6

               /* int main(){
                    float a;
                    cout<<"Enter your marks here: ";
                    cin>>a;
                    if(a>=75){
                        cout<<endl<<"Passed: Grade A";
                    }
                    else{
                        if(a>=60){
                            cout<<endl<<"Passed: Grade B";
                        }
                        else{
                            if(a>=45){
                                cout<<"Passed: Grade C";
                            }
                            else{
                                cout<<"Failed";
                            }
                        }
                    }
                return 0;
                } */