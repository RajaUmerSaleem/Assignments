#include<iostream>
#include<cstdlib>
using namespace std;
int main() {
	
cout<<rand()<<endl;
cout<<rand()<<endl;
cout<<rand()<<endl;
cout<<rand()<<endl;
}

