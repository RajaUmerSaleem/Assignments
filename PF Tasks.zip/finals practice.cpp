/*#include <iostream>
using namespace std;

void swap(char *x, char *y)
 {
    char *t = x;
    x = y;
    y= t;
}
int main() {
    char x[] = "hello";
    char y[] = "welcome";
    char *t;
    swap(x, y);
    cout << x << " " << y << endl;
    return 0;
}*/
/*
int main()
{
int a=30 , b=80 , c = 8;

int *p1=&a , *p3, *p2=&c;

p3=&b;

p3=p1;

b = *p3;

*p2=*p1;
cout << a << b << c;

return 0;
}*/
/*
#include <iostream> 
using namespace std;
struct TwoVals

{

int a = 5;

int b = 10;

};

int main()
{

TwoVals v;

cout << v.a << " " << v.b;

return 0;

}*/
/*
int main() {

int arr[20];

int i;
for (i = 0; i < 10; i++)
arr[i]= 97 + i;
cout<< *arr;
return 0;
} 
*/
/*
int main()
{
int a=10 ;
int *p=&a;
int **q= &p;
int b=20 ;
(*p) ++;
cout<<a <<" "<<b;
return 0;
}*/
/*
int main()
{
int numbers[5] = {10, 20, 30, 40, 50};
 cout << "The third element in the array is "; 
 cout << *(numbers + 3)*2 << endl;
}
*/
/*
#include <iostream>
using namespace std;

struct Play {
    int score, bonus;
};

void calculate(Play &P, int N = 10) {
    P.score++;
    P.bonus += N;
}

int main() {
    Play PL = {10, 15};

    calculate(PL, 51);
    cout << PL.score << ":" << PL.bonus << endl;

    calculate(PL);
    cout << PL.score << ":" << PL.bonus << endl;

    calculate(PL, 15);
    cout << PL.score << ":" << PL.bonus << endl;

    return 0;
}*/
/*
double totalSales(double *arr, int size);
int main()
{
const int QTRS = 4;
double sales[QTRS]={1200,4200, 5000, 6000};
 cout << "The total sales for the year are Rs";
  cout << totalSales(sales, QTRS) << endl;
return 0;
}
double totalSales(double *arr, int size)
{
double sum = 0.0;
 for (int count = 0; count < size; count++)
{
	sum += *arr;
	arr++;
}
return sum;
}*/
/*
int main()
{
int m[4][4]={{1,2,3,4},{4,5,6,7},{8,9,10,11},{12,13,14,15}};
int m2[4][4]={{1,1,1,1},{2,2,2,2},{1,1,1,1},{2,2,2,2}};
int sum=0;
for(int r =0;r<4;r++)
{
	for(int c =0;c<4;c++)
	{
		sum+=m[r][c];
	}
}
for(int r =0;r<4;r++)
{
	for(int c =0;c<4;c++)
	{
		sum+=m2[r][c];
	}
}
cout<<sum<<"\n";
return 0;
}*/
#include<iostream>
#include<ctime>
using namespace std;
int main()
{
	time_t currentTime = time(NULL); 
	string currentDate = ctime(&currentTime);
	string now_time=currentDate;
	cout<<"Currect date"<<now_time<<endl;	
}

	



