#include<iostream>
using namespace std;
int main()
{ 
int a,b,c;

cout<<"Enter the first Number :";
cin>>a;
cout<<"Enter the second Number :";
cin>>b;
cout<<"Enter the third Number :";
cin>>c;

if (a>b&&a>c)
cout<<"Largest number is"<<a;
else if(b>c&&b>a)
cout<<"Largest number is"<<b;
else 
cout<<"Largest number is"<<c<<endl;

if(a<b&&a<c)
cout<<"smallest number is"<<a;
else if (b<c&&b<a)
cout<<"smallest number is"<<b;
else 
cout<<"smallest number is"<<c;
return 0;	
}	
