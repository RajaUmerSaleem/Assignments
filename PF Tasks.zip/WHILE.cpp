#include<iostream>
using namespace std;
int main() {
	
int y =1;
lab:
cout<<y<<"\tRAJA UMER SALEEM"<<endl;
y++;
if(y<=100)
goto lab;
}

