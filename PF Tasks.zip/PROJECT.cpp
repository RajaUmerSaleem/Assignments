#include<iostream>
#include <windows.h>
#include<string>
using namespace std;
int bill=0;
string decide="";
   int choice=0;
struct car{
	string name,model,reg;
	int price;
	bool rent;
};
struct client{
	string name,cnic;
	int price;
};
 client cli[5];
 void cheader()
{
    cout<<endl;	
    cout << "\t\t\t|----------------------------------|" << endl;
    cout << "\t\t\t|----- CAR RENTAL MENU SYSTEM -----|" << endl;
    cout << "\t\t\t|------- ENJOY OUR SERVICE --------|" << endl;
    cout << "\t\t\t|----------------------------------|" << endl;
    cout<<endl;
    cout<<endl;
    cout<<endl;
}
void rent( car c[5])
{
	cout<<"\n\n";	
	int cn,t;
	cout<<"\t\t\tEnter no of car, want to rent"<<endl;
	cin>>cn;
	cout<<"\t\t\tEnter no of hours.."<<endl;
	cin>>t;
	cin.ignore();
	cout<<"\t\t\tEnter your name"<<endl;
	getline(cin,cli[cn-1].name);
	cout<<"\t\t\tEnter your cinc"<<endl;
	getline(cin,cli[cn-1].cnic);
    if(t<=5 && c[cn-1].rent == false)
	{
	system("CLS");
	cheader();
	cout<<"\n\n\n";	
	cout<<"\t\t\tOk Sir! you want to rent "<<c[cn-1].name<<" for "<<t<<"/hours"<<endl;
cout<<"\t\t\t Car Name: "<<c[cn-1].name<<endl;
cout<<"\t\t\t Car Reg.NO: "<<c[cn-1].reg<<endl;
cout<<"\t\t\t Car Model: "<<c[cn-1].model<<endl;
c[cn-1].rent = true;
cout<<"\t\t\t";
cout<<c[cn-1].name<<" is Rented... "<<endl;
bill=bill+t*c[cn-1].price;
}
else if(cn>5)
cout<<"You are choosing invalid option"<<endl;
else
  cout<<"You must rent a avaible car for maximum five hours"<<endl;
}
car c[5] = {{"Audi", "R8", "1",3000, false},
                {"Mahindra", "Thar", "02",2000, false},
                {"SUZUKI", "Cultus", "7",500, false},
                {"BMW", "i8", "5",3500, false},
                {"KIA", "Sorento", "8",2000, false}};
void menu()
{
	cheader();
    system("CLS");
    cheader(); 
    cout<<endl;
    cout<<endl;
    cout<<"\t\t\t 1:Rent a car"<<endl;
    cout<<"\t\t\t 2:Return a car"<<endl;
    cout<<"\t\t\t 3:View available cars"<<endl;
    cout<<"\t\t\t 4:View your bill"<<endl;
    cout<<"\t\t\t 5:Logout"<<endl; 
	cout<<"\t\t\t 6:View report"<<endl; 
    cout<<"\t\t\t";
    cin>>choice; 
}
int main()
{
	string rc; //returnCar var
    string pass, id;
    string  cid="client";
    string  oid="owner";
    string  cpass="clientM@123";
    string  opass="ownerM@123";
   
    int n; 
login:
system("CLS");	
cheader();
    cout<<"\t\t\tYOU WANT TO LOG IN CAR RENTAL MENU SYSTEM"<< endl;
    cout<<"\t\t\t 1:Login as CUSTOMER " << endl;
    cout<<"\t\t\t 2:Login as ADMIN " << endl;
    cout<<"\t\t\t";
    cin >> n;
while(decide!="yes")
{
if(n==1)
{
       cin.ignore();
cout<<endl<<"\t\t\tEnter ID: ";
            getline(cin, id);
            cin.ignore();
cout<<"\t\t\tEnter password: ";
            getline(cin, pass);
           if(id==cid&&pass==cpass)
           {
        cout<<"\t\t\t....Access Granted...."<<endl;
        system("PAUSE");
       	  decide="yes";
	       }
	   	else
         {
		 cout << "\t\t\tWrong password or ID, try again." << endl;
		 decide!="no";
         }
}
}
    while (decide!="no")
    {
    system("CLS");
    menu();
switch(choice) 
{
case 1:
    system("CLS");
    cheader();
    cout<<endl;
    cout<<"\t\t\t Cars List"<<endl;
    for(int i=0;i<5;i++)
{
cout<<"\t\t\t---------------------"<<endl;
cout<<"\t\t\t\t("<<i+1<<")"<<endl;
cout<<"\t\t\tCar Name: "<<c[i].name<<endl;
cout<<"\t\t\tCar Reg.NO: "<<c[i].reg<<endl;
cout<<"\t\t\tCar Model: "<<c[i].model<<endl;
cout<<"\t\t\tCar Price: "<<c[i].price<<"/hour "<<endl;
if (c[i].rent==false)
cout<<"\t\t\tAvailable"<<endl;
else
cout<<"\t\t\tUn-Available"<<endl;
			}
			rent(c);
		  system("PAUSE");	
break;
		case 2:
			cout<<"Ok Sir! You want to return car"<<endl;
			cout<<"----- Rented Cars -----"<<endl;
	     		for(int i=0;i<5;i++)
    		{
    	if (c[i].rent==true){
cout<<"Car Name: "<<c[i].name<<endl;	
	}
}
	cout<<" Which you want to return"<<endl;
	cin>>rc;
 for(int i=0;i<5;i++)
   	{
    if (c[i].rent==true){
if(rc==c[i].name);
{
c[i].rent=false;
cout<<c[i].name<<" is returned successfully"<<endl;
cout<<endl;
	cout<<"----------------------------------"<<endl;
	cout<<"Thank-You for enjoying our service"<<endl;
	cout<<"----------------------------------"<<endl;
	system("PAUSE");
	}	 
	}
}	
break;
case 3:
cout<<"----- Available Cars -----"<<endl;
for(int i=0;i<5;i++)
{
if (c[i].rent==false){
cout<<"Car Name: "<<c[i].name<<endl;	
	}
}
cout<<"--------------------------"<<endl;
	system("PAUSE");
	break; 
	case 4:
		cout<<"the total bill is "<<bill<<endl;
  system("PAUSE");
            break;
            case 5:
            	decide="no";
            	goto login;
            	break;
            	case 6:
    cout<<"----------------------------------"<<endl;
	cout<<"............. Report ............."<<endl;
	cout<<"----------------------------------"<<endl;
for(int i=0;i<5;i++)
{	
if (c[i].rent==true)
    {	
      cout<<"Customer Name:"<<cli[i].name<<endl;	
      cout<<"Customer CNIC:"<<cli[i].cnic<<endl;	
      cout<<"Rented Car :"<<c[i].name<<endl;
	}
	cout<<"\n";
    }
system("PAUSE");
break;
            	default :
            	cout<<"wrong input"<<endl;
		    }
		}
return 0;
}
// admin
//        while (true)
//        {
//            cout << "\t\t\tEnter password and ID: ";
//            cin.ignore();
//            getline(cin, pass);
//            getline(cin, id);
//          if(pass==opass&&id==oid)
//            {
//    system("CLS");
//    cout << "\t\t\t|----------------------------------|" << endl;
//    cout << "\t\t\t|-------- DEAR OWNER!! ------------|" << endl;
//    cout << "\t\t\t|--------- YOU LOGINED ------------|" << endl;
//    cout << "\t\t\t|----------------------------------|" << endl;
//            break;
//            }
//            else
//                cout << "\t\t\tWrong password or ID, try again." << endl;
//        }
//        break;
//    default:
//        cout << "\t\t\tInvalid choice" << endl;
//    }
