 /*#include<iostream> 
using namespace std;
void palindrome(int num)
{
int orignal=num;
int reverse=0;
while(num!=0)
{
	int temp =0;
	temp =num%10;
	reverse=reverse*10+temp;
	num=num/10;
}
cout<<reverse<<endl;
cout<<orignal<<endl;
if(orignal==reverse)
cout<<"it is palindrome";
else
cout<<"it is not palindrome";
}

int main ()
{
	int num ;
	cout<<"enter a number";
	cin>>num;
	palindrome(num);
}*/

/*
#include<iostream> 
using namespace std;
int main()
{
	int num ,len,temp,sum,c,ncheck,v;
c=sum=0;
	cout<<"enter a number";
	cin>>num;
//	cout<<"enter its lenth";
//	cin>>lenth;
while(num!=0)
{
	temp=num%10;
	sum=sum+temp;
	num=num/10;
}
ncheck=sum-1;
for(int i=1;i<=ncheck;i++)
{
v=ncheck%i;
if(v==0)
{
	c++;
}
}
if(c==2)
cout<<"prime no ";
return 0;
}*/
/*
#include<iostream> 
using namespace std;
int main()
{
		int num,len,n,t,sum1,sum2,c,temp1,temp2;
		cin>>num;
		t =num;
		sum1=0;
		
		 n=len/2;
		 int i=1;
		 while(i<=n)
		 {
		 	temp1=num%10;
		 	sum1=sum1+temp1;
		 	num=num/10;
		 }
		 cout<<sum1;
		 
		  int j=1; 
		 	 while(j<=n)
		 {
		 t=t/10;
		 c++;
		 if(c==len/2)
		 {
		 	temp2=t%10;
		 	sum2=sum2+temp2;
		 }
}
	cout<<sum2;
return 0;
		 }*/
		 /*
#include<iostream>
#include<windows.h>
#include<conio.h>
using namespace std;

bool gameover;
const int w = 20;
const int h = 20;
int headx, heady, fruitx, fruity, score;
int tailx[100], taily[100], ntail;
enum edirection {stop = 0, LEFT, RIGHT, UP, DOWN};
edirection dir;

void setup()
{
	gameover = false;
	dir = stop;
	score = 0;
	ntail = 0;
	headx = w / 2;
	heady = h / 2;
	fruitx = rand() % w;
	fruity = rand() % h;
}
void draw()
{
	system("cls");
	for (int i = 0; i <= w + 1; i++)
	{
		cout << "#";
	}
	cout << endl;
	for (int i = 0; i < h; i++)
	{
		for (int j = 0; j <= w; j++)
		{
			if (j == 0)
			{
				cout << "#";
			}
			if (headx == j && heady == i)
			{
				cout << "O";
			}
			else if (fruitx == j && fruity == i)
			{
				cout << "A";
			}
			else
			{
				bool print = false;
				for (int k = 0; k < ntail; k++)
				{
					if (tailx[k] == j && taily[k] == i)
					{
						cout << "o";
						print = true;
					}
				}
				if (!print)
				{
					cout << " ";
				}
			}
			if (j == w - 1)
			{
				cout << "#";
			}
		}
		cout << endl;
	}
	for (int i = 0; i <= w + 1; i++)
	{
	 	cout << "#";
	}
	cout << endl;
	cout << "score : " << score << endl;
}
void input()
{
	if (_kbhit())
	{
		switch (_getch())
		{
		case'a':
			dir = LEFT;
			break;
		case'd':
			dir = RIGHT;
			break;
		case's':
			dir = DOWN;
			break;
		case'w':
			dir = UP;
			break;
		case'x':
			gameover = true;
			break;
		default:
			break;
		}
	}
}
void logic()
{
	int prevx = tailx[0];
	int prevy = taily[0];
	int prev2x, prev2y;
	tailx[0] = headx;
	taily[0] = heady;
	for (int i = 1; i < ntail; i++)
	{
		prev2x = tailx[i];
		prev2y = taily[i];
		tailx[i] = prevx;
		taily[i] = prevy;
		prevx = prev2x;
		prevy = prev2y;
	}
	switch (dir)
	{
	case LEFT:
		headx--;
	break;
	case RIGHT:
		headx++;
	break;
	case UP:
		heady--;
	break;
	case DOWN:
		heady++;
	break;
	default:
		break;
	}
//	if (headx > w || headx < O || heady > h || heady < O)
//	{
	//	gameover = true;
	//}
	if (headx >= w)
		headx = 0;
	else if (headx < 0)
		headx = w - 1;
	if (heady >= h)
		heady = 0;
	else if (heady < 0)
		heady = h - 1;
	for (int i = 0; i < ntail; i++)
	{
		if (tailx[i] == headx && taily[i] == heady)
		{
			gameover = true;
		}
	}
	if (headx == fruitx && heady == fruity)
	{
		score = score + 10;
		fruitx = rand() % w;
		fruity = rand() % h;
		ntail++;
	}
}

int main()
{
	setup();
	while (!gameover)
	{
		draw();
		input();
		logic();
		Sleep(100);
	}
	return 0;
}*/
/*
#include<iostream> 
using namespace std;
int main()
{
	int i,j;
int a[3][3];
for(i=0;i<3;i++){
	for( j=0;j<3;j++)
{
		cin>>a[i][j];
}
}
for(int i=0;i<3;i++)
{
	for(int j=0;j<3;j++)
	cout<<a[i][j]<<"	";
	cout<<endl;
}
}
*/
//reversing row
/*
#include<iostream> 
using namespace std;
int main()
{
	int i,j;
int a[3][3];
for(i=0;i<3;i++){
	for( j=0;j<3;j++)
{
		cin>>a[i][j];
}
}
for(int i=0;i<3;i++)
{
	for(int j=3-1;j>=0;j--)
	cout<<a[i][j]<<"	";
	cout<<endl;
}
}
*/
//taking transpose
/*
#include<iostream> 
using namespace std;
int main()
{
	int i,j;
int a[3][3];
for(i=0;i<3;i++){
	for( j=0;j<3;j++)
{
		cin>>a[i][j];
}
}
for(int j=0;j<3;j++){
  for(int i=0;i<3;i++)
	cout<<a[i][j]<<"	";
	cout<<endl;
}
}
*/
//revsing row 
/*
#include<iostream> 
using namespace std;
int main()
{
	int i,j;
int a[3][3];
for(i=0;i<3;i++){
	for( j=0;j<3;j++)
{
		cin>>a[i][j];
}
}
for(int i=0;i<3;i++)
{
	for(int j=3-1;j>=0;j--)
	cout<<a[i][j]<<"	";
	cout<<endl;
}
}*/
//reversing colmn
/*
#include<iostream> 
using namespace std;
int main()
{
	int i,j;
int a[3][3];
for(i=0;i<3;i++){
	for( j=0;j<3;j++)
{
		cin>>a[i][j];
}
}
for(int i=2;i>=0;i--)
{
	for(int j=0;j<3;j++)
	cout<<a[i][j]<<"	";
	cout<<endl;
} 
}*/
/*
#include<iostream> 
using namespace std;
int main()
{	
int index=0;
int miniindex=0;
int highest_marks=0;
int a[3][5];
int i,j;
for(i=0;i<3;i++){
	for( j=0;j<5;j++)
{
		cin>>a[i][j];
}
}
cout<<"   	std1	 std2	std3	std4	std5"<<endl;
for(int i=0;i<3;i++)
{
	cout<<"quiz "<<i+1<<"    ";
	{
	for(int j=0;j<5;j++)
	cout<<a[i][j]<<"	";
	cout<<endl; 
	}	
}
for(int i=0;i<3;i++)
{
int max=a[i][0];
	{
	for(int j=0;j<5;j++) 
	{
	if (max<a[i][j])
	{
	max=a[i][j];
	index=j;
	}
    }
cout<<"it is max in quiz "<<i+1<<" is "<<max<<"the indext is "<<i<<","<<index<<endl;
	}
}
cout<<endl;
for(int i=0;i<3;i++)
{
int min=a[i][0];
	{
	for(int j=0;j<5;j++) 
	{
	if (min>a[i][j])
	{
		min=a[i][j];
		miniindex=j;
	}
    }
cout<<"it is min in quiz "<<i+1<<" is "<<min<<"the indext is "<<i<<","<<miniindex<<endl;
	}	
}
for(j=0;j<5;j++)
{
highest_marks =a[0][j];
	for(i=0;i<3;i++)
	{
		if(highest_marks<a[i][j])
	highest_marks =a[j][i];
	}
	cout<<"highest marks are "<<highest_marks<<endl;
	}
}*/
/*
#include<iostream>
using namespace std;
	const int row = 3;
		const int column = 3;
void matrix(int a[row][column])
{
for(int i=0;i<row;i++)
	{
     	for(int j=0;j<column;j++)
     	{
		cout <<a[i][j]<<"  		";
    	}
   cout<<endl;
    } 
}
void transpose(int a[row][column])
{
for(int i=0;i<row;i++)
	{
     	for(int j=0;j<column;j++)
     	{
		cout <<a[j][i]<<"  		";
    	}
   cout<<endl;
    } 
}
void c_reverse(int a[row][column])
{
	for(int i=row-1;i>=0;i--)
	{
     	for(int j=0;j<column;j++)
     	{
	cout<<a[i][j]<<"  		";
    	}
    cout<<endl;
	} 
}
void r_reverse(int a[row][column])
{
	for(int i=0;i<row;i++)
	{
     	for(int j=column-1;j>=0;j--)
     	{
	cout<<a[i][j]<<"  		";
    	}
    cout<<endl;
	} 
}

int main()
{

		int a[row][column];
	cout<<"entre the 9 numbers to make matrix"<<endl;
	for(int i=0;i<row;i++)
	{
     	for(int j=0;j<column;j++)
     	{
		cin>>a[i][j];
    	}
    	
    } 
    cout<<"	     MATRIX "<<endl;
    matrix(a);
    cout<<endl;
cout<<"	     TRANSPOSE "<<endl;

 transpose(a);
cout<<"	   REVERSE COLUMN "<<endl;
c_reverse(a);
  cout<<"	   REVERSE ROW  "<<endl;
r_reverse(a);
}*/
/*
#include<iostream>
using namespace std;
int main()
{
	int max;
int a[3][5];
	for(int i=0;i<3;i++)
	{
     	for(int j=0;j<5;j++)
     	{
		cin>>a[i][j];
    	}
    	
    } 
cout<<"	 student1	student2	student3	student4	student5"<<endl;
	for(int i=0;i<3;i++)
	{
		cout<<"Quiz"<<i+1<<"\t";
     	for(int j=0;j<5;j++)
     	{
		cout<<a[i][j]<<"\t\t";
    	}
    cout<<endl;
	} 
	for(int i=0;i<3;i++)
	{ 
	max =a[i][0];
    for(int j=0;j<5;j++)
    {
	if(a[i][j]>max)
	max=a[i][j];
    }
    cout<<"the maximum number in quiz "<< i+1<<" is "<<max<<endl;
	} 	
}*/
/*
#include<iostream>
using namespace std;
struct Std{
	string name,rollnumber;
	int age;
	float marks;
};
int main()
{
Std s1;
cout<<" Enter your name:";
getline(cin,s1.name);
cout<<" Enter your roll-number:";
getline(cin,s1.rollnumber);
cout<<" Enter your age:";
cin>>s1.age;
cout<<" Enter your marks:";
cin>>s1.marks;
cout<<" Your name:";
cout<<s1.name<<endl;
cout<<" Your roll-number:";
cout<<s1.rollnumber<<endl;
cout<<" Your age:";
cout<<s1.age<<endl;
cout<<" Your marks:";
cout<<s1.marks<<endl;	
}
*/
/*
#include<iostream>
using namespace std;
struct Std{
	string name,rollnumber;
	int age;
	float marks;
};
int main()
{
Std s[5];
for(int i=0;i<5;i++)
{
	
cout<<" Enter your name:";
getline(cin,s[i].name);
cout<<" Enter your roll-number:";
getline(cin,s[i].rollnumber);
cout<<" Enter your age:";
cin>>s[i].age;
cout<<" Enter your marks:";
cin>>s[i].marks;
cout<<endl;
cin.ignore();
}
for(int i=0;i<5;i++)
{
cout<<" Your name:";
cout<<s[i].name<<endl;
cout<<" Your roll-number:";
cout<<s[i].rollnumber<<endl;
cout<<" Your age:";
cout<<s[i].age<<endl;
cout<<" Your marks:";
cout<<s[i].marks<<endl;	
}
}*/
/*
#include<iostream>
#include<string>
using namespace std;
struct Car{
	char carMake[20];
	char carModel[20];
	int yearModel;
	double cost;
};
int main()
{
	Car c1={"Ford","Mustang",1996,20000};	
cout<<"Make:"<<c1.carMake;
	cout<<"Model:"<<c1.carModel;
cout<<"Year Model:"<<c1.yearModel;
cout<<"Cost: $"<<c1.cost;
}*/
/*
#include<iostream>
using namespace std;
int main()
{
int a[5]={10,20,30,40,50};
int *pty;
int *ptx=&a[0];
cout<<&a[0]<<endl; 
cout<<ptx<<endl; 
pty=ptx;
cout<<pty;
}*/
//#include<iostream>
//#include<string>
//using namespace std;
//int main()
//{
//	cout<<"   ******"<<endl;
//    cout<<"  **********"<<endl;
//    cout<<"*******************"<<endl;
//    cout<<"******************"<<endl;
//    cout<<"    @@         @@  "<<endl;
//    
//}
/*
#include<iostream>
#include<string>
using namespace std;
int main()
{
int x=10;
int *ptr=&x;
cout<<ptr<<endl;
cout<<*ptr;
cout<<"Value changed"<<endl;
*ptr=30;
cout<<x;
}*/
/*
#include<iostream>
#include<string>

using namespace std;

struct customer{
	string name,cnic,email;
};
int main()
{
	
customer *ptr;
ptr= new customer[5];
for (int i=0;i<5;i++)
{
	cin>>ptr[i].name;
	cin>>ptr[i].cnic;
	cin>>ptr[i].email;
}
for (int i =0;i<5;i++)
{
{
	cout<<ptr[i].name;
	cout<<ptr[i].cnic;
	cout<<ptr[i].email;
}
cout<<endl;
}
delete ptr;
}*/
/*
#include <iostream>
#include <string>

using namespace std;

// Using struct instead of class - members are public by default
struct Customer {
    string name;
    int age;

    // Display customer information
    void display() const {
        cout << "Name: " << name << ", Age: " << age << endl;
    }
};

int main() {
    // Get the number of customers from the user
    int numCustomers;
    cout << "Enter the number of customers: ";
    cin >> numCustomers;
    Customer* customerArray = new Customer[numCustomers];

    for (int i = 0; i < numCustomers; ++i) {
        cout << "Enter customer " << (i + 1) << " details:" << endl;
        cout << "Name: ";
        cin >> customerArray[i].name;
        cout << "Age: ";
        cin >> customerArray[i].age;
    }

    // Display customer information
    cout << "\nCustomer Report:\n";
    for (int i = 0; i < numCustomers; ++i) {
        customerArray[i].display();
    }
    delete[] customerArray;

    return 0;
}*/
/*
#include <iostream>
#include <string>
#include <fstream>
       using namespace std;
       struct Customer {
         string user,upass,id,pass;
               };
               int count=0;
                Customer c;
               void login()
               {
           	    cin.ignore();
           	getline(cin,c.user);
           	 cin.ignore();
           	getline(cin,c.upass);
           	ifstream read("record.txt");
           	while(read>>c.id>>c.pass)
           	{
           		if(c.user==c.id&&c.upass==c.pass)
           		{
           			count=1;
			}
			   }
			   read.close();
			   if(count==1)
			   {
			   	cout<<"login successfully"<<endl;
			   }
			   else
			   cout<<"id not found"<<endl;
			   }
			   void reg()
			   {	
			    	    cin.ignore();
           	getline(cin,c.user);
           	 cin.ignore();
           	getline(cin,c.upass);
			   ofstream add("record.txt",ios::app);
			   add<<c.user<<' '<<c.upass<<endl;
			   cout<<"registored successfully..";
			   }
			   int main()   
        {
        	int choice;
while(true)
{
        	cout<<"1: Regiration"<<endl;
            cout<<"2: Login"<<endl;
            cin>>choice;
            switch(choice)
            {
		
            case 1:
            	reg();
            	break;
            case 2:
            	login();
            	break;	
            	default:
            		cout<<"invalid input";
            	}
					   }
				}
			 */
			 /*
#include <iostream>
#include <string>
#include <fstream>
using namespace std;

struct Customer {
    string user, upass, id, pass;
};

int count = 0;
Customer c;

void login() {
	cin.ignore();
    getline(cin, c.user);
    getline(cin, c.upass);

    ifstream read("record.txt");
    while (read >> c.id >> c.pass)
	 {
        if (c.user == c.id &&c.upass == c.pass) 
		{
            count = 1;
        }
    }
    read.close();
cout<<count<<endl;
    if (count == 1) {
        cout << "Login successfully" << endl;
        count=0;
    } else {
        cout << "ID not found" << endl;
    }
}
void reg() {
		cin.ignore();
    getline(cin, c.user);
    getline(cin, c.upass);
    cout<<c.user<<endl;
    cout<<c.upass<<endl;
    ofstream add("record.txt", ios::app);
    add << c.user << ' ' << c.upass <<endl;
    add.close();
    cout << "Registered successfully" << endl;
}

int main() {
    int choice;

    while (true) {
        cout << "1: Registration" << endl;
        cout << "2: Login" << endl;
        cout << "Enter choice (0 to exit): ";
        cin >> choice;

        if (choice == 0) {
            break;
        }

        switch (choice) {
            case 1:
                reg();
                break;
            case 2:
                login();
                break;
            default:
                cout << "Invalid input" << endl;
        }
    }
    return 0;
}
/*
#include <iostream>
#include <string>
#include <fstream>

using namespace std;

struct Customer {
    string user, upass, id, pass;
};

Customer c;

bool login() {
    cin.ignore();
    cout << "Enter username: ";
    getline(cin, c.user);

    cout << "Enter password: ";
    getline(cin, c.upass);

    ifstream read("record.txt");

    while (read >> c.id >> c.pass) {
        if (c.user == c.id && c.upass == c.pass) {
            read.close();
            return true;
        }
    }

    read.close();
    return false;
}

int main() {
    if (login()) {
        cout << "Login successfully" << endl;
    } else {
        cout << "ID not found" << endl;
    }

    return 0;
}*/
/*
#include<iostream>
#include<conio.h>
#include<windows.h>
using namespace std;
int main ()
{
cout<<"\t\t\tLoading..."<<endl;
char x = 219;
for(int i=0;i<=27;i++)
{
	cout<<x;
	Sleep(150);
 } 
  cout<<endl<<"welcome"<<endl;
  return 0;
}
*/
/*
#include<iostream>
using namespace std;
/*
void swap(int *ptx,int *pty)
{
	int *temp;
	temp=ptx;
	ptx=pty;
	pty=temp;
	cout << *ptx <<endl;
	cout << *pty <<endl;
}
int main ()
{
	int x=1;
	int y=2;
	int *ptx;
	int *pty;
	ptx=&x;
	pty=&y;
	cout << "Before " <<endl<< *ptx <<endl<< *pty << endl;
	swap(ptx,pty);
}
	*/	
	/*
	void input(int *arr,int s)
	{
		for(int i =0;i<s;i++)
		{
			cin>>arr[i];
		}
	}
		void output(int *arr,int s)
	{
		for(int i =0;i<s;i++)
		{
			cout<<arr[i]<<"\t";
		}
	}
int main()
{
	int arr[10];
	int s;
	cin>>s;
input(arr,s);
 output(arr,s);
		   }	
		   */  
		   /*
	void input(int *arr[])
	{
	for(int i=0;i<3;i++)
{
		for(int j =0;j<5;j++)
		{
			cin>>arr[i][j];
		
		}
		
	}
}
		void output(int *arr[])
		{  
			for(int i=0;i<3;i++)
       {
		for(int j =0;j<5;j++)
		{
			cout<<arr[i][j]<<"\t";
	     }
	     cout<<endl;
        }
}
	int* sum1(int *ptr[],int sum[])
	{
for(int i=0;i<3;i++)
	{
	for(int j=0;j<5;j++)
	{
	sum[i]+=ptr[i][j];
	}
	}
	return sum;
	}
int main()
{
	int arr1[5],arr2[5],arr3[5];
	int *ptr[3];
	int sum[3]={0,0,0}; 
	ptr[0]=arr1;
	ptr[1]=arr2;
	ptr[2]=arr3;
	input(ptr);
	output(ptr);
    sum1(ptr,sum);
for(int i=0;i<3;i++)
{
	cout<<sum[i]<<endl;
}
}*/  
/*
	void input(int *arr[])
	{
	for(int i=0;i<3;i++)
{
		for(int j =0;j<5;j++)
		{
			cin>>arr[i][j];
		
		}
		
	}
}
		void output(int *arr[])
		{  
			for(int i=0;i<3;i++)
       {
		for(int j =0;j<5;j++)
		{
			cout<<arr[i][j]<<"\t";
	     }
	     cout<<endl;
        }
}
	int* sum1(int *ptr[],int sum[])
	{
for(int i=0;i<3;i++)
	{
	for(int j=0;j<5;j++)
	{
	sum[i]+=ptr[i][j];
	}
	}
	return sum;
	}
int main()
{
	int size;
	cin>>size;
	int sum[3]={0,0,0};
	int *ptr[3];

ptr[0]=new int[size];
ptr[1]=new int[size];
ptr[2]=new int[size];
	input(ptr);
	output(ptr);
    sum1(ptr,sum);
for(int i=0;i<3;i++)
{
	cout<<sum[i]<<endl;
}
}
*/

/*#include<iostream>
using namespace std;
 int main()
 {
 	int set[10];
 	int *ptr=&set[7];
 	*ptr=99;
 	cout<<"Stored Value:"<<set[7];
 }*/
 /*
 {
 	int size =20;
 	int *ptr= new int[size];
 for(int i=0;i<20;i++)
 {
 	cin>>ptr[i];
 }
 cout<<"array output by pointer"<<endl;
  for(int i=0;i<20;i++)
 {
 	cout<<ptr[i]<<"	";
 }
 delete []ptr;
 }*/
 /*
 {
 	int *tempNumbers= new int[5];
 	int **temp=&tempNumbers;
 	for(int i=0;i<5;i++)	
{
	cout<<*temp[i]<<endl;
	 } 	
delete []tempNumbers;
delete []temp;
 }*/
 /*
#include<iostream>
using namespace std;
struct stu{
	string name;
	int votes;
	float per;
};
 int main()
 {
 	int sum;
 	int size=5;
    cin>>size;
 	int total;
 	stu *ptr= new stu[size] ;
 	//for(int i=0;i<5;i++)
 	for(int i=0;i<size;i++)
 	{
		cout<<"enter name:";
 		cin.ignore();
 		getline(cin,ptr[i].name);
 		cout<<"enter votes:";
 		cin>>ptr[i].votes;
 		total+=ptr[i].votes;
 		cout<<"enter percentage of votes:";
 		cin>>ptr[i].per;	
	  }
	 cout<<"Candidate\t\t Votes\t\t  votes(%)"<<endl; 
	 //for(int i=0;i<5;i++)
	for(int i=0;i<size;i++)
 	 {

 		cout<<ptr[i].name<<"\t\t\t ";
 		cout<<ptr[i].votes<<"\t\t\t ";
 		cout<<ptr[i].per<<"\t\t\t ";
 		cout<<endl;
	 }
	 cout<<"Total\t\t "<<total;
	delete []ptr;
 }
 */
 /*
 #include<iostream>
using namespace std;
void dub(int *ptr,int size)
{
	if(size<=0)
	{
		cout<<"the array is not valid size"<<endl;
	}
	else
	{
	int *ptd =new int[size];
	 for(int i=0;i<size;i++)
 {
 	ptd[i]=ptr[i];
 	cout<<ptd[i]<<" ";
 }	
}
}
 int main()
 {
 	int size;
 	cout<<"size: ";
 	cin>>size;
 	cout<<endl;
 int *ptr=new int[size];
  for(int i=0;i<size;i++)
 {
 	cin>>ptr[i];
 }
 dub(ptr,size);
}
*//*
 #include<iostream>
using namespace std;
struct stu{
	string id;
	int size=50;
	char *pc = new char[size];
	float marks;
};
int main()
{
	int size;
	cin>>size;
stu *ptr= new stu[size];
for (int i =0;i<size;i++)
{
cin.ignore();
getline(cin,ptr[i].id);

cin>>ptr[i].pc;
cin>>ptr[i].marks;
}
for (int i =0;i<size;i++)
{

cout<<ptr[i].id<<" ";
cout<<ptr[i].pc<<" ";
cout<<ptr[i].marks<<" ";
}
}*/
/*
#include<iostream>
#include<fstream>
using namespace std;
int main()
{ 
//string word;
char word;
//ofstream myfile;
ifstream file;
//myfile.open("file.txt",ios::app);
//myfile<<"this is Raja Umer Saleem"<<endl;
//myfile.close();
//myfile.open("file.txt",ios::app);
//for(int i=1;i<=100;i++){
//	myfile<<i<<endl;
//}
 file.open("file.txt");
 if(file.is_open())
 {
 cout<<"File open"<<endl;
 while(true)
 {
 	file>>word;
 	cout<<file.tellg()<<" "<<word<<endl;
 	if(file.eof())
  	break;
 }
 file.close();
}   
}*/


//file handling
//p1
/*
#include<iostream>
#include<string>
#include<fstream>
using namespace std;
int main()
{ 
int c;
string word;
char ch;
ifstream fout;
fout.open("student.txt");
 if(fout.is_open())
 {
 cout<<"File open"<<endl;
 while(true)
 {
 	getline(fout,word);
 c++;
 	if(fout.eof())
  	break;
 }
 fout.close();
}
cout<<"Lines are:"<<c-1;
c=0;
fout.open("student.txt");
 if(fout.is_open())
 {
 cout<<endl<<"File open"<<endl;
 while(true)
 {
 fout>>word;
 c++;
 	if(fout.eof())
  	break;
 }
 fout.close();
}
cout<<"words are:"<<c-1;
c=0;
 fout.open("student.txt");
 if(fout.is_open())
 {
 cout<<endl<<"File open"<<endl;
 while(true)
 {
 fout>>ch;
 c++;
 	if(fout.eof())
  	break;
 }
 fout.close();
}
cout<<"characters are:"<<c-1;
return 0;
}*/
// name , id,cgpa,marks,grade
/*� A function to read the students� data into the array.
� A function to assign the relevant grade to each student based on their marks.
� A function to find the highest test score.
� A function to display best three assignment marks of each student.
� Sort the data of each student based on their total marks.*/

#include<iostream>
#include<string>
#include <cstdlib>
#include<fstream> 
#include<cstddef> 
using namespace std;
int main(){
	fstream file;
		int account;
	string passid,pword;
	cout<<"Dear customer!\n1:you have an account\n2:You want to create to create a account\n";
	cin>>account;
	switch(account)
	{
		case1:
		//read;	
		  break;
		  case2:
		  	cin.ignore();
		  	cout<<"Enter id"<<endl;
		  	cin>>passid;
		  	cout<<"Enter password"<<endl;
		    cin>>pword;
		  	file.open("password.txt",ios::app|ios::out);
		 if (!file.is_open()) {
                cout << "Error opening file." << endl;
            }
		  	file<<passid<<" "<<pword<<endl;
		  	file.close();
		  	break;
        }
}

