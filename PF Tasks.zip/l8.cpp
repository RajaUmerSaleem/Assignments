                   /*RAJA UMER SALEEM
                      2023-CS-609*/

//Q1
/*
#include<iostream>
using namespace std;
//data in required form
void matrix(int a[5][3],string n[5])
{
cout<<"\tQuiz1\tQuiz2\tQuiz3"<<endl;
for(int i=0;i<5;i++)
{
	cout<<n[i]<<"	";
	for(int j=0;j<3;j++)
	{
		cout<<a[i][j]<<"	";
	}
cout<<endl;
}
}
//maximum no.s in all quizes and student names..
void marks(int a[5][3],string n[5])
{
	int s;
	int max;
for(int j=0;j<3;j++)
    {
		s=0;
max = a[0][j];
for(int i=0;i<5;i++)
	{
	   if(max<a[i][j])
	    {
		max=a[i][j];
		s=i;
	   }  
	}
	cout<<"the maximum marks in quiz no"<<j+1<<" is "<<max<<" and student name is "<<n[s]<<endl;	
  }		
}
//overall toper and name..
void overall(int a[5][3],string n[5])
{	
int s;
int max=0;
	for(int i=0;i<5;i++)
{
	int sum =0;
	for(int j=0;j<3;j++)
	{
		sum+=a[i][j];
	}
if(max<sum)	
{
	max=sum;
	s=i; 
}
}
cout<<"the maximum marks are "<<max<<"\n"<<"and student name is "<<n[s];
		}
//fetch data by name 
void fetchrecord(int a[5][3],string n[5],string name)
  {
			int qshow=0;
			cout<<"       quiz1 quiz2 quiz3 "<<endl;
for(int i=0;i<5;++i)
   {
	if(n[i]==name)
	{
		cout<<n[i]<<"	";
		qshow = i;
	}
	for(int j=0;j<3;j++)
	{
	 { 
		if(i==qshow)
		cout<<a[i][j]<<"	";
		}
	}
  }	
}
 void sorted(int a[5][3],string n[5],string name)	
 {
 	
int sum [5];
for(int i=0;i<5;i++)
{
	sum[i]=0;
	for(int j=0;j<3;j++)
	{
		sum[i]+=a[i][j];	
	}
	cout<< "Name"<<"  "<<n[i]<<"   "<<" total marks "<<sum[i]<<endl;
}	
cout<<endl<<" Sorted by descendiong order"<<endl;
for(int i=0;i<4;i++)
{ 
for (int j=i+1;j<5;j++)
	if(sum[j]>sum[i])
	{
int S= sum[j];
            sum[j] = sum[i];
            sum[i] = S;
            
            string N = n[j];
            n[j] = n[i];
            n[i ] = N;
    }
}
for(int i=0;i<5;i++)
{
	cout<<"name"<<"  "<<n[i]<<"  "<<"sum"<<"  "<<sum[i]<<endl;
}
	cout<<endl;
	 }	
int main()
{ 
string name="";
int qshow;
int a[5][3];
 string n[5];
for(int i=0;i<5;i++)
{
	cout<<"Enter the name of student"<<endl;
	cin>>n[i];
	for(int j=0;j<3;j++)
	{
		cout<<"enter the marks in quiz no"<<j+1<<endl;
		cin>>a[i][j];
	}
}
matrix(a,n);	
marks(a,n);
overall(a,n);

cout<<endl<<"entre the name of student to find its record "<<endl;
cin.ignore();
cin>>name;
fetchrecord(a,n,name);
cout<<endl;
sorted(a,n,name);
return 0;
}*/


//	Q2
/*
#include<iostream>
using namespace std;
const int r=3;

const int c=3;
void magic(int arr[r][c])
{
	int r1,r2,r3,c1,c2,c3,d1,d2;
	r1=r2=r3=c1=c2=c3=d1=d2=0;
	r1=arr[0][0]+arr[0][1]+arr[0][2];
	r2=arr[1][0]+arr[1][1]+arr[1][2];
	r3=arr[2][0]+arr[2][1]+arr[2][2];
	c1=arr[0][0]+arr[1][0]+arr[2][0];
	c2=arr[0][1]+arr[1][1]+arr[2][1];
	c3=arr[0][2]+arr[1][2]+arr[2][2];
d1=arr[0][0]+arr[1][1]+arr[2][2];
d2=arr[0][2]+arr[1][1]+arr[2][0];

if(	r1==r2&&r1==r3&&c1==c2&&c1==c3&&r1==d1&&r1==d2&&d1==d2)
{
cout<<"it is a  magic matrix ";
}
else
cout<<"it is not a  magic matrix ";
}

int main()
{
	int arr[r][c];
	cout<<" Enter the entities of this matrix to check wheather it is magic or not"<<endl;
	for(int i=0;i<r;i++)
	{
		for(int j=0;j<c;j++)
		{
			cin>>arr[i][j];
		}
	}
		for(int i=0;i<r;i++)
	{
		for(int j=0;j<c;j++)
		{
		cout<<arr[i][j]<<" ";
		}
		cout<<endl;
	}
	  magic(arr);
	}*/
 //Q3
/*#include<iostream>
using namespace std;
int main()
{
	int i,j,k;
	int sum=0;
	int m_1[3][3];
	int m_2[3][3];
	int result_matrix[3][3];
	cout<<"ENTER FIRST MATRIX ELEMENTS"<<endl;
for(i=0;i<3;i++)
 {
		 for(j=0;j<3;j++)
	{
		cin>>m_1[i][j];
	}
 }
 	cout<<"  FIRST MATRIX "<<endl;
 for(i=0;i<3;i++)
 {
		 for(j=0;j<3;j++)
	{
		cout<<m_1[i][j]<<"  ";
	}
 cout<<endl;
 }
 cout<<"ENTER SECOND MATRIX ELEMENTS"<<endl;
 for(i=0;i<3;i++)
 {
		 for(j=0;j<3;j++)
	{
		cin>>m_2[i][j];
	}
 }
  cout<<"  SECOND MATRIX"<<endl;
 for(i=0;i<3;i++)
 {
		 for(j=0;j<3;j++)
	{
		cout<<m_2[i][j]<<endl;
	}
	cout<<endl;
 }
 for(i=0;i<3;i++)
 { 
		 for(j=0;j<3;j++){	
		 sum=0;	
	for(k=0;k<3;k++)
{
		sum+=m_1[i][k]*m_2[k][j];
}
	result_matrix[i][j]=sum;
 }
 	
}
cout<<"  RESULT MATRIX  "<<endl;
  for(i=0;i<3;i++)
 { 
 
		 for(j=0;j<3;j++)
	{
	cout<<result_matrix[i][j]<<"	";
	}
	cout<<endl;
 }
}*/
//Q4 
//TIC TAC TOE GAME by 2d arrays
/*
#include<iostream>
using namespace std;
bool tie=false; 
char spaces[3][3]={{' ',' ',' '},{' ',' ',' '},{' ',' ',' '}};
string n1,n2;
int r;
int c;
char token = 'X';
void board()
{
	system("cls");
	cout<<"\t"<<spaces[0][0]<<"  | "<<spaces[0][1]<<" | "<<spaces[0][2]<<endl;
	cout<<"\t"<<"___|"<<"___"<<"|___"<<endl;
	cout<<"\t"<<spaces[1][0]<<"  | "<<spaces[1][1]<<" | "<<spaces[1][2]<<endl;
	cout<<"\t"<<"___|"<<"___"<<"|___"<<endl;
	cout<<"\t"<<spaces[2][0]<<"  | "<<spaces[2][1]<<" | "<<spaces[2][2]<<endl;
	cout<<"\t"<<"   |"<<"   "<<"|   "<<endl;  	
}
void input()
{
 if(token=='X')
	{
	cout<<n1<<" player 1 "<<endl;
	cout<<n1<<" enter the row number "<<endl;
	cin>>r;
	cout<<n1<<" enter the column number "<<endl;
	cin>>c;
	}
 if(token=='O')
	{
	cout<<n2<<" player 2 "<<endl;
	cout<<n2<<" enter the row number "<<endl;
	cin>>r;
	cout<<n2<<" enter the column number "<<endl;
	cin>>c;
	}	
if(token=='X'&&spaces[r][c]!='X'&&spaces[r][c]!='O')
	{
		spaces[r][c]='X';
		token='O'; 
		board();
	}
else if(token=='O'&&spaces[r][c]!='X'&&spaces[r][c]!='O')
	{
		spaces[r][c]='O';
		token='X';
		board();
	}
else
	{
		cout<<"there is no empty space"<<endl;
	}
}
int check()
{
	return 0;
	for (int i =0;i<3;i++)
	{
		if( (spaces[i][0]==spaces[i][1] && spaces[i][0]==spaces[i][2]) || (spaces[0][i]==spaces[1][i] && spaces[0][i]==spaces[2][i]))
	return 1;
	}
	 if( (spaces[0][0]==spaces[1][1] && spaces[0][0]==spaces[2][2]) || (spaces[0][2]==spaces[1][1] && spaces[0][2]==spaces[2][0]) )
	{
	return 1;
	}
	
for(int i =0;i<3;i++)
   	for(int k =0;k<3;k++)
    {
	if(spaces[i][k]!='X'&& spaces[i][k]!='O')
		return 0;
     }
	tie = true;
	return 1;
}

int main()
{
	cout<<"\t\t\t[-------------------------------]"<<endl;
	cout<<"\t\t\t{--------- TIC TAC TOE ---------}"<<endl;
    cout<<"\t\t\t[-------------------------------]"<<endl;
    cout<<"Enter the first player name"<<endl;
    getline(cin,n1);
    cout<<"Enter the second player name"<<endl;
    getline(cin,n2);
    cout<<n1<<" you are first player and you will play at first, you have X symbol"<<endl;
    cout<<n2<<" you are second player and you will play at second, you have O symbol"<<endl;  
    
   
do
{
     board();
	input();
	check();
	
}
while(check()!=1);
	
if(check()==1 && token=='X'&&tie==false)
{
	cout<<n1<<" won the game "<<endl;
}
else if(check()==1 && token=='O'&&tie==false)
{
	cout<<n2<<" won the game "<<endl;
}
else
{
	cout<<"it is tie!!"<<endl;
}
}*/

                       /*THANKYOU very much... Respected SIR! MUHAMMAD AIZAZ AKMAL 
					   for this opportunity to make this assignment.*/



	
