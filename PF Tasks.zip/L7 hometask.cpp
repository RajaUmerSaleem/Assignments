                     //PF LAB 7 HOME TASK ASSIGNMENT 
                     /*RAJA UMER SALEEM 
                     CS-2023-609*/
//1
/*#include<iostream>
using namespace std;
int fibonacci(int n)
{
	for (int i=1;i<=n;i++)
cout<<i<<endl;
return 0;
}
int main()
{
	int n;
	cout<<"enter the number ";
	cin>>n;
 fibonacci(n);
	
}*/

//2
/*
#include<iostream>
using namespace std;
int palindrome(int a)
{
	int b,c,d;
	b=(a/100);
	c=(a/100)%10;
	d=(a%100)%10;	
	if(b==d)
	  	cout<<" Palindrome " ;
	  	else
	  		cout<<" not Palindrome " ;
	  		return 0;
	  	}
	  	int main()
	  	{
	int a;
	cout<<"enter the number ";
	cin>>a;
palindrome(a);
}
*/
//3
/*
#include<iostream>
using namespace std;
int FizzBuzz(int n)
{
	if( n%3==0)
	cout<<"Fizz";
if( n%5==0)
		cout<<"Buzz";
		else
			cout<<"it does not lie on both conditions";
		return 0;
	}
int main()
{
	int n;
	cout<<"enter the number ";
	cin>>n;
FizzBuzz(n);
}*/

//4
/*
#include<iostream>
using namespace std;
int sum(int x,int y )
{	
cout<<x+y;
return 0;
}
int sub(int x,int y )
{	
cout<<x-y;
return 0;
}
int mul(int x,int y )
{	
cout<<x*y;
return 0;
}
int div(int x,int y )
{	
cout<<x/y;
return 0;
}
int main()
{
	int x,y;
	int c;
	cout<<"enter two numbers ";
	cin>>x>>y;
	cout<<"enter 1 to add "<<endl;
		cout<<"enter 2 to multipty "<<endl;
			cout<<"enter 3 to subtraction "<<endl;
				cout<<"enter 4 to divide"<<endl;
				cin>>c;		
 switch(c)
{
case 1:
	sum(x,y);
	break;
	case 2:
	mul(x,y);
	break;
	case 3:
	sub(x,y);
	break;
	case 4:
	div(x,y);
	break;
	default:
		cout<<"enter valid choice ";
}
return 0;
}
*/
//5
/*
#include<iostream>
using namespace std;
char cal_grade(int n)
{
	char X;
	if(n>=75)
 X = 'A';
 else 	if(n>=60)
 X = 'B';
  else 	if(n>=50)
 X = 'C';
 else
  X = 'F';
  return X;
}
int main ()
{
	int n;
	cout << "enter your marks";
	cin>>n;
	cout<<"your grade is "<<cal_grade(n);
	return 0;
	
}*/

//6
/*
#include<iostream>
using namespace std;
int triangle(int n)
{
	for (int i=1;i<=n;i++)
	{
	for(int j=1;j<=i;j++)
	{
	
cout<<i;
}
cout<<endl;
}
return 0;
}
int main()
{
	int n;
	cout<<"enter the number ";
	cin>>n;
 triangle(n);
 return 0;
}*/
  /*THANKYOU very much... Respected SIR! MUHAMMAD AIZAZ AKMAL and  Respected MA'AM! ZOHA SOHAIL
					   for  this opportunity to make this assignment.*/





		
	
