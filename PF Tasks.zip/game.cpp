#include<iostream>
#include<windows.h>
#include<conio.h>
using namespace std;

bool gameover;
const int w = 20;
const int h = 20;
int headx, heady, fruitx, fruity, score;
int tailx[100], taily[100], ntail;
enum edirection {stop = 0, LEFT, RIGHT, UP, DOWN};
edirection dir;

void setup()
{
	gameover = false;
	dir = stop;
	score = 0;
	ntail = 0;
	headx = w / 2;
	heady = h / 2;
	fruitx = rand() % w;
	fruity = rand() % h;
}
void draw()
{
	system("cls");
	for (int i = 0; i <= w + 1; i++)
	{
		cout << "#";
	}
	cout << endl;
	for (int i = 0; i < h; i++)
	{
		for (int j = 0; j <= w; j++)
		{
			if (j == 0)
			{
				cout << "#";
			}
			if (headx == j && heady == i)
			{
				cout << "O";
			}
			else if (fruitx == j && fruity == i)
			{
				cout << "A";
			}
			else
			{
				bool print = false;
				for (int k = 0; k < ntail; k++)
				{
					if (tailx[k] == j && taily[k] == i)
					{
						cout << "o";
						print = true;
					}
				}
				if (!print)
				{
					cout << " ";
				}
			}
			if (j == w - 1)
			{
				cout << "#";
			}
		}
		cout << endl;
	}
	for (int i = 0; i <= w + 1; i++)
	{
		cout << "#";
	}
	cout << endl;
	cout << "score : " << score << endl;
}
void input()
{
	if (_kbhit())
	{
		switch (_getch())
		{
		case'a':
			dir = LEFT;
			break;
		case'd':
			dir = RIGHT;
			break;
		case's':
			dir = DOWN;
			break;
		case'w':
			dir = UP;
			break;
		case'x':
			gameover = true;
			break;
		default:
			break;
		}
	}
}
void logic()
{
	int prevx = tailx[0];
	int prevy = taily[0];
	int prev2x, prev2y;
	tailx[0] = headx;
	taily[0] = heady;
	for (int i = 1; i < ntail; i++)
	{
		prev2x = tailx[i];
		prev2y = taily[i];
		tailx[i] = prevx;
		taily[i] = prevy;
		prevx = prev2x;
		prevy = prev2y;
	}
	switch (dir)
	{
	case LEFT:
		headx--;
	break;
	case RIGHT:
		headx++;
	break;
	case UP:
		heady--;
	break;
	case DOWN:
		heady++;
	break;
	default:
		break;
	}
//	if (headx > w || headx < O || heady > h || heady < O)
//	{
	//	gameover = true;
	//}
	if (headx >= w)
		headx = 0;
	else if (headx < 0)
		headx = w - 1;
	if (heady >= h)
		heady = 0;
	else if (heady < 0)
		heady = h - 1;
	for (int i = 0; i < ntail; i++)
	{
		if (tailx[i] == headx && taily[i] == heady)
		{
			gameover = true;
		}
	}
	if (headx == fruitx && heady == fruity)
	{
		score = score + 10;
		fruitx = rand() % w;
		fruity = rand() % h;
		ntail++;
	}
}

int main()
{
	setup();
	while (!gameover)
	{
		draw();
		input();
		logic();
		Sleep(100);
	}
	return 0;
}
