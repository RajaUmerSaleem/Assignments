#include<iostream>
#include<math.h>
using namespace std;
int main() {
	
int a,b;
cout<<"enter two numbers to \n ";
cin>>a;
cin>>b;
cout<<" your sum is \n "<<a+b;
}

