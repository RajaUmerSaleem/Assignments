                            // PF LAB3 ASSIGGNMENT
							/*RAJA UMER SALEEM 
                               CS-2023-609*/

/*
//P1
#include<iostream>
using namespace std;
int main()
{
int len,w,a;
cout<<"enter the length ";
cin>>len;
cout<<"enter the width ";
cin>>w;
a=len*w;
cout<<" Area of rectangle is:  "<<a;
return 0;
}*/

/*
//P2
#include<iostream>
using namespace std;
int main()
{
int dkm,m,f,i,cm;
cout<<"Enter the distance";
cin>>dkm;
m=dkm*1000;
f=dkm*3281;
i=dkm*39370;
cm=dkm*100000;
cout<<"Distance in meters: "<<m<<endl;
cout<<"Distance in feets: "<<f<<endl;
cout<<"Distance in inches: "<<i<<endl;
cout<<"Distance in centimeters: "<<cm<<endl;
return 0;
}*/

//P3
/*
#include<iostream>
using namespace std;
int main()
{
int tf,tc;
cout<<"Enter temperature in Fahrenheit degrees";
cin>>tf;
tc=(tf-32)*5/9;
cout<<tc;
}*/

//P4
/*#include<iostream>
using namespace std;
int main()
{
int len,b,r,ar,p,ac,c;
cout<<"enter the length of rectangle";
cin>>len;
cout<<"enter the breadth of rectangle";
cin>>b;
cout<<"enter the radius of circle";
cin>>r;
ar=len*b;
p=2*(len+b);
ac=3.14*r*r;
c=2*3.14*r;
cout<<"Area of rectangle :"<<ar<<endl;
cout<<"perimeter of rectangle :"<<p<<endl;
cout<<"Area of circle :"<<ac<<endl;
cout<<"circumference of circle :"<<c<<endl;
return 0;
}*/
 
//P5
/*
#include<iostream>
using namespace std;
int main()
{
int td,y,m,w,d;
	
cout<<"Enter number of days";
cin>>td;
y=td/365;
td=td%365;
m=td/30;  //30days in one month
td=td%30;
w=td/7;  //7days in one week
td=td%7;
d=td;
cout<<"No. of years :"<<y<<endl;
cout<<"No. of months :"<<m<<endl;
cout<<"No. of week :"<<w<<endl;
cout<<"No. of days :"<<d<<endl;
return 0;	
}*/	

//P6
/*	#include<iostream>
using namespace std;
int main()
{
int tc,h,fif,t,fiv,r;
cout<<"Amount of withdrawal :";
cin>>tc;
h=tc/100;
tc=tc%100;
fif=tc/50;
tc=tc%50;
t=tc/10;
tc=tc%10;
fiv=tc/5;
tc=tc%5;
r=tc;
cout<<"Notes of Hundred :"<<h<<endl;
cout<<"Notes of fifty  :"<<fif<<endl;
cout<<"Notes of ten :"<<t<<endl;
cout<<"Notes of five :"<<fiv<<endl;
cout<<"Notes of rupee:"<<r<<endl;
return 0;
}*/

//P7
/*
#include<iostream>
using namespace std;
int main()
{
	int a,b,c,d;
	cout<<" Enter a number :";
	cin>>a;
	b=(a/100);
	c=(a%100)/10;
	d= a%10;
	cout<<" sum is:"<<b+c+d<<endl;
	cout<<" reverse:"<<d<<c<<b<<endl;
	return 0;
}

 Output
Enter a number :456
 sum is:15
 reverse:654*/
 
 //P8
 /*#include<iostream>
using namespace std;
int main()
{
		int a,b,c,d,e,f;
	cout<<" Enter a number :";
	cin>>a;
	b=(a/10000);
	c=(a/1000)%10;
	d= ((a%1000)/100);
	e=((a%100)/10);
	f=a%10;
		cout<<b+1;
		cout<<c+1;
 	cout<<d+1;
			cout<<e+1;
				cout<<f+1;
				return 0;
			}
*/

//P9
/*
 #include<iostream>
using namespace std;
int main()
{
int a,b,c,m,r,q,z;
cout<<"enter the value of a:";
cin>>a;
cout<<"enter the value of b:";
cin>>b;
cout<<"enter the value of c:";
cin>>c;
cout<<"enter the value of m:";
cin>>m;
cout<<"enter the value of r:";
cin>>r;
cout<<"enter the value of q:";
cin>>q;
z=(8.8*(a+b)*2/c-0.5+2*a/(q+r))/(a+b)*(1/m);
cout<<"the result is"<<z;
return 0;
}
*/
//P10
/*
 #include<iostream>
using namespace std;
int main()
{
	int a;
	cout<<"enter a number :";
	cin>>a;
	if(a>=0)
	{
		if (a%2==0)
			cout<<"it is positive and even number :";
			else
			cout<<"it is positive and odd number :";	
	}
	else
		{
		if (a%2==0)
			cout<<"it is negitive and even number :";
			else
			cout<<"it is negitive and odd number :";		
	}
	return 0;
}*/

//P11
/*
#include<iostream>
using namespace std;
int main()
{
	int y;
	cout<<"enter year:";
	cin>>y;
	if(y%4==0 &&( y%100!=0 ||y%400==0))
			cout<<"it is a leap year";
			else
cout<<"it is not a leap year";

return 0;
}
*/

//P12
/*
#include<iostream>
using namespace std;
int main()
{
int u;
cout<<"Enter number of units";
cin>>u;	
if (u<=50)
	u=u*20;
else if (u<=150)

	u=(20*50)+((u-50)*25);

else if (u<=250)

	u=(20*50)+(100*25)+((u-150)*30);

else if (u<=500)

	u=(20*50)+(100*25)+(100*30)+((u-250)*35);

u=u+u*.2;
cout<<u<<"rupees";
return 0;
}
*/

//P13
/*
#include<iostream>
using namespace std;
int main()
{
	int n , w;
	float p,kg,g,o;
	char in;
	cout<<"Enter weigth of choclates";
	cin>>w;
	cout<<"Enter number of choclates";
	cin>>n;
	cout<<"press O for ounce weigth"<<endl;
	cout<<"press P for  pounds weigth"<<endl;
	cout<<"press G for  grams weigth"<<endl;
	cout<<"press K for Kilograms weigth"<<endl;	
	cin>>in;
	if(in=='O')
	{
		o=w*n;
		cout<<o<<" ounces";	
	}
	else	if(in=='P')
			{
		p=w*n*0.0625;
		cout<<p<<" pounds";
		
	}
	else		if(in=='G')
					{
		p=w*n*28.3495;
		cout<<p<<" grams";
		
	}
		else		if(in=='K')
	
					{
		p=w*n*0.0283495;
		cout<<p<<" Kilograms";
		
	}
	return 0;
}
*/

//P14
/*
#include<iostream>
using namespace std;
int main()
{
	int bc=10;
	float tm,cm,ac,at,tax,st;
	cout<<"enter the no. of minutes calls :";
	cin>>cm;
	cout<<"enter the no. of  texts :";
	cin>>tm;
	tax=0.5;
	if(tm>60)
	 at=(tm-60)*0.1;
	 if(cm>40)
	 ac=(cm-40)*0.2;
	cout<<"the base charge $"<<bc<<endl;
		cout<<"the additional call charges $"<<ac<<endl;
		cout<<"the additional text charges $"<<at<<endl;
		cout<<"Rescue 1122 charges $"<<tax<<endl;
		st=bc+ac+at+tax;
		st=st+st*.05;
		cout<<"the entire bill  $"<<st<<endl;
		return 0;
	}*/
	
	                         /*THANKYOU very much... Respected SIR! MUHAMMAD AIZAZ AKMAL 
					              for this opportunity to make this assignment.*/
	
	
	
	
	
	
	
	
 
