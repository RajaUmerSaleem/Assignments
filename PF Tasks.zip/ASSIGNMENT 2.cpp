#include<iostream>
#include<cmath>
using namespace std;
//PROBLEM 1:
/*void pattern(int height)
{
	for (int a = height; a >= 1; --a)
	{
		cout << " ";
		for (int s = 0; s <height-a; s++)
		{
			cout << " ";
		}
		for (int k = a; k <= (2*a)-1; k++)
		{
			cout << "*";
		}
		for (int k = 0; k < a-1; k++)
		{
			cout << "*";
		}
		cout << endl;
	}
	for (int i = 2; i <= height; i++)
	{
		for (int space = 0; space <= height-i; space++)
		{
			cout << " ";
		}
		for (int j = 1; j <= (2 * i) - 1; j++)
		{
			cout << "*";
		}
		cout << endl;
	}
}
int main()
{
	int num;
	cout << "Enter the Number: ";
	cin >> num;
		num = (num / 2)+1;
	pattern(num);
	return 0;
}*/
/*void diamond(int num)
{
	for (int i = 1; i <= (num/2); i++)
	{
		cout << " ";
		for (int j = 1; j <= num - i; j++)
		{
			cout << " ";
		}
		for (int k = 0; k != (2 * i - 1); )
		{
			if (k == 0 || k == 2 * i - 2)
				cout << "*";
			else
				cout << " ";
			k++;
		}
		cout << endl;
	}
	for (int i = num/2; i >= 1; i--)
	{
		for (int j = 0; j <= num - i; j++)
		{
			cout << " ";
		}
		for (int k = 0; k != (2 * i - 1); )
		{
			if (k == 0 || k == 2 * i - 2)
				cout << "*";
			else
				cout << " ";
			k++;
		}
		cout << endl;
	}
}
int main()
{
	int height;
	cout << "Enter the Height: ";
	cin >> height;
	diamond(height);
	return 0;
}*/

//PROBLEM 2:
/*bool Powerful(int n)
{
	int m=n, x, s=0,k=n,l;
	double j;
	l = log10(m)+1;
	while(m!=0)
	{
		x = m % 10;
		j=pow(x, l);
		s = s + j;
		m /=10;
	}
	return s == k;
}
int main()
{
	int k;
	cout << "Enter the number.";
	cin >> k;
	if (Powerful(k))
		cout << "it is a powerful number";
	else
		cout << "It is not a powerful number ";
	return 0;
	}*/
//PROBLEM 3

/*
void Powerful(int n)
{
	int  x, s = 0, j, l;

	s == 0;
	int m = n;
	for (int i = n; i <= n; i++) {
	while (m != 0)
		{
			x = m % 10;
			j = pow(x, 3);
			s = s + j;
			
			m /= 10;
		}
		if (s == n)
			cout << i << " ";
	}
}

int main()
{
	cout << "ALL 3 digit powerful numbers" << endl;
	for (int i = 100; i < 1000; i++)
	
	{
		Powerful(i);
	}
	return 0;
}*/


//PROBLEM 4
/*void prime(int n)
{
	int k = n;

	for (int j = 1; j < k; j++)
	{
		int p = 0;
		int Nu = j;
		for (int i = 1; i < n; i++)
		{ 
			if (Nu % i == 0)
				p++;
		}
		if (p == 2)
			cout <<Nu << " ,  ";
	}
}
int main() {
	int n;
	cout << "enter the range for prime numbers: ";
	cin >> n;
	prime(n);
}*/

//PROBLEM 5
/*void series(int fi, int se, double n)
{
	if (n > 2)
	{
		cout << fi << " " << se << " ";
		int num1 = fi;
		int num2 = se;
		for(int i=3;i<=n;++i)
		{
			int nextn;
			if (i % 2 == 1)
			{
				nextn = num1 + num2;
			}
			else
			{
				nextn = num1 * num2;
			}
			cout << nextn << " ";
			num1 = num2;
			num2 = nextn;
		}
	}
	else
	{
		cout << "iteration must be greater than 2.";
	}
}
int main() {
	int fi, se, n;
	cout << "Enter the first number:  ";
	cin >> fi;
	cout << "Enter the second number: ";
	cin >> se;
	cout << "enter the series iteration: ";
	cin >> n;
	series(fi, se, n);
	return 0;
}*/


//PROBLEM 6


int SumOfDigits(int n) {
	int sum = 0;

	while (n > 0) {
		sum += n % 10;
		n /= 10;
	}

	return sum;
}

int SingleDigitSum(int n) {
	while (n >= 10) {
		n = SumOfDigits(n);
	}
	return n;
}

int main() 
{
	int inputNumber;

	cout << "Enter a number: ";
	cin >> inputNumber;
	int singleDigitSum = SingleDigitSum(inputNumber);
	cout << "The sum of digits after a single-digit number is: " << singleDigitSum <<endl;
	return 0;
}


//PROBLEM 7


/*void menu(int n, int m, int choice) {
	int  num1=n, num2=m, a, su, d, mul;

		switch (choice) {
		case 1:
			 a = num1 + num2;
			cout << "Result: " << a<<endl;
			break;
		case 2:
			 su = num1 - num2;
			cout << "Result: " << su<<endl;
			break;
		case 3:
			 d = num1 / num2;
			cout << "Result: " << d<<endl;
			break;
		case 4:
			 mul = num1 * num2;
			cout << "Result: " << mul<<endl;
			break;
		default:
			cout << "Invalid choice. Please select a valid option." << endl;
		}
	}
int main()
{
	int n, m, choice;
	cout << "enter first number: ";
	cin >> n;
	cout << "enter second number: ";
	cin >> m;
	cout << "Calculator Menu:" << endl;
	cout << "1. Addition" << endl;
	cout << "2. Subtraction" << endl;
	cout << "3. Division" << endl;
	cout << "4. Multiplication" << endl;
	cout << "Enter your choice (1-4): ";
	cin >> choice;
	menu(n, m, choice);
	return 0;
}*/


         ////QUIZ 2
//Task 1
/*bool Palindrome(int x) {
    if (x < 0) {
        return false;
    }

    int originalX = x;
    int reversedX = 0;

    while (x > 0) {
        int digit = x % 10;
        reversedX = reversedX * 10 + digit;
        x /= 10;
    }

    return originalX == reversedX;
}

int main() {
    int num;
    cout << "Enter an integer: ";
    cin >> num;

    if (Palindrome(num)) {
        cout << num << " is a palindrome." << endl;
    }
    else {
        cout << num << " is not a palindrome." << endl;
    }

    return 0;
}
*/

//Task 2
/*
bool isPrime(int n) {
	if (n <= 1) {
		return false;
	}
	for (int i = 2; i * i <= n; i++) {
		if (n % i == 0) {
			return false;
		}
	}
	return true;
}
bool isPerfect(int n) {
	int sum = 1; 
	for (int i = 2; i * i <= n; i++) {
		if (n % i == 0) {
			sum += i;
			if (i != n / i) {
				sum += n / i;
			}
		}
	}
	return sum == n;
}

bool isFunny(int number) {
	int sum = 0;
	int temp = number;
	while (temp > 0) {
		sum += temp % 10;
		temp/= 10;
	}
	if (isPrime(sum - 1)) {
		return true;
	}
	int numDigits = 0;
	int firsthalfsum = 0;
	int secondhalfsum = 0;
	temp = number;
	while (temp > 0) {
		int digit = temp % 10;
		if (numDigits % 2 == 0) {
			firsthalfsum += digit;
		}
		else {
			secondhalfsum += digit;
		}
		temp /= 10;
		numDigits++;
	}
	int difference = abs(firsthalfsum - secondhalfsum);
	if (isPerfect(difference)) {
		return true;
	}

	return false;
}

int main() {
	int number;
	cout << "Enter a number: ";
	cin >> number;

	if (isFunny(number)) {
		cout << "The number is funny." << endl;
	}
	else {
	cout << "The number is serious." << endl;
	}

	return 0;
}*/
