/*#include<iostream>
using namespace std;
int main()
{
	int num,temp,reverse,temp2,orignal;
	cin>>num;
	reverse=0;
	while(num!=0)
	{
		temp=num%10;
		reverse=reverse*10+temp;
		num=num/10;
	}
	//reverse num is in reverse ;
	while(reverse>=0)
	{
	temp2=reverse%10;
	orignal=temp2;
	reverse=reverse/10;
		if(orignal==8)
		cout<<"EIGHT ";
		else if(orignal==1)
		cout<<"ONE ";
			else if(orignal==2)
		cout<<"TWO ";
			else if(orignal==3)
		cout<<"THREE ";
			else if(orignal==4)
		cout<<"FOUR ";
			else if(orignal==5)
		cout<<"FIVE ";
			else if(orignal==6)
		cout<<"SIX ";
			else if(orignal==7)
		cout<<"SEVEN ";
		else if (orignal==9)
		cout<<"NINE ";
		else 
		{

		cout<<"ZERO ";
		break;
	}
	}
	return 0;	
}
*/
